#pragma once

#include "util/keydefs.h"
#include "util/log.h"
#include "util/string_utils.h"
#include "util/touch.h"

#include "../lua.h"

#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>

#include <stdexcept>
#include <string>
#include <map>
#include <list>
#include <vector>

#include <ctime>

namespace player {
namespace event {

//	Event type
#define TYPE_LIST(fnc)	\
	fnc( presentation )	\
	fnc( selection )	\
	fnc( attribution )

namespace evtType {
#define DO_ENUM_TYPE(t) t,
enum type {
	unknown = 0,
	TYPE_LIST(DO_ENUM_TYPE)
	LAST
};
#undef DO_ENUM_TYPE
}

//	Event action
#define ACTION_LIST(fnc)	\
	fnc( start )	\
	fnc( stop )		\
	fnc( abort )	\
	fnc( pause )	\
	fnc( resume )

namespace evtAction {
#define DO_ENUM_ACTION(a) a,
enum type {
	unknown = 0,
	ACTION_LIST(DO_ENUM_ACTION)
	LAST
};
#undef DO_ENUM_ACTION
}

/*
Returns a Lua-compatible representation of the given value as a string.
*/
template<typename T> std::string represent(const T &value) {
    return util::to_string(value);
}

template<> std::string represent(const std::string &value);

/*
Special class representing a nil value.
*/
class LuaNil {
public:
    operator std::string() const;

    void push(lua_State *lua) const;

    static const LuaNil NIL;
};

template<> std::string represent(const LuaNil &value);

/*
A field in a Lua table.

This class implements basic functionality for exchanging single field values
between a C++ application and a running Lua context. For more details, see
LuaTable below.

This is an abstract class. The LuaFieldValue template
*/
class LuaField {
public:
    /*
    Creates a new field of the given name.
    */
    LuaField(const std::string &name);

    // Destructor
    virtual ~LuaField() { };

    /*
    Returns a string representation of this field.
    */
    virtual operator std::string() const = 0;

    /*
    Returns a pointer to a copy of this field.
    */
    virtual LuaField *clone() const = 0;

    /*
    Pushes this field's value to the given Lua context's global stack.
    */
    virtual void push(lua_State *lua) const = 0;

    /*
    Returns a char which represents the type of the stored value
     */
    virtual char typeChar() const = 0;

    // The field's name. Array items leave this empty.
    const std::string name;
};

typedef boost::shared_ptr<LuaField> LuaFieldPtr;

typedef std::vector<LuaFieldPtr> LuaFieldArray;

typedef std::map<std::string, LuaFieldPtr> LuaFieldMap;

/*
Template implementation of the abstract class LuaField.

To be used with LuaFieldValue, a type must provide:

# A zero-argument constructor;
# Support for value assignment;
# A push() method that accepts a lua_State* argument (or alternatively, a
  template specialization of LuaFieldValue::push);
# A template specialization of player::event::represent that accepts a const
  reference to a value of the type (only for user types; primitive types are
  already covered by the template's default definition).

Currently the following types fulfill the requirements above:

* bool
* int
* double
* std::string
* LuaNil (special class for nil values)
* LuaTable

Not all primitive types are yet supported simply because they haven't been
needed yet; it should be trivial to add the others as required. At any rate Lua
has only three primitive types -- boolean (int 0 or 1), lua_Numver (double) and
string (NULL-terminated char arrays) -- so any additional types wouldn't
require anything much different from what is already implemented.
*/
template<typename T> class LuaFieldValue: public LuaField {
public:
    /*
    Creates a new field with the given name.
    */
    LuaFieldValue(const std::string &name);

    /*
    Creates a new field with the given name and initial value.
    */
    LuaFieldValue(const std::string &name, const T &value);

    // See LuaField
    virtual operator std::string() const;

    // See LuaField
    virtual LuaField *clone() const;

    // See LuaField
    virtual void push(lua_State *lua) const;

    // See LuaField
    virtual char typeChar() const;

    // Value stored in this field.
    T value;
};

/*
Wrapper for structured data exchanged between a native C++ application and an
embedded Lua execution context.

The main data structure used in the Lua programming language is the "table". A
Lua table can work as either dictionary or array, and contain primitive values
(boolean, number, string) as well as other tables. Furthermore, all data in a
running Lua context is stored in a global stack: all C API functions for data
manipulation work through it -- either by taking the item at the top of the
stack as an implicit argument, or by accepting an index into the stack.

Manipulating Lua tables via the C API can quickly become cumbersome -- one must
be constantly aware of what is at the top of the stack, and any operation on
even moderately complex structures can take quite a bit of pushing and popping
values around.

LuaTable provides an automated mechanism for exchanging structured data between
a C++ host application and a running Lua context. It is a collection of
LuaField objects (separated in named and indexed collections, corresponding to
a Lua table's possible uses as both record and array) which can contain either
primitive values or other LuaTable's; the whole structure can be pushed into a
running Lua context by a single call to the push() method of the top LuaTable
object.

For an example of use, see source file "player/lua/event/class/si.cpp".
*/
class LuaTable {
public:
    /*
    Creates a new LuaTable instance.
    */
    LuaTable();

    /*
    Custom copy-constructor.
    */
    LuaTable(const LuaTable &that);

    /*
    Custom assignment operator.

    This implementation uses the copy-swap idiom with the passing-by-value
    optimization. For details, see [http://www.cplusplus.com/articles/y8hv0pDG/].
    */
    LuaTable &operator = (LuaTable that);

    /*
    Produces a string representation of this table.
    */
    operator std::string() const;

    /*
    Pulls the named value from the record at the given index of the given Lua
    context's global stack.

    If the target record doesn't have a field by the given name, this object is
    left unmodified. Returns whether the operation was successful.
    */
    template<typename T> bool pull(const std::string &name, lua_State *lua, int index);

    /*
    Pulls the named value from the record at the given index of the given Lua
    context's global stack.

    If the target record doesn't have a field by the given name, the field is
    set with the given fallback value. Returns whether the operation was
    successful.
    */
    template<typename T> bool pull(const std::string &name, lua_State *lua, int index, const T &fallback);

    /*
    Pulls the array at the top of the given index of the given Lua context's
    global stack. Returns whether the operation was successful.

    If not all values in the Lua array are of a type compatible to the one
    specified in this call, the method may fail but this object be left with
    some pulled values.
    */
    template<typename T> bool pull(lua_State *lua);

    /*
    Pulls the named array value from the record at the given index of the given
    Lua context's global stack.

    If the target record doesn't have a field by the given name, this object is
    left unmodified (unless argument preset is true, in which case the field is
    set to an empty Table). Returns whether the operation was successful.
    */
    template<typename T> bool pullArray(const std::string &name, lua_State *lua, int index, bool preset = false);

    /*
    Pushes this table to the top of the given Lua context's stack.
    */
    void push(lua_State *lua) const;

    /*
    Adds a copy of the given element to the end of this array.
    */
    template<typename T> void add(const T &value);

    /*
    Adds an empty element to the end of the array and returns a reference to it,
    to the effect that changes to the reference will update the stored value.
    */
    template<typename T> T &add();

    /*
    Checks whether a given field is defined on this Table.
    */
    bool contains(const std::string &name);

    /*
    Returns a vector of copies of all values contained in this array. All values
    must be the same type for this to work.
    */
    template<typename T> std::vector<T> get() const;

    /*
    Returns a copy of the value stored at the given index. If the index isn't
    valid an exception of type out_of_range is thrown.
    */
    template<typename T> const T &get(int index) const;

    /*
    Returns a copy of the current value for the named field. If no field by the
    given name is found, a runtime_error exception is thrown.
    */
    template<typename T> const T &get(const std::string &name) const;

    /*
    Returns a reference to the value stored at the given index, to the effect
    that changes to the reference will update the stored value. If the index
    isn't valid an exception of type out_of_range is thrown.
    */
    template<typename T> T &ref(int index);

    /*
    Returns a reference to a value stored in the named field, to the effect that
    changes to the reference will update the stored value. If no field by the
    given name is found, a new one is created.
    */
    template<typename T> T &ref(const std::string &name);

    /*
    Sets the array cell at the given index to a copy of the given value. If the
    index isn't valid an exception of type out_of_range is thrown. Otherwise,
    the current LuaFieldValue object is discarded and a new one is created in
    its place. This makes it possible to change the type of the cell from one
    assignment to the next.

    For example:

    LuaTable foo;
    foo.add<std::string>("bar"); // First cell in the array is created with string type and value "bar"
    std::string r = foo.get<int>(0); // r == "bar"

    foo.set<int>(0, 8); // Cell is reassigned, type changed to int
    int n = foo.get<int>(0); // n == 8

    std::string s = foo.get<std::string>(0); // Illegal, first cell was last reassigned as int
    */
    template<typename T> void set(int index, const T &value);

    /*
    Sets the value of the named field to a copy of the given value. If this
    field has already been set before, the current LuaFieldValue object is
    discarded and a new one is created in its place. This makes it possible to
    change the type of a named field from one assignment to the next.

    For example:

    LuaTable foo;
    foo.set<std::string>("bar", "FUBAR"); // Field "bar" is created with type std::string
    std::string r = foo.get<int>("bar"); // r == "FUBAR"

    foo.set<int>("bar", 8); // Field "bar" is reassigned, type changed to int
    int n = foo.get<int>("bar"); // n == 8

    std::string s = foo.get<std::string>("bar"); // Illegal, field "bar" was last reassigned as int
    */
    template<typename T> void set(const std::string &name, const T &value);

    /*
     * Convenience method to create a table from a specific string representation
     */
    bool fromString(const std::string &data);

    /*
     * Convenience method to create a specific string representation from this LuaTable
     */
    bool toString(std::string &data);

private:
    /*
    Returns a pointer to the field by the given index, or NULL if the index
    isn't valid.
    */
    LuaField *fetch(size_t index) const;

    /*
    Returns a pointer to the field by the given name, or NULL if it isn't found.
    */
    LuaField *fetch(const std::string &name) const;

    /*
    Pulls a value of given type to the top of the given Lua context's global
    stack. Returns whether the operation was successful.
    */
    template<typename T> bool pull(lua_State *lua, T &value);

    /*
    Recursively build data from string. Used by fromString.
    */
    bool recFromString(const std::string &data, unsigned int &offset);

    // Map storing this record's fields by name.
    LuaFieldMap fields;

    // Vector storing this array's fields.
    LuaFieldArray values;
};

/*
Class for date-time values represented as tables in the Lua environment.
*/
class LuaDateTime: public LuaTable {
public:
    operator time_t() const;

    /*
    Implements assignment from a C date-time value (an integral counting the
    seconds since the epoch) to a Lua date-time object.
    */
    LuaDateTime &operator = (time_t when);

    /*
    Pulls a date-time table value from the top of the given Lua context's global
    stack. Returns whether the operation was successful.
    */
    bool pull(lua_State *lua);
};

/*
A wrapper for access to a registered event handler within a Lua context.
*/
class LuaHandler {
public:
    /*
    Creates a new Lua event handler wrapper.

    Arguments:

    lua
        Pointer to the Lua context where the handler is defined.

    reference
        Reference of the event handler in the Lua context's global stack.

    filter
        Class of the events handled by the registered handler.

    depFilters
        Class dependent filters
    */
	LuaHandler(lua_State *lua, int reference, const std::string &filter, const std::list<std::string> &depFilters);

    virtual ~LuaHandler();

    /*
    Checks whether the handler at the given index (relative to the
    context's passed stack) is the same as the one wrapped in this object.
    */
    bool isEqual(lua_State *L, int index);

	/*
	Returns an event's class dependent filter name list.
	*/
    static const std::list<std::string> depFilter(const std::string &name);
    /*
    Check whether a given event matches the wrapped handler's filter, calling
    the handler on it if positive.

    Returns whether the handler was actually called.
    */
	bool dispatch(const LuaTable &event) const;

	bool dispatchEvent( int ref );

private:
    // Lua context where the wrapped event handler is defined.
	lua_State *const lua;

    // Reference to the wrapped handler.
    // See: http://www.lua.org/manual/5.1/manual.html#luaL_ref
	const int reference;

    // Event filter expression associated to the wrapped handler.
	const std::string filter;

    // Filters associated to this event class
	const std::list<std::string> depFilters;
};

typedef boost::shared_ptr<LuaHandler> LuaHandlerPtr;

typedef std::vector<LuaHandlerPtr> LuaHandlers;

/*
An event exchanged between a C++ host application and a running Lua context.

Implements several convenience methods for more easily dealing with specific
event types (keyboard, pointer, SMS etc).
*/
class LuaEvent: public LuaTable {
public:
    /*
    Default constructor.
    */
    LuaEvent();

    virtual ~LuaEvent() { };

    /*
    Custom copy-constructor.
    */
    LuaEvent(const LuaEvent &that);

    /*
    Creates a new LuaEvent with the given class name.
    */
    LuaEvent(const std::string &name);

    /*
    Convenience constructor for key events.

    Arguments:

    key
        Enum value corresponding to the typed key.

    isUp
        Whether this event resports a key up (true) or down (false).
    */
    LuaEvent(util::key::type key, bool isUp);

    /*
    Convenience constructor for pointer events.

    Arguments:

    touch
        Enum code of the pointer type.

    x
        Horizontal coordinate of the event.

    y
        Vertical coordinate of the event.
    */
    LuaEvent(util::touch::type touch, int x, int y);

    /*
    Convenience constructor for SMS events.

    Arguments:

    from
        Identification of the message's sender.

    port
        Port the message was received from.

    message
        Contents of the message.
    */
    LuaEvent(const std::string &from, const std::string &port, const std::string &message);

    /*
    Convenience constructor for SMS events.

    Arguments:

    to
        Identification of the message's recipient.

    sent
        Result of SMS send event.

    error
        If sent is false, this is en error message. Empty otherwise.

    id
        SMS message id.
    */
    LuaEvent(const std::string &to, const bool &sent, const std::string &error, const std::string &id);

    /*
    Returns this event's class name.
    */
    std::string name() const;

    /*
    Returns a pointer to a copy of this event.
    */
    virtual LuaEvent *clone() const;

    /*
    Dispatches this event to the first matching handler. Alternatively, can be
    overwritten by subclasses to use the given Lua context instead; for an
    example, see source file "player/lua/event/class/ncl.cpp".
    */
    virtual void dispatch(lua_State *lua, LuaHandlers &handlers) const;

    /*
    Convenience methods for Key events
    */

    // Returns whether this is a key event.
    bool isKey() const;

    util::key::type getKey() const;

    bool isUp() const;

    /*
    Convenience methods for Pointer events
    */

    // Returns whether this is a pointer event.
    bool isPointer() const;

    bool isPress() const;

    util::touch::type getTouch() const;

    int getX() const;

    int getY() const;

    /*
    Convenience methods for SI events
    */

    bool isSI() const;

    /*
    Convenience methods for SMS events
    */

    // Returns whether this is a SMS event.
    bool isSMS() const;
};

typedef boost::shared_ptr<LuaEvent> LuaEventPtr;

/*
LuaFieldValue Definitions
*/

template<typename T> LuaFieldValue<T>::LuaFieldValue(const std::string &name):
    LuaField(name),
    value()
{
    // Nothing to do.
}

template<typename T> LuaFieldValue<T>::LuaFieldValue(const std::string &name, const T &_value):
    LuaField(name),
    value(_value)
{
    // Nothing to do.
}

template<typename T> LuaFieldValue<T>::operator std::string() const {
    // Array fields have empty names
    if (name == "") {
        return represent(value);
    }

    return name + "=" + represent(value);
}

template<typename T> LuaField *LuaFieldValue<T>::clone() const {
    return new LuaFieldValue<T>(name, value);
}

template<typename T> void LuaFieldValue<T>::push(lua_State *lua) const {
    LDEBUG("player::event::LuaFieldValue", "Push object: %s", ((std::string) value).c_str());

    value.push(lua);
}

template<> void LuaFieldValue<bool>::push(lua_State *lua) const;

template<> void LuaFieldValue<int>::push(lua_State *lua) const;

template<> void LuaFieldValue<double>::push(lua_State *lua) const;

template<> void LuaFieldValue<std::string>::push(lua_State *lua) const;

template<> char LuaFieldValue<bool>::typeChar() const;
template<> char LuaFieldValue<int>::typeChar() const;
template<> char LuaFieldValue<double>::typeChar() const;
template<> char LuaFieldValue<std::string>::typeChar() const;
template<> char LuaFieldValue<LuaNil>::typeChar() const;
template<> char LuaFieldValue<LuaTable>::typeChar() const;
template<> char LuaFieldValue<LuaDateTime>::typeChar() const;

/*
LuaTable Definitions
*/

template<typename T> bool LuaTable::pull(lua_State *lua, T &value) {
    return value.pull(lua);
}

template<> bool LuaTable::pull(lua_State *lua, bool &value);

template<> bool LuaTable::pull(lua_State *lua, int &value);

template<> bool LuaTable::pull(lua_State *lua, double &value);

template<> bool LuaTable::pull(lua_State *lua, std::string &value);

template<typename T> bool LuaTable::pull(lua_State *lua) {
	for (int i = 0, n = luaL_getn(lua, -1); i < n; i++) {
        lua_rawgeti(lua, -1, i + 1);
        if (lua_isnil(lua, -1)) {
            return false;
        }

        T value;
        bool ok = pull<T>(lua, value);
        lua_pop(lua, 1);
        if (!ok) {
            lua_pop(lua, 1); // Pops the array out of the stack
            return false;
        }

        add<T>(value);
	}

    lua_pop(lua, 1); // Pops the array out of the stack
    return true;
}

template<typename T> bool LuaTable::pull(const std::string &name, lua_State *lua, int index) {
	lua_getfield(lua, index, name.c_str());
	if (lua_isnil(lua, -1)) {
		return false;
	}

    T value;
    bool ok = pull<T>(lua, value);
    lua_pop(lua, 1);
    if (!ok) {
        return false;
    }

	set<T>(name, value);
	return true;
}

#define pullRequired(TABLE, TYPE, NAME, LUA, INDEX) \
    if (!TABLE.pull<TYPE>(NAME, LUA, INDEX)) { \
        std::string tag = "[player::lua::event]"; \
        std::string err = util::format("Could not pull field \"%s\" as type \"%s\"", std::string(NAME).c_str(), #TYPE); \
        LDEBUG(tag.c_str(), err.c_str()); \
        return tag + " " + err; \
    }

template<typename T> bool LuaTable::pull(const std::string &name, lua_State *lua, int index, const T &fallback) {
    bool ok = pull<T>(name, lua, index);
    if (!ok) {
        set<T>(name, fallback);
    }

    return ok;
}

template<typename T> bool LuaTable::pullArray(const std::string &name, lua_State *lua, int index, bool preset) {
    if (preset) {
        ref<LuaTable>(name);
    }

	lua_getfield(lua, index, name.c_str());
	if (lua_isnil(lua, -1)) {
		return false;
	}

    return ref<LuaTable>(name).pull<T>(lua);
}

template<typename T> void LuaTable::add(const T &value) {
    LuaFieldPtr pointer(new LuaFieldValue<T>("", value));
    values.push_back(pointer);
}

template<typename T> T &LuaTable::add() {
    add(T());
    LuaFieldValue<T> *field = (LuaFieldValue<T>*) values.back().get();
    return field->value;
}

template<typename T> std::vector<T> LuaTable::get() const {
    std::vector<T> copy;
    copy.reserve(values.size());
    for (LuaFieldArray::const_iterator i = values.begin(), n = values.end(); i != n; ++i) {
        const LuaFieldValue<T> *field = (LuaFieldValue<T>*) i->get();
        copy.push_back(field->value);
    }

    return copy;
}

template<typename T> const T &LuaTable::get(int index) const {
    LuaFieldValue<T> *field = (LuaFieldValue<T>*) fetch(index);
    return field->value;
}

template<typename T> const T &LuaTable::get(const std::string &name) const {
    LuaFieldValue<T> *field = (LuaFieldValue<T>*) fetch(name);
    if (field == NULL) {
        throw std::runtime_error(std::string() + "Field \"" + name + "\" not found");
    }

    return field->value;
}
template<typename T> T &LuaTable::ref(int index) {
    LuaFieldValue<T> *field = (LuaFieldValue<T>*) fetch(index);
    return field->value;
}

template<typename T> T &LuaTable::ref(const std::string &name) {
    LuaFieldValue<T> *field = (LuaFieldValue<T>*) fetch(name);
    if (field == NULL) {
        field = new LuaFieldValue<T>(name);
        fields[name].reset(field);
    }

    return field->value;
}

template<typename T> void LuaTable::set(int index, const T &value) {
    values.at(index).reset(new LuaFieldValue<T>("", value));
}

template<typename T> void LuaTable::set(const std::string &name, const T &value) {
    fields[name].reset(new LuaFieldValue<T>(name, value));
}

template<> std::string represent(const LuaTable &value);

//	Callbacks
typedef boost::function<void(
	evtType::type type,
	evtAction::type action,
	const std::string &parameter,
	const std::string &value)> Callback;

typedef boost::function<void (const LuaEvent&)> InputCallback;

class Module;

//	getters
evtType::type getEventType(const std::string &name);
evtAction::type getEventAction(const std::string &name);
const char *getActionName( evtAction::type action );

}
}
