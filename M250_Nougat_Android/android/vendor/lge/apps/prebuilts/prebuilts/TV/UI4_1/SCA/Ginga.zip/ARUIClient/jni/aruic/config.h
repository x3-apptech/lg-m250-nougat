#include <string>

namespace aruic {
namespace config {

void setPort(std::string port);

std::string getPort();

} // namespace config
} // namespace aruic
