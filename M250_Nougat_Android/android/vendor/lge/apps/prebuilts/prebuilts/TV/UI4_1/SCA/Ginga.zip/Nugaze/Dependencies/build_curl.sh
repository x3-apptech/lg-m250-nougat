#!/bin/bash

. build_setup.sh
CPPFLAGS="${CPPFLAGS} -I${CWD}/include"
LDFLAGS="-L${CWD}/lib"
LIBS="-lz"

CURL="curl-7.30.0"
extract_sources $CURL
STAGE=$(make_stagedir)

./configure CC="$CC" CPPFLAGS="$CPPFLAGS" LDFLAGS="$LDFLAGS" LIBS="$LIBS" --host arm-linux --prefix=$STAGE --exec-prefix=$STAGE \
    --disable-tftp --disable-sspi --disable-ipv6 --disable-ldaps --disable-ldap --disable-telnet \
    --disable-pop3 --disable-ftp --with-ssl=$TOOLS/android-openssl --disable-imap --disable-smtp \
    --disable-pop3 --disable-rtsp --disable-ares --without-ca-bundle --disable-warnings --disable-manual \
    --without-nss --enable-shared --without-random

make $MAKE_JOBS $MAKE_LOAD
make install
copy_binaries $STAGE
