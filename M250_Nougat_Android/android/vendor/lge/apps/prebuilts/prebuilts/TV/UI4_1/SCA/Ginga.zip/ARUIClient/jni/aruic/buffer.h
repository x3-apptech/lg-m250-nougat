#pragma once

#include <string>

namespace aruic {

	typedef unsigned int DWORD;

	class Buffer {
	public:
		//	Constructors
		Buffer( void );
		explicit Buffer( int blockSize );
		Buffer( const Buffer &other );
		Buffer( const char *buf, int len, bool owner=true );
		virtual ~Buffer( void );

		//	Operators
		Buffer &operator=( const Buffer &other );
		bool operator==( const Buffer &other ) const;

		//	Getters
		int length() const;
		int capacity() const;
		int blockSize() const;
		char *buffer() const;
		operator const char*( void );
		char &operator[]( int pos );
		std::string asHexa( void ) const;
		template<class Operand> inline void format( Operand &oper )const;

		//	Operations
		void resize( int len );
		void append( const char *buf, int len );
		void copy( const char *buf, int len );
		void copy( int pos, const char *buf, int len );
		void assign( const char *buf, int len );
		void swap( Buffer &other );

		//	User data
		void setUserData( void *data );
		void *getUserData() const;

	protected:
		void clear( void );
		void makeSpace( int len, bool copy );

	private:
		char *_buf;
		bool  _owner;
		int   _length;
		int   _bufLen;
		int   _blockSize;
		void *_userData;
	};

	template<class Operand>
	inline void Buffer::format( Operand &oper ) const {
		for (int i=0; i<_length; ++i) {
			oper( _buf[i] );
		}
	}

}

