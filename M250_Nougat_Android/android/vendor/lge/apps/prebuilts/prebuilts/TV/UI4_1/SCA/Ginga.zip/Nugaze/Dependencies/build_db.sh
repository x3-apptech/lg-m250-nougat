#!/bin/bash

. build_setup.sh

NAME="db-5.1.29"
extract_sources $NAME
STAGE=$(make_stagedir)

cd build_unix
export CC
../dist/configure --host=arm-linux-androideabi --disable-shared --prefix=$STAGE

make $MAKE_JOBS $MAKE_LOAD
make install
cd ..
copy_binaries $STAGE
