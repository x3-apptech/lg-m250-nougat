#pragma once
#include <map>
#include <string>
#include <vector>

typedef struct lua_State lua_State;

namespace player {

class LuaPlayer;

namespace settings {

class PropertyTable
{
public:
	PropertyTable( const std::string& name );
	virtual ~PropertyTable() {};
	typedef std::pair<std::string,void*> PropTableMethods;
	typedef std::vector<std::string> PropName;
	typedef std::vector<PropTableMethods> PropMethod;
	typedef void* VoidPtr;

	int addProperty( const std::string& name );
	int addMetaMethod( const std::string& name, void* value );

	PropName *getProperties() { return &_properties; }
	PropMethod *getMethods() { return &_methods; }

private:
	PropName _properties;
	PropMethod _methods;
};

class Module
{
public:
	Module( LuaPlayer *player, lua_State *lua );
	virtual ~Module();

	static Module *get( lua_State *st );
	bool isReadOnly( void );
	void update( void );

	static int toConcat( lua_State *st, std::string& parameter );
	static int toString( lua_State *st, std::string& parameter );
	static int toCall( lua_State *st, std::string& parameter );

protected:
	void exportTable( void );
	void readOnly( bool value );

private:
	LuaPlayer *_player;
	lua_State *_lua;
	bool _readOnly;
};

}
}
