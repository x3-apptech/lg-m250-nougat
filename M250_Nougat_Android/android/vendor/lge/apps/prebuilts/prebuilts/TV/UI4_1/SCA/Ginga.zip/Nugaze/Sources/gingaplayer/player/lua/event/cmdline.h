#include "../../../system.h"

namespace player {
namespace event {

void pollCmdLine(System *system);

/**
 * call this when you want pollCmdLine thread to finish
 * by itself
 */
extern void endCmdLinePoller();

} // namespace event
} // namespace player
