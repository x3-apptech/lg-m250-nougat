#include "types.h"

#include "translators.h"
#include "opcodes.h"

namespace aruic {
namespace mediaplayer {

void newMediaPlayer(void *id) {
	invoke(id, IPC_MEDIA_PLAYER_NEW).call();
}

void deleteMediaPlayer(void *id) {
	invoke(id, IPC_DELETE).call();
}

bool initialize(void *id, const Rect &rect, const std::string &url) {
	return invoke(id, IPC_MEDIA_PLAYER_INIT_RECT).set(rect).set(url).call().get<bool>();
}

bool initialize(void *id, const std::string &url) {
	return invoke(id, IPC_MEDIA_PLAYER_INIT).set(url).call().get<bool>();
}

void finalize(void *id) {
	invoke(id, IPC_MEDIA_PLAYER_FINALIZE).call();
}

void play(void *id) {
	invoke(id, IPC_MEDIA_PLAYER_PLAY).call();
}

void stop(void *id) {
	invoke(id, IPC_MEDIA_PLAYER_STOP).call();
}

void pause(void *id, bool needPause) {
	invoke(id, IPC_MEDIA_PLAYER_PAUSE).set(needPause).call();
}

void mute(void *id, bool needMute) {
	invoke(id, IPC_MEDIA_PLAYER_MUTE).set(needMute).call();
}

void volume(void *id, float vol) {
	invoke(id, IPC_MEDIA_PLAYER_VOLUME).set(vol).call();
}

void move(void *id, const Point &point) {
	invoke(id, IPC_MEDIA_PLAYER_MOVE).set(point).call();
}

void resize(void *id, const Size &size) {
	invoke(id, IPC_MEDIA_PLAYER_RESIZE).set(size).call();
}

} // namespace mediaplayer
} // namespace aruic
