#include "types.h"

#include <string>
#include <vector>

namespace aruic {
namespace surface {

void newSurface(void *id, Canvas *canvas, const aruic::Rect &rect);
void newSurface(void *id, Canvas *canvas, const std::string &file, aruic::Size &size);
void deleteSurface(void *id);

void setClip(void *id, const aruic::Rect &rect);
void getClip(void *id, aruic::Rect &rect);

int fontAscent(void *id);
int fontDescent(void *id);
bool applyFont(void *id, const aruic::Font font, int &ascent, int &descent);

void setColor(void *id, const aruic::Color &color);

void setOpacity(void *id, int alpha);

void drawLine(void *id, int x1, int y1, int x2, int y2);
void drawRect(void *id, const Rect &rect);
void fillRect(void *id, const Rect &rect);
void drawRoundRect(void *id, const Rect &rect, int arcW, int arcH);
void fillRoundRect(void *id, const Rect &rect, int arcW, int arcH);
void drawPolygon(void *id, const std::vector<Point>& vertices, bool closed);
void fillPolygon(void *id, const std::vector<Point>& vertices);
void drawEllipse(void *id, const Point &center, int rw, int rh, int angStart, int angStop);
void fillEllipse(void *id, const Point &center, int rw, int rh, int angStart, int angStop);

void drawText(void *id, const Point &pos, const std::string &text, int ascent);
void drawTextBox(void *id, const Rect &rect, const std::string &text, int alignment, int spacing, const Color bgColor);
void measureText(void *id, const std::string &text, Size &size);

void setCompositionMode(void *id, const std::string &mode);
void clear(void *id, const Rect &rect);
void blit(void *id, const Point &target, const Surface *srcSurface, const Rect &source);
void blit(void *id, const std::vector<Point> &targets, const std::vector<Surface*> &srcSurfaces, const std::vector<Rect> &sources);
void scale(void *id, const Rect &targetRect, const Surface *srcSurface, const Rect &sourceRect, bool flipw, bool fliph);
void rotate(void *id, int degrees, const Surface *surface);
void resize(void *id, const Size &size, bool scaleContent);

void getPixelColor(void *id, const Point &pos, Color &color);
void setPixelColor(void *id, const Point &pos, const Color &color);
int getPixel(void *id, const Point &pos);

bool saveAsImage(void *id, const std::string &file);

} // namespace surface
} // namespace aruic
