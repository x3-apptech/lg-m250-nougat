#pragma once

#include "types.h"
#include "canvas/types.h"
#include "util/id/ident.h"
#include "util/touch.h"

typedef struct lua_State lua_State;

namespace util {
namespace net {
	class Socket;
}
}

namespace player {

class System;
class LuaPlayer;

namespace event {

class DispatchOutInfo;

class Module {
public:
	Module( System *sys, LuaPlayer *player, lua_State *lua );
	virtual ~Module();

	//	Initialization
	void setCallback( const Callback &callback );
	void setInputEventCallback( const InputCallback &callback );

	//	Lua player methods
	void dispatchKey( util::key::type key, bool isUp );
	void dispatchPointer(util::touch::type touch, int x, int y);
	void dispatchPresentation( evtAction::type action, const std::string &label );
	void dispatchAttribution( const std::string &name, evtAction::type action, const std::string &value );

	//	Dispatch methods
	typedef boost::shared_ptr<DispatchOutInfo> DispatchOutInfoPtr;

	void dispatchIn(const LuaEvent &event, bool isInternal);
	void dispatchInCallback( int ref, util::id::Ident &timerID );
	void dispatchOut(
		evtType::type type,
		evtAction::type action,
		const std::string &parameter,
		const std::string &value );
	void dispatchOutCallback( DispatchOutInfoPtr dispatchInfo, util::id::Ident &timerID );

	//	Lua methods (Internal use)
	std::string postEvent( lua_State *L, const std::string &evtClass, bool isOut, int eventPos );
	int addHandler( lua_State *L, int pos, int method, const std::string &classFilter,
			const std::list<std::string> &classDependent );
	void removeHandler( lua_State *L, int index );
	util::DWORD uptime() const;

	//	Timer
	typedef std::pair<util::id::Ident,int> TimerRef;
	typedef std::vector<TimerRef> TimerList;
	void registerTimer( lua_State *L, util::DWORD ms );
	void cancelTimer( int timerRef );
	void cancelTimer( util::id::Ident &id, bool needUnregister );

	//	Socket
	typedef std::map<util::id::Ident,util::net::Socket *> SocketList;
	util::id::Ident connect( const std::string &host, const std::string &port, util::DWORD timeout=0 );
	bool disconnect( util::id::ID_TYPE socketID );
	bool send( util::id::ID_TYPE socketID, const std::string &data, util::DWORD timeout=0 );

	//	Aux
	static Module *get( lua_State *st );

protected:
	typedef std::string (*PostEventMethod)( System *system, lua_State *st, bool isOut, int eventPos );
	typedef std::map<std::string,PostEventMethod> Classes;

	//	Timers
	void cancelTimerAux( TimerList::iterator &it, bool unregister );
	void onTimerExpired( util::id::Ident &timerID );

	//	Sockets
	void disconnect( SocketList::iterator &it );
	void onDataReceived( util::id::Ident &socketID );

private:
	System *_sys;
	LuaPlayer *_player;
	lua_State *_lua;
	Callback _callback;
	InputCallback _inCallback;
	Classes _classes;
	LuaHandlers _handlers;
	LuaHandlers _handlersToRemove;

	SocketList _sockets;
	TimerList _timers;
};

}	// namespace event
}	// namespace player

