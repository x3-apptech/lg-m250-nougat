#pragma once

#include "buffer.h"

#include <string>
#include <vector>

#include "ipc_socket.h"

namespace aruic {

class ipc {
public:
    ipc(int opcode);
    ~ipc();

    ipc &call();

    ipc &get(int &value);

    ipc &get(std::string &value);

    template<typename T> T get();

    template<typename T> ipc &get(T &value);

    template<typename T> ipc &get(std::vector<T> &values);

    ipc &set(int value);

    ipc &set(float value);

    ipc &set(const std::string &value);

    template<typename T> ipc &set(const T &value);

    template<typename T> ipc &set(const T *value);

    template<typename T> ipc &set(const std::vector<T> &values);

private:
    Buffer *_buffer;
    ipc_socket &_socket;
};

class invoke: public ipc {
public:
    invoke(const void *id, int opcode);
};

template<typename T> T ipc::get() {
    T value;
    get(value);
    return value;
}

template<> std::string ipc::get();

template<> bool ipc::get();

template<typename T> ipc &ipc::get(T &value) {
    get((int&) value);
    return *this;
}

template<typename T> ipc &ipc::get(std::vector<T> &values) {
    for (int i = 0, n = get<int>(); i < n; i++) {
        values.push_back(get<T>());
    }

    return *this;
}

template<typename T> ipc &ipc::set(const T &value) {
    return set((int) value);
}

template<typename T> ipc &ipc::set(const T *value) {
    return set((int) value);
}

template<typename T> ipc &ipc::set(const std::vector<T> &values) {
    set((int) values.size());
    for (typename std::vector<T>::const_iterator i = values.begin(), n = values.end(); i != n; ++i) {
        set(*i);
    }

    return *this;
}

}
