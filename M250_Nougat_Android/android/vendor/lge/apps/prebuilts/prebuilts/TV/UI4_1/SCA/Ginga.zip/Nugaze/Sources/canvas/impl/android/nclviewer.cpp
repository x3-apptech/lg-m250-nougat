#include "nclviewer.h"
#include "../../canvas.h"
#include "../../size.h"
#include "../../system.h"
#include <util/log.h>

#include "../../point.h"
#include "../../surface.h"
#include "window.h"
#include <boost/thread/thread.hpp>

namespace canvas {
namespace android {

NclViewer::NclViewer( canvas::System *sys, canvas::Surface *surface):
    canvas::NclViewer(sys, surface)
{
	LDEBUG("android::NclViewer", "NclViewer(System = %p, Surface = %p)", sys, surface);
	_window = NULL;
}

NclViewer::~NclViewer(void) {
	stop();
	LDEBUG("android::NclViewer", "~NclViewer(void)");
}

void NclViewer::resize(const Size &size) {
	LWARN("android::NclViewer", "resize(%d,%d) - not implemented", size.w, size.h);
	//aruic::window::setSize();
}

void NclViewer::move(const Point &point) {
	LWARN("android::NclViewer", "move(%d,%d) - not implemented", point.x, point.y);
	//aruic::window::move();
}

void NclViewer::stop() {
	if (_window) {
		LINFO("NclViewer", "Stop page");
		delete _window;
		_window = NULL;
	}
}

void *NclViewer::prepare() {
	LDEBUG("android::NclViewer", "prepare()");
	const Size &s = surface()->getSize();
	canvas::Point point = this->surface()->getLocation();
	canvas::Rect position(point.x, point.y, s.w, s.h);
	_window = _sys->window();
	// TODO: set position and size
	return (void*)_window;
}

void NclViewer::draw() {
	// TODO: multi-thread access to srcSurface may need to be mutex protected
	LDEBUG("android::NclViewer", "draw()");
	canvas::Surface* srcSurface = getSurface();
	if (!srcSurface) {
		LWARN("android::NclViewer", "no Surface to draw");
		return;
	}
	this->surface()->setCompositionMode( composition::source );
	this->surface()->blit(canvas::Point(0,0), srcSurface);
	this->surface()->markDirty();
	this->surface()->flush();
}

void NclViewer::dispatch(const player::event::LuaEvent &event) {
    LDEBUG("NclViewer", "Received %s", ((std::string) event).c_str());
}

void NclViewer::dispatchKey( util::key::type key, bool isUp ) {
    LDEBUG("NclViewer", "dispatchKey (%d, isUp=%d)", key, isUp);
}

}
}
