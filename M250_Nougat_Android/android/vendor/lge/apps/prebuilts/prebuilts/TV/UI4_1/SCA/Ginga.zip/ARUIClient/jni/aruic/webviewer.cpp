#include "webviewer.h"

#include "translators.h"
#include "opcodes.h"

namespace aruic {
namespace webviwer {

void newWebViewer(void * id, Surface *surface) {
	invoke(id, IPC_WEBVIEWER_NEW).set(surface).call();
}

void deleteWebViewer(void * id) {
	invoke(id, IPC_DELETE).call();
}

bool load(void * id, const std::string &file) {
	return invoke(id, IPC_WEBVIEWER_LOAD).set(file).call().get<bool>();
}

void stop(void * id) {
	invoke(id, IPC_WEBVIEWER_STOP).call();
}

void draw(void * id) {
	invoke(id, IPC_WEBVIEWER_DRAW).call();
}

void dispatchKey(void * id, const std::string &key, bool isUp) {
	invoke(id, IPC_WEBVIEWER_DISPATCH_KEY).set(key).set(isUp).call();
}

void dispatchPointer(void * id, const std::string &touch, int x, int y) {
	invoke(id, IPC_WEBVIEWER_DISPATCH_PTR).set(touch).set(x).set(y).call();
}

} // namespace webviwer
} // namespace aruic
