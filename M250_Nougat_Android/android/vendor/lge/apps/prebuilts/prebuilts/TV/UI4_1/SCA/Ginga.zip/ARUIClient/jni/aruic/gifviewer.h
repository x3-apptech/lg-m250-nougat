#include "types.h"

#include <string>

namespace aruic {
namespace gifviewer {

void newGifViewer(void * id, Surface *surface);
void deleteGifViewer(void * id);

bool load(void * id, const std::string &file);
void stop(void * id);
int draw(void * id);
void setFreeze(void* id, bool freeze);
int getDuration(void * id);

} // namespace gifviewer
} // namespace aruic
