#include "surface.h"

#include "translators.h"
#include "opcodes.h"

namespace aruic {
namespace surface {

void newSurface(void *id, Canvas *canvas, const aruic::Rect &rect) {
	invoke(id, IPC_SURFACE_NEW_RECT).set(canvas).set(rect).call();
}

void newSurface(void *id, Canvas *canvas, const std::string &file, aruic::Size &size) {
	invoke(id, IPC_SURFACE_NEW_FILE).set(canvas).set(file).call().get(size);
}

void deleteSurface(void *id) {
	invoke(id, IPC_DELETE).call();
}

void setClip(void *id, const aruic::Rect &rect) {
	invoke(id, IPC_SURFACE_SET_CLIP).set(rect).call();
}

void getClip(void *id, aruic::Rect &rect) {
	invoke(id, IPC_SURFACE_GET_CLIP).call().get(rect).get<bool>();
}

int fontAscent(void *id) {
	return invoke(id, IPC_SURFACE_FONT_ASCENT).call().get<int>();
}

int fontDescent(void *id) {
	return invoke(id, IPC_SURFACE_FONT_DESCENT).call().get<int>();
}

bool applyFont(void *id, const aruic::Font font, int &ascent, int &descent) {
	return invoke(id, IPC_SURFACE_APPLY_FONT).set(font).call().get(ascent).get(descent).get<bool>();
}

void setColor(void *id, const aruic::Color &color) {
	invoke(id, IPC_SURFACE_SET_COLOR).set(color).call();
}

void setOpacity(void *id, int alpha) {
	invoke(id, IPC_SURFACE_SET_OPACITY).set(alpha).call().get<bool>();
}

void drawLine(void *id, int x1, int y1, int x2, int y2) {
	invoke(id, IPC_SURFACE_DRAW_LINE)
		.set(x1).set(y1)
		.set(x2).set(y2)
	.call();
}

void drawRect(void *id, const Rect &rect) {
	invoke(id, IPC_SURFACE_DRAW_RECT).set(rect).call();
}

void fillRect(void *id, const Rect &rect) {
	invoke(id, IPC_SURFACE_FILL_RECT).set(rect).call();
}

void drawRoundRect(void *id, const Rect &rect, int arcW, int arcH) {
	invoke(id, IPC_SURFACE_DRAW_ROUND_RECT)
		.set(rect)
		.set(arcW)
		.set(arcH)
	.call();
}

void fillRoundRect(void *id, const Rect &rect, int arcW, int arcH) {
	invoke(id, IPC_SURFACE_FILL_ROUND_RECT)
		.set(rect)
		.set(arcW)
		.set(arcH)
	.call();
}

void drawPolygon(void *id, const std::vector<Point>& vertices, bool closed) {
	invoke(id, IPC_SURFACE_DRAW_POLYGON)
		.set(vertices)
		.set(closed)
	.call();
}

void fillPolygon(void *id, const std::vector<Point>& vertices) {
	invoke(id, IPC_SURFACE_FILL_POLYGON)
		.set(vertices)
	.call();
}

void drawEllipse(void *id, const Point &center, int rw, int rh, int angStart, int angStop) {
	invoke(id, IPC_SURFACE_DRAW_ELLIPSE)
		.set(center)
		.set(rw)
		.set(rh)
		.set(angStart)
		.set(angStop)
	.call();
}

void fillEllipse(void *id, const Point &center, int rw, int rh, int angStart, int angStop) {
	invoke(id, IPC_SURFACE_FILL_ELLIPSE)
		.set(center)
		.set(rw)
		.set(rh)
		.set(angStart)
		.set(angStop)
	.call();
}

void drawText(void *id, const Point &pos, const std::string &text, int ascent) {
	invoke(id, IPC_SURFACE_DRAW_TEXT)
		.set(pos)
		.set(text)
		//.set(ascent) // parameter not needed
	.call();
}

void drawTextBox(void *id, const Rect &rect, const std::string &text, int alignment, int spacing, const Color bgColor) {
	invoke(id, IPC_SURFACE_DRAW_TEXT_BOX)
		.set(rect)
		.set(text)
		.set(alignment)
		.set(spacing)
		.set(bgColor)
	.call();
}

void measureText(void *id, const std::string &text, Size &size) {
	invoke(id, IPC_SURFACE_MEASURE_TEXT).set(text).call().get(size);
}

void setCompositionMode(void *id, const std::string &mode) {
	invoke(id, IPC_SURFACE_SET_COMP_MODE)
		.set(mode)
	.call();
}

void clear(void *id, const Rect &rect) {
	invoke(id, IPC_SURFACE_CLEAR_RECT)
		.set(rect)
	.call();
}

void blit(void *id, const Point &target, const Surface *srcSurface, const Rect &source) {
	invoke(id, IPC_SURFACE_BLIT)
		.set(target)
		.set(srcSurface)
		.set(source)
	.call();
}

void blit(void *id, const std::vector<Point> &targets, const std::vector<Surface*> &srcSurfaces, const std::vector<Rect> &sources) {
	invoke(id, IPC_SURFACE_MULTI_BLIT)
		.set(targets)
		.set(srcSurfaces)
		.set(sources)
	.call();
}

void scale(void *id, const Rect &targetRect, const Surface *srcSurface, const Rect &sourceRect, bool flipw, bool fliph) {
	invoke(id, IPC_SURFACE_SCALE)
		.set(targetRect)
		.set(srcSurface)
		.set(sourceRect)
		.set(flipw)
		.set(fliph)
	.call();
}

void rotate(void *id, int degrees, const Surface *surface) {
	invoke(id, IPC_SURFACE_ROTATE)
		.set(degrees)
		.set(surface)
	.call();
}

void resize(void *id, const Size &size, bool scaleContent) {
	invoke(id, IPC_SURFACE_RESIZE)
		.set(size)
		.set(scaleContent)
	.call();
}

void getPixelColor(void *id, const Point &pos, Color &color) {
	invoke(id, IPC_SURFACE_GET_PIXEL_COLOR).set(pos).call().get(color);
}

void setPixelColor(void *id, const Point &pos, const Color &color) {
	invoke(id, IPC_SURFACE_SET_PIXEL_COLOR)
		.set(pos)
		.set(color)
	.call();
}

int getPixel(void *id, const Point &pos) {
	return invoke(id, IPC_SURFACE_GET_PIXEL)
		.set(pos)
	.call().get<int>();
}

bool saveAsImage(void *id, const std::string &file) {
	return invoke(id, IPC_SURFACE_SAVE_AS_IMAGE).set(file).call().get<bool>();
}

} // namespace surface
} // namespace aruic
