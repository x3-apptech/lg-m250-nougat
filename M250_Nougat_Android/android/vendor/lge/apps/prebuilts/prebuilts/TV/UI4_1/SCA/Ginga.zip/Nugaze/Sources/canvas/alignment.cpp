#include "alignment.h"

namespace canvas {
namespace alignment {

#define TO_STRING(ALIGNMENT) case ALIGNMENT: return #ALIGNMENT

const char* getName(int value) {
    switch (value) {
        TO_STRING(None);
        TO_STRING(vTop);
        TO_STRING(vCenter);
        TO_STRING(vBottom);
        TO_STRING(hLeft);
        TO_STRING(hCenter);
        TO_STRING(hRight);
    }

    return "(Unknown alignment)";
}

}
}
