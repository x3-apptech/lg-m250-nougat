#pragma once

#include <string>
#include <vector>

namespace aruic {

typedef char BYTE;

typedef void Canvas;
typedef void Window;
typedef void Surface;

class Rect {
public:
	int x;
	int y;
	int w;
	int h;
};

class Point {
public:
	int x;
	int y;
};

class Size {
public:
	int w;
	int h;
};

class Color {
public:
	int r;
	int g;
	int b;
	int alpha;
};

class Font {
public:
	std::vector<std::string> families;
	int size;
	bool bold;
	bool italic;
	bool smallCaps;
};

} // namespace aruic
