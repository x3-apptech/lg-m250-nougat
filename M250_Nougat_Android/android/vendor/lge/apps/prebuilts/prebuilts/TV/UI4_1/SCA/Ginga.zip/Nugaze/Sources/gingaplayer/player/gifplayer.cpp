#include "gifplayer.h"
#include <limits.h>
#include "../device.h"
#include <canvas/gifviewer.h>
#include <util/mcr.h>
#include <boost/bind.hpp>
#include "../property/forwardproperty.h"
#include "../property/propertyimpl.h"
#include "../../canvas/system.h"

namespace player {

GifPlayer::GifPlayer( Device *dev )
	: GraphicPlayer( dev )
{
	_freeze = false;
	_frametimer = new TimeLineTimer( dev->systemPlayer() );
}

GifPlayer::~GifPlayer()
{
	delete _frametimer;
}

bool GifPlayer::startPlay() {
	bool result=false;
	if (GraphicPlayer::startPlay()) {
		//	Create gif viewer
		_gif = device()->createGifViewer( surface() );
		if (_gif) {
			//	Load url
			_gif->load( body() );
			adjustDuration();
			_frametimer->start();
			result=true;
		}
	}
	return result;
}


void GifPlayer::stopPlay() {
	_frametimer->stop();
	_gif->stop();
	GraphicPlayer::stopPlay();
	DEL(_gif);
}

//	Events
void GifPlayer::onSizeChanged( const canvas::Size &size ) {
	_gif->resize( size );
}

void GifPlayer::onPositionChanged( const canvas::Point &point ) {
	_gif->move( point );
}

void GifPlayer::refresh() {
	int delay_ms = _gif->draw();
	LDEBUG("GifPlayer","%p draw() -> %d", this, delay_ms);
	if (delay_ms <= 0) {
		// error or end of media
		stop();
	} else {
		// schedule next frame
		_next_frame_time_ms = delay_ms;
		_frametimer->addTimer(_next_frame_time_ms,boost::bind(&GifPlayer::onTimerExpired,this,_next_frame_time_ms));
	}
}

bool GifPlayer::supportRemote() const {
	return true;
}

void GifPlayer::registerProperties() {
	GraphicPlayer::registerProperties();

	{
		ForwardProperty<SelectionEventData> *prop =
			new ForwardProperty<SelectionEventData>( boost::bind(&GifPlayer::sendKeyEvent, this, _1) );
		addProperty( property::type::selectionEvent, prop );
	}
	{
		PropertyImpl<bool> *prop=new PropertyImpl<bool>( false, _freeze );
		prop->setApply( boost::bind(&GifPlayer::applyFreeze, this) );
		addProperty( property::type::freeze, prop );
	}
}

void GifPlayer::sendKeyEvent( const SelectionEventData &data ) {
	LINFO("GifPlayer", "selection event");
	// do nothing
}

void GifPlayer::applyFreeze() {
	LDEBUG("GifPlayer","applyFreeze: _freeze = %d", _freeze);
	_gif->setFreeze(_freeze);
	adjustDuration();
}

/**
 * Note that we should not need to control duration with _gif_duration and timer, as the
 * draw method shall return 0 when media is completed. But we are doing it for safety.
 */
void GifPlayer::adjustDuration() {
	_gif_duration = (_freeze ? INT_MAX /*infinite*/ : _gif->getDuration());
	LDEBUG("GifPlayer","setting gif duration to %d (freeze = %d)", _gif_duration, _freeze);
	if (_gif_duration > 0 && _gif_duration < INT_MAX)
		createTimer(_gif_duration,boost::bind(&GifPlayer::onTimerExpired,this,_gif_duration));
}

void GifPlayer::onTimerExpired(int time) {
	LDEBUG("GifPlayer","timer expired: now %d, duration %d", time, _gif_duration);
	if (time == _gif_duration)
		stop();
	else if (time == _next_frame_time_ms && isPlaying()) {
		device()->system()->enqueue(boost::bind(&GifPlayer::refresh,this));
	}
}

bool GifPlayer::isApplication() const {
	return false;
}

}
