#!/bin/bash

. build_setup.sh

NAME="valgrind-3.8.1"
extract_bz2 $NAME
cd $NAME

./autogen.sh

./configure CC="$CC" CXX="$CXX" CPPFLAGS="-DANDROID_HARDWARE_generic" --prefix=/data/local/valdroid --host=armv7-unknown-linux --target=armv7-unknown-linux --with-tmpdir=/sdcard

make $MAKE_JOBS $MAKE_LOAD
make $MAKE_JOBS $MAKE_LOAD install DESTDIR=`pwd`/android
