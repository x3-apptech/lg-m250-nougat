#include "user.h"
#include "../event.h"
#include "../../lua.h"
#include <canvas/system.h>

namespace player {
namespace event {
namespace user {

std::string postEvent(System *sys, lua_State *st, bool /*isOut*/, int eventPos) {
	//	Get event module from stack
	Module *module = Module::get(st);
	if (!module) {
		return "[event::ncl] Invalid event module";
	}

	LuaEvent event;
	lua_pushnil(st);  // First key
	while (lua_next(st, eventPos) != 0) {
		const char *key=lua_tostring(st,-2);
		const char *value=lua_tostring(st,-1);
		event.set<std::string>(key, value);

		//	Removes 'value'; keeps 'key' for next iteration
		lua_pop(st, 1);
	}

	//	Dispatch table to user
	dispatchUser(*module, event);

	return "";
}

void dispatchUser(Module &module, LuaEvent &event) {
	module.dispatchIn(event, true);
}

}
}
}
