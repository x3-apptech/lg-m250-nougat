#include "system.h"

#include <map>
#include <string>
#include <vector>

#include "util/cfg/cfg.h"
#include "util/keydefs.h"
#include "util/log.h"
#include "util/string_utils.h"

#include <aruic/input.h>
#include <aruic/config.h>

#include "gifviewer.h"
#include "nclviewer.h"

namespace canvas {
namespace android {

static void dispatchKey(System *system, std::vector<std::string> &event) {
    std::string keyName = event.at(1);
    std::string state = event.at(2);

    util::key::type keyValue = util::key::getKey(keyName.c_str());
    bool isUp = (state == "true");

    system->dispatch(player::event::LuaEvent(keyValue, isUp));
}

static void dispatchPointer(System *system, std::vector<std::string> &event) {
    util::touch::type touch = util::touch::getTouch(event.at(1).c_str());
    int x = util::from_string<int>(event.at(2));
    int y = util::from_string<int>(event.at(3));

    system->dispatch(player::event::LuaEvent(touch, x, y));
}

/*
static void dispatchSMS(System *system, std::vector<std::string> &event) {
    std::string type = event.at(1);
    if (type == "send") {
        std::string to = event.at(2);
        std::string result = event.at(3);
        std::string error = event.at(4);
        std::string id = event.at(5);
        bool sent = (result == "true");

        system->dispatch(player::event::LuaEvent(to, sent, error, id));
    }
    else {
        std::string from = event.at(2);
        std::string port = event.at(3);
        std::string message = event.at(4);

        system->dispatch(player::event::LuaEvent(from, port, message));
    }
}

static void dispatchSiEPG(System *system, std::vector<std::string> &event) {
    player::event::LuaEvent si;
    player::event::si::parseEPG(si, event);
    system->dispatch(si);
}

static void dispatchSiMosaic(System *system, std::vector<std::string> &event) {
    player::event::LuaEvent si;
    player::event::si::parseMosaic(si, event);
    system->dispatch(si);
}

static void dispatchSiServices(System *system, std::vector<std::string> &event) {
    player::event::LuaEvent si;
    player::event::si::parseServices(si, event);
    system->dispatch(si);
}

static void dispatchSiTime(System *system, std::vector<std::string> &event) {
    player::event::LuaEvent si;
    player::event::si::parseTime(si, event);
    system->dispatch(si);
}
*/

typedef void (*dispatcher)(System *system, std::vector<std::string> &event);

static void poll(System *system) {
    std::map<std::string, dispatcher> handlers;
    handlers["key"] = dispatchKey;
    handlers["pointer"] = dispatchPointer;
    /*
    handlers["si.epg"] = dispatchSiEPG;
    handlers["si.mosaic"] = dispatchSiMosaic;
    handlers["si.services"] = dispatchSiServices;
    handlers["si.time"] = dispatchSiTime;
    handlers["sms"] = dispatchSMS;
    */

    for (;;) {
        std::vector<std::string> event;
        aruic::input::readInputEvent(event);

        std::string name = event.at(0);
        std::map<std::string, dispatcher>::iterator i = handlers.find(name);
        if (i == handlers.end()) {
            LWARN("android::System", "Unknown input event \"%s\"", name.c_str());
            continue;
        }

        dispatcher handle = i->second;
        handle(system, event);
    }
}

System::System():
    poller(poll, this)
{
    aruic::config::setPort(util::cfg::getValue<std::string>("gui.canvas.arui.port"));
}

canvas::NclViewer *System::createNclViewer( canvas::Surface *surface ) {
	return new NclViewer( (canvas::System *)this, surface );
}

canvas::GifViewer *System::createGifViewer( Surface *surface ) {
	return new GifViewer( (canvas::System *)this, surface );
}

}
}
