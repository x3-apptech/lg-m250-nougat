#include "gifviewer.h"

#include "translators.h"
#include "opcodes.h"

namespace aruic {
namespace gifviewer {

void newGifViewer(void * id, Surface *surface) {
	invoke(id, IPC_GIFVIEWER_NEW).set(surface).call();
}

void deleteGifViewer(void * id) {
	invoke(id, IPC_DELETE).call();
}

bool load(void * id, const std::string &file) {
	return invoke(id, IPC_GIFVIEWER_LOAD).set(file).call().get<bool>();
}

void stop(void * id) {
	invoke(id, IPC_GIFVIEWER_STOP).call();
}

int draw(void * id) {
	return invoke(id, IPC_GIFVIEWER_DRAW).call().get<int>();
}

void setFreeze(void * id, bool freeze) {
	invoke(id, IPC_GIFVIEWER_FREEZE).set(freeze).call();
}

int getDuration(void * id) {
	return invoke(id, IPC_GIFVIEWER_DURATION).call().get<int>();
}

} // namespace webviwer
} // namespace aruic
