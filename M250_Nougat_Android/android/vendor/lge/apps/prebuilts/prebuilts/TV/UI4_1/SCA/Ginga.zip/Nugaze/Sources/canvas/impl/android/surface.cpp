#include <iomanip>

#include "surface.h"
#include "converter.h"

#include "../../rect.h"

#include <util/log.h>
#include <util/string_utils.h>

#include <aruic/surface.h>

namespace canvas {
namespace android {

using namespace std;

Surface::Surface(Canvas *canvas, const Rect &rect):
    canvas::Surface(Point(rect.x, rect.y)),
    _canvas(canvas),
    _size(rect.w, rect.h),
    _lastAlpha(255),
    _lastColor(0, 0, 0, 0),
    _lastMode(composition::null),
    _fontAscent(-1),
    _lastText(),
    _lastSize(0, 0)
{
	LDEBUG("android::Surface", "Surface(Rect(%d, %d, %d, %d))", rect.x, rect.y, rect.w, rect.h);
	aruic::surface::newSurface(this, canvas, aruicRect(rect).convert());
}

Surface::Surface(Canvas *canvas, const std::string &file):
    canvas::Surface(Point(0, 0)),
    _canvas(canvas),
    _size(320, 240),
    _lastAlpha(255),
    _lastColor(0, 0, 0, 0),
    _lastMode(composition::null),
    _fontAscent(-1),
    _lastText(),
    _lastSize(0, 0)
{
	LDEBUG("android::Surface", "Surface(\"%s\")", file.c_str());
	aruic::Size aSize;
	aruic::surface::newSurface(this, canvas, file, aSize);
	_size = canvasSize(aSize).convert();
}

Surface::~Surface()
{
    markDirty();
    LDEBUG("android::Surface", "~Surface()");
	aruic::surface::deleteSurface(this);
}

canvas::Canvas *Surface::canvas() const {
	return _canvas;
}

Size Surface::getSize() const {
	return _size;
}

bool Surface::getClip(Rect &rect) {
	aruic::Rect aRect;
	aruic::surface::getClip(this, aRect);
	rect = canvasRect(aRect).convert();
	return true;
}

int Surface::fontAscent() {
	if (_fontAscent == -1) {
		_fontAscent = aruic::surface::fontAscent(this);
	}
	return _fontAscent;
}

int Surface::fontDescent() {
	if (_fontDescent == -1) {
		_fontDescent = aruic::surface::fontDescent(this);
	}
	return _fontDescent;
}

void Surface::setColorImpl(Color &color) {
    if (!(_lastColor.equals(color, 0))) {
        _lastColor = color;
        aruic::surface::setColor(this, aruicColor(color).convert());
    }
}

bool Surface::setOpacity(util::BYTE alpha) {
    if (_lastAlpha != alpha) {
        _lastAlpha = alpha;
        aruic::surface::setOpacity(this, alpha);
    }
    return true;
}

util::BYTE Surface::getOpacity() const {
	return _lastAlpha;
}

bool Surface::saveAsImage(const std::string& file) {
	return aruic::surface::saveAsImage(this, file);
}

bool Surface::applyFont() {
	Font font = getFont();
	if (_lastFont != font) {
		_lastFont = font;
		int ascent;
		int descent;
		bool result = aruic::surface::applyFont(this, aruicFont(font).convert(), ascent, descent);
		if (result) {
			_fontAscent = ascent;
			_fontDescent = descent;
		}
		return result;
	} else {
		return true;
	}
}

void Surface::setClipImpl(const Rect& rect) {
	aruic::surface::setClip(this, aruicRect(rect).convert());
}

void Surface::drawLineImpl(int x1, int y1, int x2, int y2) {
	aruic::surface::drawLine(this, x1, y1, x2, y2);
}

void Surface::drawRectImpl(const Rect& rect) {
	aruic::surface::drawRect(this, aruicRect(rect).convert());
}

void Surface::fillRectImpl(const Rect& rect) {
	aruic::surface::fillRect(this, aruicRect(rect).convert());
}

void Surface::drawRoundRectImpl(const Rect& rect, int arcW, int arcH) {
	aruic::surface::drawRoundRect(this, aruicRect(rect).convert(), arcH, arcW);
}

void Surface::fillRoundRectImpl(const Rect& rect, int arcW, int arcH) {
	aruic::surface::fillRoundRect(this, aruicRect(rect).convert(), arcH, arcW);
}

void Surface::drawPolygonImpl(const std::vector<Point>& vertices, bool closed) {
	// TODO
	std::vector<aruic::Point> aVertices;
	for (std::vector<Point>::const_iterator i = vertices.begin(), n = vertices.end(); i != n; ++i) {
		aVertices.push_back((aruicPoint(*i).convert()));
	}

	aruic::surface::drawPolygon(this, aVertices, closed);
}

void Surface::fillPolygonImpl(const std::vector<Point>& vertices) {
	// TODO
	std::vector<aruic::Point> aVertices;
	for (std::vector<Point>::const_iterator i = vertices.begin(), n = vertices.end(); i != n; ++i) {
		aVertices.push_back((aruicPoint(*i).convert()));
	}

	aruic::surface::fillPolygon(this, aVertices);
}

void Surface::drawEllipseImpl(const Point& center, int rw, int rh, int angStart, int angStop) {
	aruic::surface::drawEllipse(this, aruicPoint(center).convert(), rw, rh, angStart, angStop);
}

void Surface::fillEllipseImpl(const Point& center, int rw, int rh, int angStart, int angStop) {
	aruic::surface::fillEllipse(this, aruicPoint(center).convert(), rw, rh, angStart, angStop);
}

void Surface::setCompositionModeImpl(composition::mode mode) {
	if (_lastMode != mode) {
		_lastMode = mode;
		aruic::surface::setCompositionMode(this, util::to_string(composition::getModeName(mode)));
	}
}

void Surface::clearImpl( const Rect &rect ) {
	aruic::surface::clear(this, aruicRect(rect).convert());
}

void Surface::blitImpl(const Point& target, canvas::Surface* srcSurface, const Rect& source) {
	aruic::surface::blit(this, aruicPoint(target).convert(), srcSurface, aruicRect(source).convert());
}

void Surface::blitImpl(const std::vector<Point>& targets, const std::vector<canvas::Surface*>& srcSurfaces, const std::vector<Rect>& sources) {
	// TODO
	std::vector<aruic::Point> aTargets;
	for (std::vector<Point>::const_iterator i = targets.begin(), n = targets.end(); i != n; ++i) {
		aTargets.push_back((aruicPoint(*i).convert()));
	}

	// TODO
	std::vector<aruic::Surface*> aSurfaces;
	for (std::vector<canvas::Surface*>::const_iterator i = srcSurfaces.begin(), n = srcSurfaces.end(); i != n; ++i) {
		aSurfaces.push_back(*i);
	}

	// TODO
	std::vector<aruic::Rect> aSources;
	for (std::vector<Rect>::const_iterator i = sources.begin(), n = sources.end(); i != n; ++i) {
		aSources.push_back((aruicRect(*i).convert()));
	}

	aruic::surface::blit(this, aTargets, aSurfaces, aSources);
}

void Surface::scaleImpl(
	const Rect& targetRect, canvas::Surface* srcSurface, const Rect& sourceRect, bool flipw, bool fliph)
{
	aruic::surface::scale(this,
			aruicRect(targetRect).convert(),
			srcSurface,
			aruicRect(sourceRect).convert(),
			flipw,
			fliph);
}

canvas::Surface *Surface::rotateImpl(int degrees) {
	Rect rect = getBounds();
	if (degrees == 90 || degrees == 270) {
		rect = Rect(rect.x, rect.y, rect.h, rect.w);
	}

	canvas::Surface* surface = createSimilar(rect);

	aruic::surface::rotate(this, degrees, surface);

	return surface;
}

void Surface::getPixelColorImpl(const Point& pos, Color& color) {
	aruic::Color aColor;
	aruic::surface::getPixelColor(this, aruicPoint(pos).convert(), aColor);
	color.r = aColor.r;
	color.g = aColor.g;
	color.b = aColor.b;
	color.alpha = aColor.alpha;
}

void Surface::setPixelColorImpl(const Point& pos, const Color& color) {
	aruic::surface::setPixelColor(this, aruicPoint(pos).convert(), aruicColor(color).convert());
}

void Surface::drawTextImpl(const Point& pos, const std::string& text, int ascent) {
	aruic::surface::drawText(this, aruicPoint(pos).convert(), text, ascent);
}

void Surface::drawTextImpl(const Rect& rect, const std::string& text, Alignment alignment, int spacing) {
	Color bgColor = getBackgroundColor();
	aruic::surface::drawTextBox(this, aruicRect(rect).convert(), text, alignment, spacing, aruicColor(bgColor).convert());
}

void Surface::measureTextImpl(const std::string& text, Size& size) {
	if (text.compare(_lastText)) {
		aruic::Size aSize;
		aruic::surface::measureText(this, text, aSize);
		size = canvasSize(aSize).convert();
		_lastText = text;
		_lastSize.w = size.w;
		_lastSize.h = size.h;
	} else {
		size.w = _lastSize.w;
		size.h = _lastSize.h;
	}
}

util::DWORD Surface::getPixel(const Point& pos) {
	return aruic::surface::getPixel(this, aruicPoint(pos).convert());
}

void Surface::resizeImpl(const Size& size, bool scaleContent) {
	_size.w = size.w;
	_size.h = size.h;
	aruic::surface::resize(this, aruicSize(size).convert(), scaleContent);
}

/*
string Surface::url_encode(const string &value) {
    ostringstream escaped;
    escaped.fill('0');
    escaped << hex;

    for (string::const_iterator i = value.begin(), n = value.end(); i != n; ++i) {
        string::value_type c = (*i);
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            escaped << c;
        }
        else {
            escaped << '%' << setw(2) << ((int) c) << setw(0);
        }
    }

    return escaped.str();
}
*/

}
}

