#pragma once

#include <gingaplayer/input/manager.h> // TODO: verify this dependency
#include "../../nclviewer.h"
#include "../../window.h"

namespace canvas {
namespace android {

class NclViewer : public canvas::NclViewer {
public:
	NclViewer( canvas::System *sys, canvas::Surface *surface );
	virtual ~NclViewer( void );

	virtual void *prepare();
	virtual void stop();
	virtual void draw();

	virtual void resize( const Size &size );
	virtual void move( const Point &point );

	virtual void dispatch(const player::event::LuaEvent &event);
	void dispatchKey( util::key::type key, bool isUp );

private:
	Window *_window;
};

}
}
