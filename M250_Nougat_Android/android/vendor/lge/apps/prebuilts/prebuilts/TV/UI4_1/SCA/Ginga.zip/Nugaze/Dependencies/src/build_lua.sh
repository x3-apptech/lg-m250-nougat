#!/bin/bash

. build_setup.sh

NAME="lua-5.1.5"
cd $NAME
rm -fR src/*.o src/*.a src/lua src/luac
STAGE=$(make_stagedir)

export CC
export LUA_AR="$AR"
export RANLIB

make generic
make install INSTALL_TOP=$STAGE
copy_binaries $STAGE
