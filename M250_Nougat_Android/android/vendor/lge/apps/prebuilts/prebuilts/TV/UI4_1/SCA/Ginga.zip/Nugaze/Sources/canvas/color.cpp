#include "color.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "system.h"
#include "util/log.h"

namespace canvas {

namespace color {

typedef struct {
	const char *name;
	util::BYTE r;
	util::BYTE g;
	util::BYTE b;
	util::BYTE a;
} ColorType;

#define DO_ENUM_COLOR( name, r, g, b, a ) { #name, r, g, b, a },
static const ColorType colors[] = {
	COLOR_LIST(DO_ENUM_COLOR)
	{ NULL, 0, 0, 0, 0 }
};
#undef DO_ENUM_COLOR

bool get(const char *textColor, Color &color) {
    if (textColor[0] == '#') {
        const char *number = textColor + 1;
        char *endptr = NULL;
        long val = strtol(number, &endptr, 16); // Base is 16

        // Check for various possible errors
        if (
            (errno == ERANGE && (val == LONG_MAX || val == LONG_MIN)) ||
            (errno != 0 && val == 0)
        ) {
            LWARN("Color", "RGB color is out of range.\n");
            return false; // Out of range
        }

        if (endptr == number) {
            LWARN("Color", "No digits were found in RGB color.\n");
            return false; // No digits
        }

        color = Color((val >> 16) & 0xFF, (val >> 8) & 0xFF, val & 0xFF);
        return true;
    }

    char *textColorLower = (char *) malloc(strlen(textColor));
    strcpy(textColorLower, textColor);
    for (int i = 0; textColorLower[i]; i++) {
        textColorLower[i] = tolower(textColorLower[i]);
    }
    for (int i = 0; i < LAST_COLOR; i++) {
        const ColorType &colorType = colors[i];
        const char *name = colorType.name;
        if (name != NULL && strcmp(name, textColorLower) == 0) {
            color = Color(colorType.r, colorType.g, colorType.b, colorType.a);
            free(textColorLower);
            textColorLower = NULL;
            return true;
        }
    }
    free(textColorLower);
    textColorLower = NULL;

	return false;
}

}

Color::Color( void )
{
	r = 0;
	g = 0;
	b = 0;
	alpha = 0;
}

Color::Color( util::BYTE paramR, util::BYTE paramG, util::BYTE paramB, util::BYTE paramAlpha )
{
	r = paramR;
	g = paramG;
	b = paramB;
	alpha = paramAlpha;
}

Color::Color( util::BYTE paramR, util::BYTE paramG, util::BYTE paramB )
{
	r = paramR;
	g = paramG;
	b = paramB;
	alpha = 255;
}

Color::~Color( void )
{
}

bool Color::operator==( const Color &color ) const {
	return r == color.r && g == color.g && b == color.b;
}

bool Color::operator!=( const Color &color ) const {
	return !((*this) == color);
}

bool Color::equals( const Color &color, int threshold ) const {
	int error = abs(color.r - r) + abs( color.g - g ) + abs( color.b - b ) + abs( color.alpha - alpha );
	return error <= threshold;
}

}
