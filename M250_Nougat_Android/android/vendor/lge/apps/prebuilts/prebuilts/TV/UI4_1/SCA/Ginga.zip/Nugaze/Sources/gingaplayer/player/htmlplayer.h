#pragma once

#include "graphicplayer.h"
#include "player/lua/event/types.h"

namespace canvas {
	class WebViewer;
}

namespace player {

class HtmlPlayer : public GraphicPlayer {
public:
	HtmlPlayer( Device *dev );
	virtual ~HtmlPlayer();

	virtual bool isApplication() const;

protected:
	virtual bool startPlay();
	virtual void stopPlay();
	virtual void refresh();
	virtual bool supportRemote() const;
	virtual void registerProperties();

	//	Events
	void onDispatchEvent(const event::LuaEvent &event);
	virtual void onSizeChanged( const canvas::Size &size );
	virtual void onPositionChanged( const canvas::Point &point );

private:
	canvas::WebViewer *_html;
};

}
