#include "types.h"

#include <algorithm>

namespace player {
namespace event {

/*
Top-level Definitions
*/

#define DO_ENUM_TYPE_STRING( t ) #t,
static const char* types[] = {
    "NULL",
    TYPE_LIST(DO_ENUM_TYPE_STRING)
    "LAST"
};

#define DO_ENUM_ACTION_STRING( a ) #a,
static const char* actions[] = {
    "NULL",
    ACTION_LIST(DO_ENUM_ACTION_STRING)
    "LAST"
};
#undef DO_ENUM_PROPERTY_STRING

evtType::type getEventType(const std::string &name) {
	for (int i = 0; i < evtType::LAST; i++) {
		if (name == types[i]) {
			return (evtType::type)i;
		}
	}

	return evtType::unknown;
}

evtAction::type getEventAction(const std::string &name){
	for (int i = 0; i < evtAction::LAST; i++) {
		if (name == actions[i]) {
			return (evtAction::type) i;
		}
	}

	return evtAction::unknown;
}

const char *getActionName( evtAction::type action ) {
	if (action > evtAction::LAST) {
		action=evtAction::unknown;
	}
	return actions[action];
}

template<> std::string represent(const std::string &value) {
    return std::string("\"") + value + '"';
}

template<> std::string represent(const LuaNil &value) {
    return ((std::string) value);
}

template<> std::string represent(const LuaTable &value) {
    return ((std::string) value);
}

/*
LuaNil Defintions
*/

LuaNil::operator std::string() const {
    return "LuaNil(nil)";
}

void LuaNil::push(lua_State *lua) const {
    lua_pushnil(lua);
}

const LuaNil LuaNil::NIL;

/*
LuaField Defintions
*/

LuaField::LuaField(const std::string &_name):
    name(_name)
{
    // Nothing to do.
}

/*
LuaFieldValue Defintions
*/

template<> void LuaFieldValue<bool>::push(lua_State *lua) const {
    LDEBUG("player::event::LuaFieldValue", "Push boolean: %s", value ? "true" : "false");

    lua_pushboolean(lua, value ? 1 : 0);
}

template<> void LuaFieldValue<int>::push(lua_State *lua) const {
    LDEBUG("player::event::LuaFieldValue", "Push int: %d", value);

    lua_pushnumber(lua, (lua_Number) value);
}

template<> void LuaFieldValue<double>::push(lua_State *lua) const {
    LDEBUG("player::event::LuaFieldValue", "Push double: %lf", value);

    lua_pushnumber(lua, (lua_Number) value);
}

template<> void LuaFieldValue<std::string>::push(lua_State *lua) const {
    LDEBUG("player::event::LuaFieldValue", "Push string: %s", value.c_str());

    lua_pushstring(lua, value.c_str());
}

template<> char LuaFieldValue<int>::typeChar() const { return 'I'; }
template<> char LuaFieldValue<bool>::typeChar() const { return 'Z'; }
template<> char LuaFieldValue<double>::typeChar() const { return 'D'; }
template<> char LuaFieldValue<std::string>::typeChar() const { return 'S'; }
template<> char LuaFieldValue<LuaNil>::typeChar() const { return 'V'; }
template<> char LuaFieldValue<LuaTable>::typeChar() const { return 'T'; }
template<> char LuaFieldValue<LuaDateTime>::typeChar() const { return 'C'; }

/*
LuaTable Definitions
*/

LuaTable::LuaTable():
    fields(),
    values()
{
    // Nothing to do.
}

LuaTable::LuaTable(const LuaTable &that):
    fields(),
    values()
{
    for (LuaFieldArray::const_iterator i = that.values.begin(), n = that.values.end(); i != n; ++i) {
        const LuaField &field = *(i->get());
        LuaFieldPtr pointer(field.clone());
        values.push_back(pointer);
    }

    for (LuaFieldMap::const_iterator i = that.fields.begin(), n = that.fields.end(); i != n; ++i) {
        const std::string &name = i->first;
        const LuaField &field = *(i->second);
        fields[name].reset(field.clone());
    }
}

LuaTable &LuaTable::operator = (LuaTable that) {
    std::swap(fields, that.fields);
    std::swap(values, that.values);
    return *this;
}

LuaTable::operator std::string() const {
    std::ostringstream stream;
    stream << "{";

    for (LuaFieldArray::const_iterator i = values.begin(), m = values.end(); i != m;) {
        LuaField *field = i->get();
        stream << (std::string) *field;
        if (++i != m) {
            stream << ", ";
        }
    }

    if (values.size() > 0 && fields.size() > 0) {
        stream << ", ";
    }

    for (LuaFieldMap::const_iterator j = fields.begin(), n = fields.end(); j != n;) {
        LuaField &field = *(j->second);
        stream << (std::string) field;
        if (++j != n) {
            stream << ", ";
        }
    }

    stream << "}";

    return stream.str();
}

bool LuaTable::contains(const std::string &name) {
    return (fetch(name) != NULL);
}

template<> bool LuaTable::pull(lua_State *lua, bool &value) {
    if (!lua_isboolean(lua, -1)) {
        return false;
    }

    value = (lua_toboolean(lua, -1) == 1 ? true : false);
    return true;
}

template<> bool LuaTable::pull(lua_State *lua, int &value) {
	if (!lua_isnumber(lua, -1)) {
		return false;
	}

    value = (int) lua_tonumber(lua, -1);
    return true;
}

template<> bool LuaTable::pull(lua_State *lua, double &value) {
	if (!lua_isnumber(lua, -1)) {
		return false;
	}

    value = (double) lua_tonumber(lua, -1);
    return true;
}

template<> bool LuaTable::pull(lua_State *lua, std::string &value) {
	if (!lua_isstring(lua, -1)) {
		return false;
	}

	value = lua_tolstring(lua, -1, NULL);
    return true;
}

void LuaTable::push(lua_State *lua) const {
    lua_createtable(lua, values.size(), fields.size());

    int index = 0;
    for (LuaFieldArray::const_iterator i = values.begin(), m = values.end(); i != m; ++i) {
        const LuaField &field = *(i->get());
        field.push(lua);
        lua_rawseti(lua, -2, ++index);
    }

    for (LuaFieldMap::const_iterator j = fields.begin(), n = fields.end(); j != n; ++j) {
        const std::string &name = j->first;
        const LuaField &field = *(j->second);
        field.push(lua);
        lua_setfield(lua, -2, name.c_str());
    }
}

LuaField *LuaTable::fetch(size_t index) const {
    return values.at(index).get();
}

LuaField *LuaTable::fetch(const std::string &name) const {
    LuaFieldMap::const_iterator i = fields.find(name);
    if (i == fields.end()) {
        return NULL;
    }

    return (i->second.get());
}

/*
 * Convenience method and helper functions to create a table from a specific string representation
 */

static std::string readString(const std::string &data, unsigned int &offset) {
	int end_idx = data.find(' ',offset);
	if (end_idx < 0)
		end_idx = data.length();
	std::string r = data.substr(offset,end_idx-offset);
	offset = end_idx+1;
	return util::url_decode(r);
}

static bool readBool(const std::string &data, unsigned int &offset) {
	std::string str = readString(data,offset);
	return str.compare("true") == 0;
}

static int readInt(const std::string &data, unsigned int &offset) {
	std::string str = readString(data,offset);
	return atoi(str.c_str());
}

static double readDouble(const std::string &data, unsigned int &offset) {
	std::string str = readString(data,offset);
	return atof(str.c_str());
}

static LuaNil readVoid(const std::string &data, unsigned int &offset) {
	offset++;
	return LuaNil::NIL;
}

bool LuaTable::fromString(const std::string &data) {
	unsigned int offset = 0;
	return recFromString(data, offset);
}

bool LuaTable::recFromString(const std::string &data, unsigned int &offset) {
	if (data[offset] == '[') { // this LuaTable shall represent an array
		LDEBUG("player::event","[LuaTable] start of array");
		char array_type = data[++offset]; // advance to array type and read it
		if (array_type != '{' && array_type != '[' && array_type != ']')
			offset++; // if not an array of tables, array of lists or empty, advance again
		do { // we shall not have an empty array (it would read as an empty table), but it works
			if (data[offset] == ']') { // end of array
				offset+=2;
				LDEBUG("player::event","[LuaTable] end of array; next char: %c", offset >= data.length() ? ' ' : data[offset]);
				break;
			}
			switch (array_type) {
			case 'I': { add<int>(readInt(data,offset)); break; }
			case 'D': { add<double>(readDouble(data,offset)); break; }
			case 'Z': { add<bool>(readBool(data,offset)); break; }
			case 'V': { add<LuaNil>(readVoid(data,offset)); break; }
			case 'S': { add<std::string>(readString(data,offset)); break; }
			case '{':
			case '[': { LuaTable value; value.recFromString(data,offset); add<LuaTable>(value); break; }
			default: return false;
			}
		} while (offset < data.length());
	} else if (data[offset++] == '{') { // this LuaTable shall represent a table
		LDEBUG("player::event","[LuaTable] start of table");
		while (offset < data.length()) {
			if (data[offset] == '}') { // end of table
				offset+=2;
				LDEBUG("player::event","[LuaTable] end of table; next char: %c", offset >= data.length() ? ' ' : data[offset]);
				break;
			}
			const std::string fieldname = readString(data,offset);
			char obj_type = data[offset];
			switch (obj_type) {
			case 'I': { offset++; set<int>(fieldname,readInt(data,offset)); break; }
			case 'D': { offset++; set<double>(fieldname,readDouble(data,offset)); break; }
			case 'Z': { offset++; set<bool>(fieldname,readBool(data,offset)); break; }
			case 'V': { offset++; set<LuaNil>(fieldname,readVoid(data,offset)); break; }
			case 'S': { offset++; set<std::string>(fieldname,readString(data,offset)); break; }
			case 'C':  { offset++;
				LuaDateTime value;
				value.set<int>("year",readInt(data,offset));
				value.set<int>("month",readInt(data,offset));
				value.set<int>("day",readInt(data,offset));
				value.set<int>("hour",readInt(data,offset));
				value.set<int>("min",readInt(data,offset));
				value.set<int>("sec",readInt(data,offset));
				set<LuaDateTime>(fieldname,value); break;
			}
			case '{':
			case '[': { LuaTable value; value.recFromString(data,offset); set<LuaTable>(fieldname,value); break; }
			default: return false;
			}
		}
	} else return false;
	return true;
}

/*
 * Convenience method and helper functions to create a specific string representation from a LuaTable
 */

static std::string urlencode(const std::string &data) {
	LDEBUG("player::event","[LuaTable] string encode: %s", data.c_str());
	return data;
}

bool LuaTable::toString(std::string &value) {
    std::ostringstream stream;
	if (fields.empty()) { // If we have an empty fields, we probably have an array...
		if (values.empty()) { // ... or an empty table
			stream << "{}";
		} else { // Array
		    stream << '[';
		    LuaFieldArray::const_iterator i = values.begin();
		    char t = i->get()->typeChar();
		    if (t != 'T') // if table, skip the type char
		    	stream << t;
		    for (LuaFieldArray::const_iterator m = values.end(); i != m; ++i) {
		        LuaField *field = i->get();
		        switch(t) {
		        //case 'V': { break; } -- there shall be no nil array
		        case 'I': { stream << ((LuaFieldValue<int>*)field)->value; break; }
		        case 'D': { stream << ((LuaFieldValue<double>*)field)->value; break; }
		        case 'Z': { stream << ((((LuaFieldValue<bool>*)field)->value) ? "true" : "false"); break; }
		        case 'S': { stream << urlencode(((LuaFieldValue<std::string>*)field)->value); break; }
		        case 'T': {
		        	std::string v;
					if (!((LuaFieldValue<LuaTable>*)field)->value.toString(v))
		        		return false;
		        	else stream << v;
		        	break;
		        }
				case 'C': {
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("year") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("month") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("day") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("hour") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("min") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("sec");
					break;
				}
		        default: return false;
		        }
	            stream << ' ';
		    }
		    stream << ']';
		}
	} else { // we have a non-empty table
		stream << '{';
		for (LuaFieldMap::const_iterator j = fields.begin(), n = fields.end(); j != n; ++j) {
		    const std::string &fieldname = j->first;
			LuaField *field = j->second.get();
			char t = field->typeChar();
			stream << fieldname << ' ';
			if (t != 'T') // if table, skip the type char
				stream << t;
		    switch(t) {
				case 'I': { stream << ((LuaFieldValue<int>*)field)->value; break; }
				case 'D': { stream << ((LuaFieldValue<double>*)field)->value; break; }
				case 'Z': { stream << ((((LuaFieldValue<bool>*)field)->value) ? "true" : "false"); break; }
				case 'V': { break; }
				case 'S': { stream << urlencode(((LuaFieldValue<std::string>*)field)->value); break; }
				case 'T': {
	        	std::string v;
				if (!((LuaFieldValue<LuaTable>*)field)->value.toString(v))
	        		return false;
	        	else stream << v;
	        	break;
	        }
				case 'C': {
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("year") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("month") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("day") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("hour") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("min") << ' ';
					stream << ((LuaTable)((LuaFieldValue<LuaTable>*)field)->value).get<int>("sec");
					break;
				}
	        default: return false;
	        }
		    stream << ' ';
		}
	    stream << "}";
	}
	value.append(stream.str());
	return true;
}


/*
LuaDateTime Definitions
*/

LuaDateTime::operator time_t() const {
    struct tm when = {
        get<int>("sec"),
        get<int>("min"),
        get<int>("hour"),
        get<int>("day"),
        get<int>("month"),
        get<int>("year"),
        0, // tm_wday
        0, // tm_yday
        //DST information is not available in Lua <date> format (MJD),
        // according to ABNT NBR 15606-2 section 10.3.3.3 and ABNT NBR 15603-2 Annex A
        /*get<bool>("isdst") ? 1 :*/ 0
    };

    return mktime(&when);
}

LuaDateTime &LuaDateTime::operator = (time_t when) {
    struct tm *fields = localtime(&when);
    set<int>("sec", fields->tm_sec);
    set<int>("min", fields->tm_min);
    set<int>("hour", fields->tm_hour);
    set<int>("day", fields->tm_mday);
    set<int>("month", fields->tm_mon);
    set<int>("year", fields->tm_year);
    //DST information is not available in Lua <date> format (MJD),
    // according to ABNT NBR 15606-2 section 10.3.3.3 and ABNT NBR 15603-2 Annex A
    //set<bool>("isdst", fields->tm_isdst != 0);

    return *this;
}

#define checkRequired(expression) if (!(expression)) {return false;}

bool LuaDateTime::pull(lua_State *lua) {
    checkRequired(LuaTable::pull<int>("year", lua, -1));
    checkRequired(LuaTable::pull<int>("month", lua, -1));
    checkRequired(LuaTable::pull<int>("day", lua, -1));

    LuaTable::pull<int>("hour", lua, -1, 12);
    LuaTable::pull<int>("min", lua, -1, 0);
    LuaTable::pull<int>("sec", lua, -1, 0);
    //DST information is not available in Lua <date> format (MJD),
    // according to ABNT NBR 15606-2 section 10.3.3.3 and ABNT NBR 15603-2 Annex A
    //LuaTable::pull<bool>("isdst", lua, -1, false);

    return true;
}

/*
LuaHandler Definitions
*/

LuaHandler::LuaHandler(lua_State *_lua, int _reference, const std::string &_filter, const std::list<std::string> &_depFilters):
    lua(_lua),
    reference(_reference),
    filter(_filter),
    depFilters(_depFilters)
{
    // Nothing to do.
}

LuaHandler::~LuaHandler() {
    luaL_unref(lua, LUA_REGISTRYINDEX, reference);
}

bool  LuaHandler::isEqual(lua_State *L, int index) {
    //	Get stored function
    lua_rawgeti(L, LUA_REGISTRYINDEX, reference);
    //	Compare with parameter
    bool res = (lua_equal( L, index, -1 ) == 1);
    lua_pop(L, 1);
    return res;
}

const std::list<std::string> LuaHandler::depFilter(const std::string &name) {
	std::list<std::string> filters;
	// Refer to NCL 3.0 Part 10, Appendix A, section 2.2.3 (Event classes)
	if (name == "key") {
		filters.push_back("type");
		filters.push_back("key");
	} else if (name == "ncl") {
		filters.push_back("type");
		filters.push_back("label");
		filters.push_back("action");
	} else if (name == "tcp") {
		filters.push_back("connection");
	} else if (name == "sms") {
		filters.push_back("from");
	} else if(name == "si") {
		filters.push_back("type");
	} else if(name == "user") {
		filters.push_back("type");
	}
	return filters;
}

bool LuaHandler::dispatch(const LuaTable &event) const {
	if ( filter != "" ) { // empty class means "any event". Class dependent filters are ignored in this case.
		const std::string class_name = event.get<std::string>("class");
		const std::list<std::string> depFilterName = depFilter(class_name);
		if ( filter != class_name ) {
			LDEBUG("player::event::LuaHandler", "event %s not match filter class \"%s\"", ((std::string) event).c_str(), filter.c_str());
			return false;
		}
		if ( depFilterName.size() < depFilters.size()) {
			// This should never happen, we should not have registered a handler with more filters than permitted anyway
			LWARN("player::event::LuaHandler", "too many filters for class \"%s\"", class_name.c_str());
			return false;
		}
		for (std::list<std::string>::const_iterator it_name = depFilterName.begin(), it_filter = depFilters.begin();
				it_filter != depFilters.end(); ++it_filter, ++it_name) {
			std::string data = event.get<std::string>(*it_name);
			if (*it_filter != data) {
				LDEBUG("player::event::LuaHandler", "event field %s (%s) not match class dependent filter (%s)",
						(*it_name).c_str(), data.c_str(), (*it_filter).c_str());
				return false;
			}
		}
	}

    LDEBUG("player::event::LuaHandler", "Dispatch event %s", ((std::string) event).c_str());

    lua_rawgeti(lua, LUA_REGISTRYINDEX, reference);

    event.push(lua);

	if (lua_pcall(lua, 1, 1, 0) != 0) {
		LERROR("player::event::LuaHandler", "Dispatched event error: %s", lua_tostring(lua, -1));
		lua_pop( lua, 1 );
		return false;
	}
    bool result = (lua_toboolean(lua, -1) == 1);
    lua_pop( lua, 1 );

    LDEBUG("player::event::LuaHandler", "Event dispatched, result = %s", result ? "true" : "false");

    return result;
}

bool LuaHandler::dispatchEvent( int ref ) {
    bool result = false;
    lua_rawgeti( lua, LUA_REGISTRYINDEX, ref );
    std::string className = lua::getField( lua, -1, "class" );

    if (filter == "" || filter == className) {
        lua_rawgeti( lua, LUA_REGISTRYINDEX, reference );
        lua_pushvalue( lua, -2 );
        lua_call( lua, 1, 1 );
        result = (lua_toboolean( lua, -1 ) == 1);
        lua_pop( lua, 1 );
    }

    lua_pop( lua, 1 );
    return result;
}

/*
LuaEvent Definitions
*/

LuaEvent::LuaEvent() {
}

LuaEvent::LuaEvent(const LuaEvent &that):
    LuaTable(that)
{
    // Nothing to do.
}

LuaEvent::LuaEvent(const std::string &name) {
	set<std::string>("class", name);
}

LuaEvent::LuaEvent(util::key::type key, bool isUp) {
	set<std::string>("class", "key");
	set<std::string>("type", isUp ? "release" : "press");
	set<std::string>("key", util::key::getKeyName(key));
}

LuaEvent::LuaEvent(util::touch::type touch, int x, int y) {
	set<std::string>("class", "pointer");
	set<std::string>("type", util::touch::getTouchName(touch));
	set<int>("x", x);
	set<int>("y", y);
}

LuaEvent::LuaEvent(const std::string &from, const std::string &port, const std::string &message) {
	set<std::string>("class", "sms");
	set<std::string>("type", "receive");
	set<std::string>("from", from);
	set<std::string>("port", port);
	set<std::string>("value", message);
}

LuaEvent::LuaEvent(const std::string &to, const bool &sent, const std::string &error, const std::string &id) {
	set<std::string>("class", "sms");
	set<std::string>("type", "send");
	set<std::string>("to", to);
	set<bool>("sent", sent);

	if (error != "") {
		set<std::string>("error", error);
	}

	if (id != "") {
		set<std::string>("id", id);
	}
}

std::string LuaEvent::name() const {
    return get<std::string>("class");
}

LuaEvent *LuaEvent::clone() const {
    return new LuaEvent(*this);
}

void LuaEvent::dispatch(lua_State *lua, LuaHandlers &handlers) const {
    for (LuaHandlers::iterator i = handlers.begin(), n = handlers.end(); i != n; ++i) {
        const LuaHandler *handler = i->get();
        if (handler && handler->dispatch(*this)) {
            break;
        }
    }
}

bool LuaEvent::isKey() const {
    return (name() == "key");
}

util::key::type LuaEvent::getKey() const {
    std::string keyName = get<std::string>("key");
    if (keyName == "") {
        return util::key::null;
    }

    return util::key::getKey(keyName.c_str());
}

bool LuaEvent::isUp() const {
    return (isKey() && get<std::string>("type") == "release");
}

bool LuaEvent::isPointer() const {
    return (name() == "pointer");
}

bool LuaEvent::isPress() const {
    return (isPointer() && get<std::string>("type") == "press");
}

util::touch::type LuaEvent::getTouch() const {
    std::string touchName = get<std::string>("type");
    return util::touch::getTouch(touchName.c_str());
}

int LuaEvent::getX() const {
    return get<int>("x");
}

int LuaEvent::getY() const {
    return get<int>("y");
}

bool LuaEvent::isSI() const {
    return (name() == "si");
}

bool LuaEvent::isSMS() const {
    return (name() == "sms");
}

}
}
