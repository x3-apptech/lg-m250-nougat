#include "input.h"

#include "translators.h"
#include "opcodes.h"

namespace aruic {
namespace input {

void readInputEvent(std::vector<std::string> &event) {
	aruic::ipc(aruic::IPC_INPUT_EVENT).call().get(event);
}

} // namespace input
} // namespace aruic
