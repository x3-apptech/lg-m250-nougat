#!/bin/bash

. build_setup.sh

EV="libev-4.15"
extract_sources $EV
STAGE=$(make_stagedir)

./configure CC="$CC" CFLAGS="$CFLAGS" --enable-static=yes --host=arm-linux --prefix=$STAGE --exec-prefix=$STAGE

patch < "${CWD}/libev_ev_select.c.patch"

make $MAKE_JOBS $MAKE_LOAD
make install
copy_binaries $STAGE
