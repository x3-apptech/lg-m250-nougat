#!/bin/bash

function build_all {
(./build_iconv.sh 2>&1) | tee out_iconv.txt
(./build_zlib.sh 2>&1) | tee out_zlib.txt
(./build_boost.sh 2>&1) | tee out_boost.txt
(./build_xerces.sh 2>&1) | tee out_xerces.txt
(./build_ev.sh 2>&1) | tee out_ev.txt
(./build_db.sh 2>&1) | tee out_db.txt
cd src; (./build_lua.sh 2>&1) | tee out_lua.txt; cd ..
(./build_curl.sh 2>&1) | tee out_curl.txt
(./build_microhttpd.sh 2>&1) | tee out_microhttpd.txt
(./build_ancillary.sh 2>&1) | tee out_ancillary.txt
}

function build_armeabi {
export TARGET_ARCH_ABI="armeabi"
build_all
}

function build_armeabi_v7a {
export TARGET_ARCH_ABI="armeabi-v7a"
build_all
}

function build_x86 {
export TARGET_ARCH_ABI="x86"
build_all
}

if [ "$2" != "" ]; then
echo "Usage: ./build_all.sh <arch>"
echo "If not supplied, <arch> defaults to \"all\""
elif [ "$1" = "" -o "$1" = "all" ]; then
rm -fR armeabi/* armeabi-v7a/* x86/*
build_armeabi
build_armeabi_v7a
build_x86
elif [ "$1" = "armeabi" ]; then
rm -fR armeabi/*
build_armeabi
elif [ "$1" = "armeabi-v7a" ]; then
rm -fR armeabi-v7a/*
build_armeabi_v7a
elif [ "$1" = "x86" ]; then
rm -fR x86/*
build_x86
else
echo "Valid options are: all (default), armeabi, armeabi-v7a or x86"
fi
