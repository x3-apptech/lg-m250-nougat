#pragma once

#include "../event.h"

namespace player {
namespace event {
namespace si {

/*
Parse a "epg" SI event from an input event.
*/
void parseEPG(LuaEvent &response, const std::vector<std::string> &event);

/*
Parse a "mosaic" SI event from an input event.
*/
void parseMosaic(LuaEvent &response, const std::vector<std::string> &event);

/*
Parse a "services" SI event from an input event.
*/
void parseServices(LuaEvent &response, const std::vector<std::string> &event);

/*
Parse a "time" SI event from an input event.
*/
void parseTime(LuaEvent &response, const std::vector<std::string> &event);

/*
Implementation of the Lua event.post method for SI events.
*/
std::string postEvent(System *sys, lua_State *st, bool isOut, int eventPos);

}
}
}

