#pragma once

#include "canvas/input.h"

#include "graphicplayer.h"
#include <util/keydefs.h>

namespace player {

class TextPlayer: public GraphicPlayer {
public:
	TextPlayer( Device *dev );
	virtual ~TextPlayer();

	// According NCL specification, default font size is system-dependent
	static const int DEFAULT_FONT_SIZE = 10;

private:
	bool hasHorizontalScroll();
	bool hasVerticalScroll();
	void drawVerticalScrollBar();

protected:
	virtual void refresh();
	virtual void registerProperties();

	bool readFile( std::string &text );
	void applyFont();
	void applyColor();
	void applyBackgroundColor();
	void applyScroll();
	void userEventReceived( const player::event::LuaEvent &event );

private:
	bool _applied;
	bool _scrollApplied;
	int _size;
	std::string _family;
	std::string _style;
	std::string _variant;
	std::string _weight;
	std::string _color;
	std::string _scroll;
	std::string _backgroundcolor;
	unsigned int _scrollIndex;
	unsigned int _scrollLimit;
};

}
