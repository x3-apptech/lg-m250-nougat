#pragma once

#include "property.h"
#include <vector>

namespace player {

class CompositeProperty : public Property {
public:
	CompositeProperty();
	virtual ~CompositeProperty();

	virtual bool canStart() const;

	void add( Property *prop );

protected:
	virtual bool assignImpl(const void *pointer);
	virtual bool needRefresh() const;
	virtual void applyChanges();

private:
	std::vector<Property *> _properties;
};

}

