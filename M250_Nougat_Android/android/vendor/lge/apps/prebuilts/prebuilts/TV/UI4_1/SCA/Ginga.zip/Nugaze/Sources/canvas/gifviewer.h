#pragma once

#include <string>
#include <boost/function.hpp>
#include "util/keydefs.h"

namespace canvas {

class Point;
class Size;
class System;
class Surface;

class GifViewer {
public:
	explicit GifViewer( Surface *surface );
	virtual ~GifViewer( void );

	virtual bool load( const std::string &uri )=0;
	virtual void stop()=0;
	/**
	 * draw
	 * @return time in ms for next frame, 0 for end of media or negative values for errors
	 */
	virtual int draw()=0;

	//	Widget
	virtual void resize( const Size &size );
	virtual void move( const Point &point );

	//	Instance creation
	static GifViewer *create( System *sys, Surface *s );

	//  Properties
	virtual void setFreeze( bool freeze )=0;
	virtual int getDuration()=0; // in ms

protected:
	Surface *surface();

private:
	Surface *_surface;
	GifViewer() {}
};

}
