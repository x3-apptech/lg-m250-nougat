#include <string>
#include <list>

namespace ncl_util {

float getPercentualValue( const std::string &value, bool throwException = false);
bool isPercentualValue( const std::string &value );

int getPixelValue( const std::string &value, bool throwException = false);

double NaN();
double infinity();
bool isNaN( double value );
bool isInfinity( double value );
bool isValidNumericValue( const std::string &values);

struct is_alpha_or_space {
	bool operator()( char c ) {
		return std::isalpha(c) || std::isspace(c);
	}
};
}
