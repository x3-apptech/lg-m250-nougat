#!/bin/bash

. build_setup.sh

ICONV="libiconv-1.14"
extract_sources $ICONV
STAGE=$(make_stagedir)

CFLAGS="${CFLAGS} -DANDROID"

./configure CC="$CC" CFLAGS="$CFLAGS" CXX="$CXX" CPPFLAGS="$CPPFLAGS" --enable-static=yes --disable-shared --host=arm-linux --prefix=$STAGE --exec-prefix=$STAGE

(cd "srclib"; patch < "${CWD}/libiconv_lib_Makefile.patch")
(cd "lib"; patch < "${CWD}/libiconv_lib_iconv.c.patch")

make $MAKE_JOBS $MAKE_LOAD
make install
copy_binaries $STAGE
