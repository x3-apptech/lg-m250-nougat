#include "nclviewer.h"
#include "surface.h"
#include <util/log.h>
#include <util/mcr.h>
#include <assert.h>

namespace canvas {

NclViewer *NclViewer::create( System *sys, Surface *surface ) {
	UNUSED(sys);
	return (NclViewer*)NULL;
}

NclViewer::NclViewer( System *sys, canvas::Surface *surface )
	: _sys(sys), _surface( surface ), _dev(NULL)
{
	_surface->setCompositionMode( composition::source );
}

NclViewer::~NclViewer( void )
{
}

//	Widget
void NclViewer::resize( const Size & /*size*/ ) {
	onResized();
}

void NclViewer::move( const Point & /*point*/ ) {
	onResized();
}

void NclViewer::onResized() {
	const Size &size = _surface->getSize();
	LDEBUG("NclViewer", "Surface resized: width=%d, height=%d", size.w, size.h);
}

Surface *NclViewer::surface() {
	assert(_surface);
	return _surface;
}

void NclViewer::setCallbackNeedRefresh( const Callback &callback ){
	_callbackNeedRefresh = callback;
}

void NclViewer::runCallbackNeedRefresh(){
	if (_callbackNeedRefresh){
		_callbackNeedRefresh();
		// TODO: the callback should be called in the original viewer's thread
		/*if (_sys)
			_sys->enqueue(_callbackNeedRefresh);
		else LWARN("NclViewer", "No system to run refresh callback");*/
	}
}

void NclViewer::setSurfaceCallback( const SurfaceCallback &callback ) {
	_surfaceCallback = callback;
}

canvas::Surface *NclViewer::getSurface() {
	if (!_surfaceCallback.empty()) {
		return _surfaceCallback();
	}
	return NULL;
}

}
