#pragma once

#include <canvas/size.h>
#include <canvas/rect.h>

namespace canvas {
	class Surface;
}

namespace player {
namespace mcanvas {

class SurfaceWrapper {
public:
	SurfaceWrapper( canvas::Surface *surface, bool isPrimary );
	virtual ~SurfaceWrapper();

	canvas::Surface *surface();

	void setFlip( bool horizontal, bool vertical );
	bool isFlippedH() const;
	bool isFlippedV() const;

	void setScaledSize( const canvas::Size &size );
	canvas::Size getScaledSize() const;

	void replaceSurface( canvas::Surface *newSurface );

	bool needScale() const;

	void rotation( int degrees );
	int rotation() const;

	bool isPrimary() const;

	void setCrop( canvas::Rect& rect );
	canvas::Rect getCrop() const;
	bool isCropSet() const;
	void clearCrop();

private:
	canvas::Surface *_surface;
	bool _flipH;
	bool _flipV;
	canvas::Size _scaledSize;
	int _rotation;
	bool _isPrimary;
	canvas::Rect _cropRect;
	bool _useCrop;

	SurfaceWrapper() {}
};

typedef SurfaceWrapper * SurfaceWrapperPtr;

}
}
