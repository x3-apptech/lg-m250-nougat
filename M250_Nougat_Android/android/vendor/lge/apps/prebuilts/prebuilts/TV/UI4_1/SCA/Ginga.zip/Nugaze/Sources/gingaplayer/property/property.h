#pragma once

#include <canvas/point.h>
#include <canvas/size.h>
#include <canvas/rect.h>
#include <util/keydefs.h>
#include <util/log.h>
#include <string>

namespace player {

class Property {
public:
	Property( void );
	virtual ~Property();

	bool assign( const char *value );

    template<typename T> bool assign(const T *value);

    template<typename T> bool assign(const T &value);

	virtual bool canStart() const;
	virtual bool needRefresh() const;
	virtual void markModified();
	virtual bool isOnlyDynamic(){
		return false;
	}
	bool apply();
	bool changed() const;

protected:
	virtual bool assignImpl(const void *pointer) = 0;

	virtual void applyChanges();

private:
	bool _changed;
};

template<typename T> bool Property::assign(const T *value) {
    LDEBUG("Property", "assign(const T *value)");
    return assignImpl(value);
}

template<typename T> bool Property::assign(const T &value) {
    LDEBUG("Property", "assign(const T &value)");
    return assignImpl(&value);
}

}

