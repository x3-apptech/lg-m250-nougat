#pragma once

#include "../../gifviewer.h"
#include "../../system.h"

namespace canvas {

class System;

namespace android {

class GifViewer : public canvas::GifViewer {
public:
	GifViewer( canvas::System *sys, Surface *surface );
	virtual ~GifViewer( void );

	virtual bool load( const std::string &file );
	virtual void stop();
	virtual int draw();

	virtual void setFreeze (bool freeze);
	virtual int getDuration();
private:
	System *_sys;
	bool _stopped;
};

}
}
