#pragma once

#include "property.h"

namespace player {

template<typename T>
class ForwardProperty : public Property {
public:
	typedef boost::function<void (const T&value)> SetFunction;

	ForwardProperty( const SetFunction &setter, bool onlyDynamic=false ) : _set( setter ),  _onlyDynamic(onlyDynamic) {}
	virtual ~ForwardProperty() {}

	virtual bool isOnlyDynamic(){
		return _onlyDynamic;
	}

protected:
	virtual bool assignImpl(const void *pointer) {
        LDEBUG("ForwardProperty", "assign(const void *pointer)");
	    const T &value = *((T*) pointer);
		_set( value );
		return true;
	}

private:
	SetFunction _set;
	bool _onlyDynamic;
};

}

