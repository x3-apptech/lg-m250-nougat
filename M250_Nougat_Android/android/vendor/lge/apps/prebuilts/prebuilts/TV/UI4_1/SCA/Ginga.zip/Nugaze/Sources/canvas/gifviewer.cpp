#include "gifviewer.h"
#include "surface.h"
#include "impl/android/gifviewer.h"
#include <util/log.h>
#include <util/mcr.h>
#include <assert.h>

namespace canvas {

GifViewer *GifViewer::create( System *sys, Surface *surface ) {
	UNUSED(sys);
	return (GifViewer*)NULL;
}

GifViewer::GifViewer( canvas::Surface *surface )
	: _surface( surface )
{
	_surface->setCompositionMode( composition::source );
}

GifViewer::~GifViewer( void )
{
}

//	Widget
void GifViewer::resize( const Size & /*size*/ ) {
	//TODO
}

void GifViewer::move( const Point & /*point*/ ) {
	//TODO
}

Surface *GifViewer::surface() {
	assert(_surface);
	return _surface;
}

}
