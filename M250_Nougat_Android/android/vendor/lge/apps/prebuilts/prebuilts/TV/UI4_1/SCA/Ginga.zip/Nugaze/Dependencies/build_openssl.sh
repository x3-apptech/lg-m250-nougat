#!/bin/bash

. build_setup.sh

NAME="openssl-1.0.1e"
extract_sources $NAME
STAGE=$(make_stagedir)

./Configure android-armv7 --prefix=$STAGE

(cat Makefile | sed "s|CC= gcc|CC= $CC|" | sed "s|AR= ar|AR= $AR|" | sed "s|RANLIB= /usr/bin/ranlib|RANLIB= $RANLIB|") > Makefile.patch
cp Makefile Makefile.backup
mv Makefile.patch Makefile

make $MAKE_JOBS $MAKE_LOAD
make install
copy_binaries $STAGE
cp -vfR android ${TOOLS}/android-openssl
