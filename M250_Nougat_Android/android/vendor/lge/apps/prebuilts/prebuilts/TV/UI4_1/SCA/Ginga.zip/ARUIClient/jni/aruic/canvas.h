#include "types.h"

namespace aruic {
namespace canvas {

void newCanvas(const void *id);
void deleteCanvas(const void *id);

void getSize(const void *id, Size &size);

} // namespace canvas
} // namespace aruic
