#include <string.h>

#include "types.h"

namespace canvas {
namespace composition {

#define DO_ENUM_MODE_STRING(t) #t,
static const char* modeNames[] = {
    "NULL",
    UTIL_MODE_LIST(DO_ENUM_MODE_STRING)
    "LAST"
};
#undef DO_ENUM_TOUCH_STRING

mode getMode(const char *touchName) {
	for (int i = 0; i < LAST; i++) {
		if (strncmp(modeNames[i], touchName, strlen(modeNames[i])) == 0) {
			return (mode) i;
		}
	}

	return null;
}

const char *getModeName(mode e) {
	if (LAST < e || e < null) {
		e = null;
	}

	return modeNames[e];
}

} // namespace composition
} // namespace canvas
