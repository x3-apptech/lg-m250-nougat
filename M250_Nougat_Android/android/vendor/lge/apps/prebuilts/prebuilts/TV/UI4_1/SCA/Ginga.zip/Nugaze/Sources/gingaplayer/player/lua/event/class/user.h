#pragma once

#include "../event.h"

namespace player {
namespace event {
namespace user {

//	Event class methods
std::string postEvent(System *sys, lua_State *st, bool isOut, int eventPos);
void dispatchUser(Module &module, LuaEvent &event);

}
}
}

