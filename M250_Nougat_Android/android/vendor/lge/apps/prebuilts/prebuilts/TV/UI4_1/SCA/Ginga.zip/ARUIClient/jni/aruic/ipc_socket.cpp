#include "ipc_socket.h"
#include "log.h"
#include <stdio.h>
#include <sys/socket.h>
#include <sys/un.h>

namespace aruic {

ipc_socket::ipc_socket(const char* file): is_open(false) {
	_uds_fd = socket(PF_UNIX, SOCK_STREAM, 0);
	if(_uds_fd < 0) {
		E("socket() failed");
		return;
	}
	D("Connecting to socket address: %s", file);
	// start with a clean address structure;
	socklen_t len;
	memset(&address, 0, sizeof(struct sockaddr_un));
	// using abstract namespace for socket path
	address.sun_family = AF_LOCAL;
	address.sun_path[0] = '\0';
	strncpy(&address.sun_path[1], file, UNIX_PATH_MAX-1);
	len = offsetof(struct sockaddr_un, sun_path) + 1 + strlen(&address.sun_path[1]);

	if (connect(_uds_fd, (struct sockaddr *) &address, len) == 0) {
		D("connected.");
		is_open = true;
	} else E("socket connect() failed");
};

ipc_socket::~ipc_socket() {
	// Signal the closing of this thread and close
	int signal = 0;
	write(_uds_fd, &signal, sizeof(int));
	close(_uds_fd);
	is_open = false;
};

int ipc_socket::readData(void *buff, int length) {
    return read(_uds_fd, buff, length);
}

void ipc_socket::writeData(const void *buff, int length) {
	write(_uds_fd, buff, length);
}

bool ipc_socket::closed() {
	return !is_open;
}

} // namespace aruic
