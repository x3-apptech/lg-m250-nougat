#pragma once

#include "graphicplayer.h"
#include "../../canvas/gifviewer.h"
#include <util/keydefs.h>
#include "timelinetimer.h"

namespace player {

class GifPlayer : public GraphicPlayer {
public:
	GifPlayer( Device *dev );
	virtual ~GifPlayer();
	virtual bool isApplication() const;

protected:
	//	Types
	typedef std::pair<util::key::type, bool> SelectionEventData;

	virtual bool startPlay();
	virtual void stopPlay();
	virtual void refresh();
	virtual bool supportRemote() const;
	virtual void registerProperties();

	//	Events
	virtual void onSizeChanged( const canvas::Size &size );
	virtual void onPositionChanged( const canvas::Point &point );
	void sendKeyEvent( const SelectionEventData &data );

	// Properties
	void applyFreeze();
	void adjustDuration();
	void onTimerExpired(int time);

private:
	canvas::GifViewer *_gif;
	bool _freeze;
	int _gif_duration;
	int _next_frame_time_ms;
	TimeLineTimer* _frametimer;
};

}
