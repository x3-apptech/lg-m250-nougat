#include <string>
#include <vector>

namespace aruic {
namespace input {

void readInputEvent(std::vector<std::string> &event);

} // namespace input
} // namespace aruic
