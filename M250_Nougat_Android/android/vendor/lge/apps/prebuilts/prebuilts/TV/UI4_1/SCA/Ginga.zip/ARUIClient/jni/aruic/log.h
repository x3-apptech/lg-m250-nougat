#pragma once

#include <android/log.h>

static const char* TAG = "ARUIClient";

#define LOG_LEVEL_ERROR 1
#define LOG_LEVEL_WARN  2
#define LOG_LEVEL_INFO  3
#define LOG_LEVEL_DEBUG 4

#define USE_LOG_LEVEL LOG_LEVEL_WARN

#if USE_LOG_LEVEL >= LOG_LEVEL_ERROR
	#define  E(x...)  __android_log_print(ANDROID_LOG_ERROR, TAG, x)
#else
	#define  E(x...)
#endif

#if USE_LOG_LEVEL >= LOG_LEVEL_WARN
	#define  W(x...)  __android_log_print(ANDROID_LOG_WARN, TAG, x)
#else
	#define  W(x...)
#endif

#if USE_LOG_LEVEL >= LOG_LEVEL_DEBUG
	#define  D(x...)  __android_log_print(ANDROID_LOG_DEBUG, TAG, x)
#else
	#define  D(x...)
#endif

#if USE_LOG_LEVEL >= LOG_LEVEL_INFO
	#define  I(x...)  __android_log_print(ANDROID_LOG_INFO, TAG, x)
#else
	#define  I(x...)
#endif
