#include "converter.h"

#include <vector>

namespace canvas {
namespace android {

aruicRect::aruicRect(const canvas::Rect &rect) {
	x = rect.x;
	y = rect.y;
	w = rect.w;
	h = rect.h;
}

aruic::Rect &aruicRect::convert() { return (*this); }

canvasRect::canvasRect(const aruic::Rect &rect) {
	x = rect.x;
	y = rect.y;
	w = rect.w;
	h = rect.h;
}

canvas::Rect &canvasRect::convert() { return (*this); }

aruicPoint::aruicPoint(const canvas::Point &point) {
	x = point.x;
	y = point.y;
}

aruic::Point &aruicPoint::convert() { return (*this); }

aruicSize::aruicSize(const canvas::Size &size) {
	w = size.w;
	h = size.h;
}

aruic::Size &aruicSize::convert() { return (*this); }

canvasSize::canvasSize(const aruic::Size &size) {
	w = size.w;
	h = size.h;
}

canvas::Size &canvasSize::convert() { return (*this); }

aruicColor::aruicColor(const canvas::Color &color) {
	r = color.r;
	g = color.g;
	b = color.b;
	alpha = color.alpha;
}

aruic::Color &aruicColor::convert() { return (*this); }

aruicFont::aruicFont(const canvas::Font &font)
{
	families = font.families();
	size = font.size();
	bold = font.bold();
	italic = font.italic();
	smallCaps = font.smallCaps();
}

aruic::Font &aruicFont::convert() { return (*this); }

} // namespace android
} // namespace canvas
