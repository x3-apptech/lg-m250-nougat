#include "config.h"

namespace aruic {
namespace config {

static std::string configPort;

void setPort(std::string port) {
	configPort = port;
}

std::string getPort() {
	return configPort;
}

} // namespace config
} // namespace aruic
