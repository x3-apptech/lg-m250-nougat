#include "tcp.h"
#include "../event.h"
#include "../../lua.h"
#include <util/id/ident.h>
#include <util/lexical_cast.hpp>
#include "../cmdline.h"

#include <iostream>

namespace player {
namespace event {
namespace tcp {

Module *moduleTCP = NULL;

std::string postEvent(System *sys, lua_State * st, bool /*isOut*/, int eventPos) {
	Module *module = Module::get( st );
	moduleTCP = module;
	if (!module) {
		return "[event::tcp] Invalid event module";
	}

	std::string value = lua::getField(st, eventPos, "type");
	if (value == "") {
		return "[event::tcp] Invalid type";
	}

	if (value == "connect") {
		std::string host = lua::getField(st, eventPos, "host");
		if (host == "") {
			return "[event::tcp] Invalid host";
		}

		std::string port = lua::getField(st, eventPos, "port");
		if (port == "") {
			return "[event::tcp] Invalid port";
		}

		/*LuaEvent event("tcp");
		event.set<std::string>("type", "connect");
		event.set<std::string>("host", host);
		event.set<std::string>("port", port);

		util::id::Ident id;*/

		value = lua::getField( st, eventPos, "timeout" );
		// FIXME: send data to pipe
		sys->cmdout << "TCP_CONNECT"
					<< " " << host
					<< " " << port
					<< " " << value
					<< std::endl;
		/*if (value != "") {
			util::DWORD timeout;
			if (util::lexical_cast(value,timeout)) {
				id = module->connect(host, port, timeout);
			} else {
				LWARN("tcp", "Invalid timeout value");
				id = module->connect(host, port);
			}
		} else {
			id = module->connect(host, port);
		}

		std::string r;
		if (util::id::isValid(id) && util::lexical_cast(id->getID(),r)) {
			event.set<std::string>("connection", r);
		} else {
			event.set<std::string>("error", "Connection failed");
		}

		module->dispatchIn(event, true);*/

		return "";
	}

	if (value == "disconnect") {
		value = lua::getField( st, eventPos, "connection" );
		if (value == "") {
			//return luaL_error( st, "[event::tcp] Invalid connection" );
			LWARN("event::tcp", "Invalid connection");
		}

		bool res;
		util::id::ID_TYPE r;
		if (util::lexical_cast(value,r))
			res = module->disconnect(r);
		else {
			LWARN("tcp", "can't find ID_TYPE for disconnect id");
			res = false;
		}

		if (!res) {
			//return luaL_error( st, "[event::tcp] Invalid connection" );
			LWARN("event::tcp", "Invalid connection");
		}

		return "";
	}

	if (value == "data") {
		bool result;

		//	Get connection
		value = lua::getField( st, eventPos, "connection" );
		if (value == "") {
			return "[event::tcp] Invalid connection";
		}
		util::id::ID_TYPE conn;
		if (!util::lexical_cast(value,conn)) {
			LWARN("tcp", "invalid connection ID_TYPE");
			return "[event::tcp] Invalid connection type";
		}

		//	Get value
		value = lua::getField( st, eventPos, "value" );
		if (value == "") {
			return "[event::tcp] Invalid value";
		}
		std::string val=value;

		//	Get timeout
		value = lua::getField( st, eventPos, "timeout" );
		if (value != "") {
			util::DWORD r;
			if (util::lexical_cast(value,r)) {
				result = module->send( conn, val, r );
			} else {
				LWARN("tcp", "invalid timeout value for send");
				result = module->send( conn, val );
			}
		} else {
			result = module->send( conn, val );
		}

		if (!result) {
			return util::format("[event::tcp] Error, cannot send data: value=%s", val.c_str() );
		}

		return "";
	}

    return util::format("[event::tcp] Invalid type: type=%s", value.c_str());
}

void connectTCP( std::string host, std::string port, std::string timeoutStr, bool allow) {
	util::id::Ident id;

	LuaEvent event("tcp");
	event.set<std::string>("type", "connect");
	event.set<std::string>("host", host);
	event.set<std::string>("port", port);

	if (moduleTCP != NULL) {
		if (allow) {
			if (timeoutStr != "") {
				util::DWORD timeout;
				if (util::lexical_cast(timeoutStr,timeout)) {
					id = moduleTCP->connect(host, port, timeout);
				} else {
					LWARN("tcp", "Invalid timeout value");
					id = moduleTCP->connect(host, port);
				}
			} else {
				id = moduleTCP->connect(host, port);
			}

			std::string r;
			if (util::id::isValid(id) && util::lexical_cast(id->getID(),r)) {
				event.set<std::string>("connection", r);
			} else {
				event.set<std::string>("error", "Connection failed");
			}
		} else {
			event.set<std::string>("error", "Connection failed");
		}

		moduleTCP->dispatchIn(event, true);
	}
}


void onDataReceived( Module *module, const std::string &val, int socketID) {
	LuaEvent event("tcp");
	std::string s;
	event.set<std::string>("type", "data");
	if (util::lexical_cast(socketID,s))
		event.set<std::string>("connection", s);
	event.set<std::string>("value", val);
	module->dispatchIn(event, false);
}

}
}
}
