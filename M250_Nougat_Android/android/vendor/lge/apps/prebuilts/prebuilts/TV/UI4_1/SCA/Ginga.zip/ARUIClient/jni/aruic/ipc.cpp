#include "ipc.h"
#include "log.h"
#include "config.h"

#include <boost/thread.hpp>

using namespace std;

namespace aruic {

ipc_socket &get_socket() {
    static boost::thread_specific_ptr<ipc_socket> connection;

    ipc_socket* conn = connection.get();
    if (conn == NULL || conn->closed()) {
        D("get_socket() - create new socket");
        conn = new ipc_socket(config::getPort().c_str());
        connection.reset(conn);
    }

    return *conn;
}

ipc::ipc(int opcode): _buffer(new Buffer()),
    _socket(get_socket())
{
    D("ipc(%d)", opcode);
    _buffer->append((char *)&opcode, sizeof(int));
}

ipc::~ipc() {
	delete(_buffer);
}

ipc &ipc::call() {
    D("call()");
    int length = _buffer->length();
    _socket.writeData(&length, sizeof(int));
    _socket.writeData(_buffer->buffer(),length);
    return (*this);
}

ipc &ipc::get(int &value) {
    _socket.readData(&value, sizeof(value));
    D("get() -> %d", value);
    return *this;
}

ipc &ipc::get(string &value) {
    int len;
    _socket.readData(&len,sizeof(len));
    char chars[len+1];
    _socket.readData(chars,len);
    chars[len] = '\0';
    value = chars;
    D("get() -> \"%s\"", value.c_str());
    return *this;
}

template<> string ipc::get() {
    string value;
    get(value);
    return value;
}

template<> bool ipc::get() {
	return (get<int>() ? true : false);
}

ipc& ipc::set(int value) {
    D("set(%d)", value);
    _buffer->append((char *)&value, sizeof(int));
    return *this;
}

ipc& ipc::set(float value) {
    D("set(%f)", value);
    _buffer->append((char *)&value, sizeof(float));
    return *this;
}

ipc& ipc::set(const string& value) {
    D("set(\"%s\")", value.c_str());
    int len = value.size();
    _buffer->append((char *)&len, sizeof(int));
    _buffer->append(value.c_str(), len);
    return *this;
}

invoke::invoke(const void *id, int opcode): ipc(opcode) {
    set(id);
}

} // namespace aruic
