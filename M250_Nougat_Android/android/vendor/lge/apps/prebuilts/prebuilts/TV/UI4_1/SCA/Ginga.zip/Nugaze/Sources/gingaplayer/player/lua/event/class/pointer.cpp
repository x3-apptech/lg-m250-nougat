
#include "pointer.h"
#include "../../lua.h"
#include "../../../../input/manager.h"
#include "canvas/system.h"
#include "util/log.h"
#include "util/string_utils.h"
#include "util/touch.h"

namespace player {
namespace event {
namespace pointer {

static std::string get_coordinate(lua_State *st, int eventPos, const char *name, int& value) {
    std::string str = lua::getField(st, eventPos, name);
    if (str == "") {
        return util::format("[player::event::pointer] Value for coordinate %s not found", name);
    }

    value = 0;
    try {
        util::from_string(str, value);
    }
    catch (...) {
        return util::format("[player::event::pointer] Invalid value for coordinate %s: \"%s\"", name, str.c_str());
    }

    return "";
}

std::string postEvent(System *sys, lua_State *st, bool isOut, int eventPos) {
    LDEBUG("lua:event::class::pointer", "postEvent");

	//	Get event type
	std::string value = lua::getField(st, eventPos, "type");
	if (value == "") {
		return "[player::event::pointer] Invalid type field in event";
	}

	util::touch::type touch = util::touch::getTouch(value);
	if (touch == util::touch::null) {
        return util::format("[player::event::pointer] Invalid type: type=%s", value.c_str());
	}

    //	Get pointer coordinates
    int x, y;
    {
        std::string err;
        if( !(err = get_coordinate(st, eventPos, "x", x)).empty() )
            return err;
        if( !(err = get_coordinate(st, eventPos, "y", y)).empty() )
            return err;
    }

    //	Get event module from stack
    Module *module = Module::get(st);
    if (module) {
        return "[player::event::touch] Invalid event module";
    }

    if (isOut) {
        module->dispatchPointer(touch, x, y);
    }
    else {
        dispatchPointer(module, touch, x, y, true);
    }

	return "";
}

void dispatchPointer(Module *module, util::touch::type touch, int x, int y, bool isInternal) {
    LDEBUG("lua:event::class::pointer", "dispatchPointer");

	LuaEvent event(touch, x, y);
	module->dispatchIn(event, isInternal);
}

}
}
}
