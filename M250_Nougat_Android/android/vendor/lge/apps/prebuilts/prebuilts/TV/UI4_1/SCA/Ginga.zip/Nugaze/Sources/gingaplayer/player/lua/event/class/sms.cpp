#include "sms.h"

#include "../../lua.h"
#include "util/log.h"
#include "util/string_utils.h"
#include "../cmdline.h"

#include <iostream>

#include <sstream>
#include <iomanip>

namespace player {
namespace event {
namespace sms {

/*static void dispatchSendSMS(
    Module *module,
    const std::string &to,
    const bool sent,
    const std::string &error,
    const std::string &id
) {
    LDEBUG("lua:event::class::sms",
        "dispatchSendSMS(module, \"%s\", \"%s\", \"%s\", \"%s\")",
        to.c_str(), (sent ? "true" : "false"), error.c_str(), id.c_str()
    );

	LuaEvent event("sms");
	event.set<std::string>("type", "send");
	event.set<std::string>("to", to);
	event.set<bool>("sent", sent);

	if (error != "") {
	    event.set<std::string>("error", error);
	}

	if (id != "") {
	    event.set<std::string>("id", id);
	}

	module->dispatchIn(event);
}*/

static std::string postRegisterEvent(System *sys, Module *module, lua_State *st, int eventPos) {
    // Get SMS port
    std::string value = lua::getField(st, eventPos, "port");
    if (value == "") {
        return "[player::event::sms] Invalid port field in event";
    }

    int port = util::from_string<int>(value);
    // FIXME: send data to pipe
    sys->cmdout << "SMS_REGISTER"
            << " " << port
            << " " << "true"
            << std::endl;

    return "";
}

static std::string postUnregisterEvent(System *sys, Module *module, lua_State *st, int eventPos) {
    // Get SMS port
    std::string value = lua::getField(st, eventPos, "port");
    if (value == "") {
        return "[player::event::sms] Invalid port field in event";
    }
    int port = util::from_string<int>(value);
    // FIXME: send data to pipe
    sys->cmdout << "SMS_REGISTER"
            << " " << port
            << " " << "false" <<
            std::endl;

    return "";
}

static std::string url_encode(const std::string &value) {
    std::ostringstream escaped;
    escaped.fill('0');
    escaped << std::hex;

    for (std::string::const_iterator i = value.begin(), n = value.end(); i != n; ++i) {
        std::string::value_type c = (*i);
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            escaped << c;
        }
        else {
            escaped << '%' << std::setw(2) << ((int) c) << std::setw(0);
        }
    }

    return escaped.str();
}

static std::string postSendEvent(System *sys, Module *module, lua_State *st, int eventPos) {
    // Get SMS destination
    std::string to = lua::getField(st, eventPos, "to");
    if (to == "") {
        return "[player::event::sms] Invalid destination field in event";
    }

    // Get SMS message contents
    std::string value = lua::getField(st, eventPos, "value");
    if (value == "") {
        return "[player::event::sms] Invalid message field in event";
    }

    // Get SMS message id, if defined
    std::string id = lua::getField(st, eventPos, "id");

    // FIXME: send data to pipe
    sys->cmdout << "SMS_SEND"
            << " " << to
            << " " << url_encode(value)
            << " " << id
            << std::endl;

    return "";
}

std::string postEvent(System *sys, lua_State *st, bool isOut, int eventPos) {
    LDEBUG("lua:event::class::sms", "postEvent");

	Module *module = Module::get(st);
	if (!module) {
		return "[player::event::sms] Invalid event module";
	}

	// Get event type
	std::string type = lua::getField(st, eventPos, "type");
	if (type == "") {
		//return luaL_error(st, "[player::event::sms] Invalid type field in event");
	}

	if (type == "register") {
        return postRegisterEvent(sys, module, st, eventPos);
	}

	if (type == "unregister") {
        return postUnregisterEvent(sys, module, st, eventPos);
	}

	std::string to = lua::getField(st, eventPos, "to");
	if (type == "send" || to != "") {
        return postSendEvent(sys, module, st, eventPos);
	}

    return "[player::event::sms] Unknown type in event";
}

}
}
}
