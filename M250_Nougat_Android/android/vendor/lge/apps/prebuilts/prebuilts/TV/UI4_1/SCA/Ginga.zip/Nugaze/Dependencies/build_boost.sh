#!/bin/bash

. build_setup.sh

# Package p7zip is needed. To install p7zip use the command-line below:
#
# sudo apt-get install p7zip-full

BOOST="boost_1_47_0"
rm -fR "${BOOST}" 2> /dev/null
7za x "${BOOST}.7z"
cd "${BOOST}"

# Applying adaptation patches
(echo "" >> "tools/build/v2/user-config.jam"; echo "NDK = ${NDK} ;" >> "tools/build/v2/user-config.jam")
cat "${CWD}/libboost_tools_build_v2_user-config-$TARGET_ARCH_ABI.jam.patch" >> "tools/build/v2/user-config.jam"
cat "${CWD}/libboost_libs_filesystem_v2_src_v2_operations.cpp.patch" | ed "libs/filesystem/v2/src/v2_operations.cpp"
patch -u boost/detail/endian.hpp < ../libboost_arm_endianness.patch

BUILDER="${CWD}/${BOOST}/builder"
mkdir -p ${BUILDER}
# Two corrections must be made to the source tree before building bjam:
#
# 1. Remove carriage-return characters ('\r') from bootstrap.sh (using fromdos from package tofrodos or dos2unix);
# 2. Give execution permission to all script files.
#
# (Ubuntu or Debian)
# To install tofrodos use the command-line below:
#
# $ sudo apt-get install tofrodos
#
# (CentOS, Fedora or RHEL)
# To install dos2unix use the command-line below:
#
# $ sudo yum install dos2unix
(cd "tools/build/v2/"; fromdos bootstrap.sh; dos2unix bootstrap.sh; find . -name '*.sh' | xargs chmod u+x; ./bootstrap.sh; ./b2 install --prefix="${BUILDER}") # Linux
export PATH=${BUILDER}/bin:${PATH}

bjam $MAKE_JOBS --disable-filesystem3 --without-python --without-serialization --without-mpi toolset=gcc-android4.7 link=static runtime-link=static target-os=linux --stagedir=android

echo "#define BOOST_FILESYSTEM_VERSION 2" >> boost/config/user.hpp

rm -fR ../$TARGET_ARCH_ABI/include/boost
cp -vfR boost ../$TARGET_ARCH_ABI/include
cp android/lib/*.a ../$TARGET_ARCH_ABI/lib
