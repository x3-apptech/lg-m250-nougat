#include "settings.h"
#include "lua/settings/settings.h"
#include <canvas/color.h>
#include <util/log.h>
#include <util/string_utils.h>
#include <util/cfg/cfg.h>
#include <util/cfg/configregistrator.h>
#include <util/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <stdio.h>
#include <boost/foreach.hpp>
#include <boost/tokenizer.hpp>

REGISTER_INIT_CONFIG(system) {
	root().addNode( "system" )
			.addValue( "language", "", "" )
			.addValue( "caption", "", "" )
			.addValue( "subtitle", "", "" )
			.addValue( "returnBitRate", "", (player::settings::PropertyTable::VoidPtr)NULL )	//deprecated
			.addValue( "returnBitRate(0)", "", "" )
			.addValue( "screenSize", "", (player::settings::PropertyTable::VoidPtr)NULL )
			.addValue( "screenOrientation", "", (player::settings::PropertyTable::VoidPtr)NULL )	//deprecated
			.addValue( "screenGraphicSize", "", (player::settings::PropertyTable::VoidPtr)NULL )
			.addValue( "audioType", "", (player::settings::PropertyTable::VoidPtr)NULL )
			.addValue( "screenSize(0)", "", "(0, 0)" )
			.addValue( "screenOrientation(0)", "", "portrait" )	//deprecated
			.addValue( "screenGraphicSize(0)", "", "(0, 0)" )
			.addValue( "audioType(0)", "", "stereo" )
			.addValue( "devNumber", "", (player::settings::PropertyTable::VoidPtr)NULL )	//deprecated
			.addValue( "devNumber(0)", "", "1" )
			.addValue( "classType", "", "active" )	//deprecated
			.addValue( "classType(0)", "", "active" )
			.addValue( "info", "", (player::settings::PropertyTable::VoidPtr)NULL )	//deprecated
			.addValue( "info(0)", "", "" )
			.addValue( "classNumber", "", "1" )
			.addValue( "CPU", "", "" )
			.addValue( "memory", "", "" )
			.addValue( "operatingSystem", "", "" )
			.addValue( "javaConfiguration", "", "" )
			.addValue( "javaProfile", "", "" )
			.addValue( "luaVersion", "", "5.1" )
			.addValue( "luaSupportedEventClasses", "", "key,ncl,pointer,si,sms,tcp,user")	//deprecated
			.addValue( "nclVersion", "NCL language version", "3.0" )	//deprecated
			.addValue( "ncl.version", "NCL language version", "3.0" )
			.addValue( "gingaNCLProfile", "Language profile supported by the receiver", "Basic" )	//deprecated
			.addValue( "gingaNCLVersion", "", "Ginga.ar 2.0" )	//deprecated
			.addValue( "GingaNCL.version", "", "Ginga.ar 2.0" )
			.addValue( "GingaJ.version", "", "" );
}

REGISTER_INIT_CONFIG(user) {
		root().addNode( "user" )
			.addValue( "age", "", "" )
			.addValue( "location", "", "" )
			.addValue( "genre", "", "" );
}

REGISTER_INIT_CONFIG(defaults) {
		root().addNode( "default" )
			.addValue( "focusBorderColor", "", "white" )
			.addValue( "selBorderColor", "", "white" )
			.addValue( "focusBorderWidth", "", -3 )
			.addValue( "focusBorderTransparency", "", "0" );
}

REGISTER_INIT_CONFIG(service) {
	root().addNode( "service" )
			.addValue( "currentFocus", "", 0 )
			.addValue( "currentKeyMaster", "", "" );
}

REGISTER_INIT_CONFIG(si) {
	root().addNode( "si" )
			.addValue( "numberOfServices", "", 0 )
			.addValue( "numberOfPartialServices", "", 0 )
			.addValue( "channelNumber", "", 0 );
}

REGISTER_INIT_CONFIG(channel) {
	root().addNode( "channel" )
		.addValue( "keyCapture", "", "true" )
		.addValue( "virtualKeyboard", "", "true" )
		.addValue( "keyboardBounds", "", "" );
}

REGISTER_INIT_CONFIG(settings) {
	root().addNode( "settings" )
	.addValue( "focusBorderTransparencyAsFloat", "", 0.0f );
}

static bool checkFloat( const std::string &value, float &f ) {
	std::string v = value;
	boost::trim( v );
	bool percentual = v.find( "%" ) == v.size() - 1;
	if (percentual) {
		boost::trim_right_if( v, boost::is_any_of( "%" ) );
	}
	if (!util::lexical_cast( v , f )) {
		LWARN("settings","checkFloat false");
		return false;
	}
	f = percentual ? f/100 : f;
	return true;
}


namespace player {
namespace settings {

typedef struct {
	prefix::type type;
	const char *name;
} PrefixType;

#define DO_ENUM_PREFIX_NAMES(t, s) { prefix::t, s },
static PrefixType prefixes[] = {
	{prefix::unknown, "unknown"},
	PREFIX_LIST(DO_ENUM_PREFIX_NAMES)
	{prefix::LAST, NULL}
};
#undef DO_ENUM_PREFIX_NAMES

#define FILL_META_FUNCTIONS( func, var ) \
int concat##func( lua_State *st ) { \
	std::string name = "system."; \
	name += var; \
	PropertyTable::PropName* values = static_cast<PropertyTable*>(util::cfg::get().get<void* const>(name))->getProperties(); \
	std::string parameter = (*values)[0]; \
	return Module::toConcat( st, parameter ); \
} \
\
int string##func( lua_State *st ) { \
	std::string name = "system."; \
	name += var; \
	PropertyTable::PropName* values = static_cast<PropertyTable*>(util::cfg::get().get<void* const>(name))->getProperties(); \
	std::string parameter = (*values)[0]; \
	return Module::toString( st, parameter ); \
} \
\
int call##func( lua_State *st ) { \
	std::string name = "system."; \
	name += var; \
	PropertyTable::PropName* values = static_cast<PropertyTable*>(util::cfg::get().get<void* const>(name))->getProperties(); \
	std::string parameter = (*values)[0]; \
	return Module::toCall( st, parameter ); \
}
FILL_META_FUNCTIONS(ScreenSize, "screenSize")
FILL_META_FUNCTIONS(ScreenOrientation, "screenOrientation")
FILL_META_FUNCTIONS(ScreenGraphicSize, "screenGraphicSize")
FILL_META_FUNCTIONS(AudioType, "audioType")
FILL_META_FUNCTIONS(ReturnBitRate, "returnBitRate")
FILL_META_FUNCTIONS(DevNumber, "devNumber")
FILL_META_FUNCTIONS(Info, "info")
#undef FILL_META_FUNCTIONS

void init( void ) {
	util::cfg::get().addNode( "global" );
	util::cfg::get().addNode( "shared" );

	char tmp[50];
	int win_w = util::cfg::getValue<int>("gui.window.size.width");
	int win_h = util::cfg::getValue<int>("gui.window.size.height");

	snprintf( tmp, sizeof(tmp), "(%d, %d)", win_h, win_w );		//(lines, pixels/line) according to 15606-2 Table 12
	std::string windowSize = std::string( tmp, strlen(tmp) );
	std::string windowOrientation = win_w > win_h ? "landscape" : "portrait";

	snprintf( tmp, sizeof(tmp), "(0, 0, %d, %d)", win_w, win_h );	//(left, top, width, height) according to 15606-2 Table 12
	std::string kbBounds = std::string( tmp, strlen(tmp) );

	snprintf( tmp, sizeof(tmp), "(%d, %d)",
				util::cfg::getValue<int>("gui.canvas.size.width"),
				util::cfg::getValue<int>("gui.canvas.size.height") );
	std::string canvasSize = std::string( tmp, strlen(tmp) );

	util::cfg::PropertyNode &sys = util::cfg::get( "system" );

#define DO_PROPERTY_TABLE(name, var, value) \
	static PropertyTable device##name( value.c_str() ); \
	device##name.addMetaMethod( "__concat", (PropertyTable::VoidPtr)&concat##name ); \
	device##name.addMetaMethod( "__tostring", (PropertyTable::VoidPtr)&string##name ); \
	device##name.addMetaMethod( "__call", (PropertyTable::VoidPtr)&call##name ); \
	sys.set( var, (PropertyTable::VoidPtr)(&device##name) );

	DO_PROPERTY_TABLE(ScreenSize, "screenSize", windowSize)
	sys.set( "screenSize(0)", windowSize );

	DO_PROPERTY_TABLE(ScreenOrientation, "screenOrientation", windowOrientation)
	sys.set( "screenOrientation(0)", windowOrientation );

	DO_PROPERTY_TABLE(ScreenGraphicSize, "screenGraphicSize", windowSize)	//1-Seg uses entire window
	sys.set( "screenGraphicSize(0)", windowSize );

	std::string audioType("stereo");
	DO_PROPERTY_TABLE(AudioType, "audioType", audioType)

	std::string returnBitRate("");
	DO_PROPERTY_TABLE(ReturnBitRate, "returnBitRate", returnBitRate)

	std::string devNumber("1");
	DO_PROPERTY_TABLE(DevNumber, "devNumber", devNumber)

	std::string info("");
	DO_PROPERTY_TABLE(Info, "info", info)
#undef DO_PROPERTY_TABLE

	util::cfg::PropertyNode &dft = util::cfg::get( "default" );
	dft.set( "focusBorderColor", "white" );
	dft.set( "selBorderColor", "white" );
	dft.set( "focusBorderWidth", -3 );
	dft.set( "focusBorderTransparency", "0" );

	util::cfg::get( "settings" ).set( "focusBorderTransparencyAsFloat", 0.0f );

	util::cfg::get( "channel" ).set( "keyboardBounds", kbBounds );

	{
		std::string vars;
		try {
			vars = util::cfg::getValue<std::string>("gui.player.gingacc.envvars");
		} catch (...) {}
		LDEBUG("settings","envVars:'%s'", vars.c_str());

		unsigned colon, period;
		boost::char_separator<char> sep(";");
		boost::tokenizer< boost::char_separator<char> > tokens(vars, sep);

		BOOST_FOREACH (const std::string& var, tokens)
			if(!var.empty() && (period = var.find_first_of(".")) != std::string::npos
					 && (colon = var.find_first_of(":")) != std::string::npos) {
				std::string group = var.substr(0, period), prop = var.substr(period+1, colon-(period+1)), value = var.substr(colon+1);
				try {
					util::cfg::get( group ).set( prop, value );
				} catch ( std::exception &e ) {
					try {
						util::cfg::get( group ).set( prop, atoi(value.c_str()) );
					} catch ( ... ) {
						LWARN("settings", "set error='%s'", e.what());
					}
				}
			}
	}
}

void fin( void ) {
	util::cfg::get().removeNode( "global" );
	util::cfg::get().removeNode( "shared" );
}

typedef struct
{
	prefix::type prefix;
	std::string prefixName;
	std::string varName;
} Property;

Property property( const std::string &value ) {

	Property p;
	p.prefix = prefix::unknown;
	p.varName = "";

	std::vector<std::string> tokens;
	boost::split( tokens, value, boost::is_any_of( "." ) );

	p.prefixName = tokens[0];
	if (tokens.size() == 2) {
		p.varName = tokens[1];
	}

	int i = 0;
	while (prefixes[i].name) {
		if (tokens[0] == prefixes[i].name) {
			p.prefix = prefixes[i].type;
		}
		i++;
	}
	return p;
}

namespace impl {
static std::vector<Module *> luaListeners;
}

void addListener( Module *module ) {
	impl::luaListeners.push_back( module );
}

void delListener( Module *module ) {
	std::vector<Module *>::iterator it = std::find( impl::luaListeners.begin(), impl::luaListeners.end(), module );
	if (it != impl::luaListeners.end()) {
		impl::luaListeners.erase( it );
	}
}

void updateListeners() {
	BOOST_FOREACH( Module *m, impl::luaListeners ) {
		m->update();
	}
}

void setProperty( const std::string &name, const std::string &value, bool init /*=false*/) {

	LDEBUG("Player::settings", "set property, name=%s, value='%s'", name.c_str(), value.c_str());

	Property p = property( name );

	switch ( p.prefix ) {
		case prefix::unknown: {
			if (init) {
                // Media elements may refer to another <media> element of the same document.
                // All attributes and child elements defined by the referred element are
                // inherited by the referring element. We need to prevent player from attempt
                // to add one property several times.
                if (!util::cfg::get("global").hasValue(name)) {
                    util::cfg::get("global").addValue(name, "", value);
                }
			} else {
				util::cfg::get( "global" ).set( name, value );
			}
            updateListeners();
			break;
		}
		case prefix::system:
		case prefix::user:
		case prefix::si: {
			if (value != "") {
				LERROR("Player::settings", "%s is a read only group of environment variables", p.prefixName.c_str());
			}
			break;
		}
		case prefix::shared: {
			if (init) {
				if (!p.varName.empty()) {
					util::cfg::get( "shared" ).addValue( p.varName, "", value );
				}
			} else {
				util::cfg::setValue( name, value );
			}
			updateListeners();
			break;
		}
		case prefix::defaults: {
			if (!value.empty()) {
				if (p.varName == "focusBorderColor" || p.varName == "selBorderColor") {
					canvas::Color tmp;
					if (canvas::color::get( value.c_str(), tmp )) {
						util::cfg::setValue( name, value );
					} else {
						LWARN("Player::settings", "invalid %s, value=%s", p.varName.c_str(), value.c_str());
					}
				} else if (p.varName == "focusBorderWidth") {
					util::cfg::get().setStr( name, value );
				} else if (p.varName == "focusBorderTransparency") {
					float tmp = 0.0;
					if (checkFloat( value, tmp )) {
						util::cfg::setValue( "settings.focusBorderTransparencyAsFloat", tmp );
						util::cfg::setValue( name, value );
					}
				}
				updateListeners();
			}
			break;
		}
		case prefix::service:
		case prefix::channel: {
			if (!value.empty()) {
				if (p.varName == "currentFocus") {
				    int index;
				    if (util::lexical_cast(value,index))
                        util::cfg::setValue(name, index);
				    else {
				        LWARN("Player::settings",
                            "setProperty(\"%s\", \"%s\"): bad cast",
                            name.c_str(), value.c_str());
				    }
				}
				else if (!p.varName.empty() && !util::cfg::get(p.prefixName).hasValue(p.varName)) {
				    util::cfg::get(p.prefixName).addValue(p.varName, "", value);
				}
				else {
					util::cfg::setValue(name, value);
				}

				updateListeners();
			}
			break;
		}
		default:
			break;
	}
}

const std::string getProperty( const std::string &name ) {

	Property p = property( name );
	std::string value = "";

	switch ( p.prefix ) {
		case prefix::unknown: {
			value = util::cfg::get( "global" ).get<std::string>( name );
			break;
		}
		default: {
			std::string type = util::cfg::get().type( name ).name();
			//	Treat the Property Table and substitute with first value
			if ( type == "Pv") {
				PropertyTable::PropName* values = static_cast<PropertyTable*>(util::cfg::get().get<void* const>(name))->getProperties();
				value = (*values)[0];
			} else {
				value = util::cfg::get().asString( name );
			}
			break;
		}
	};

	LDEBUG("Player::settings", "get var, name=%s, value=%s", name.c_str(), value.c_str());
	return value;
}


}
}
