#include "webviewer.h"

#include "../../color.h"
#include "../../rect.h"
#include "../../surface.h"

#include <util/log.h>

#include <aruic/webviewer.h>

namespace canvas {
namespace android {

using namespace aruic;

WebViewer::WebViewer(Surface *surface):
    canvas::WebViewer(surface)
{
	LDEBUG("android::WebViewer", "WebViewer(Surface *surface)");
	aruic::webviwer::newWebViewer(this, surface);
}

WebViewer::~WebViewer(void) {
	LDEBUG("android::WebViewer", "~WebViewer(void)");
	aruic::webviwer::deleteWebViewer(this);
}

bool WebViewer::load(const std::string &file) {
	LDEBUG("android::WebViewer", "load(const std::string &file)");
	return aruic::webviwer::load(this, file);
}

void WebViewer::stop() {
	LDEBUG("android::WebViewer", "stop()");
	aruic::webviwer::stop(this);
}

void WebViewer::draw() {
	LDEBUG("android::WebViewer", "draw()");
	aruic::webviwer::draw(this);
}

void WebViewer::dispatch(const player::event::LuaEvent &event) {
    LDEBUG("WebViewer", "Received %s", ((std::string) event).c_str());

    if (event.isKey()) {
        std::string key = event.get<std::string>("key");
        bool isUp = event.isUp();
        aruic::webviwer::dispatchKey(this, key, isUp);
    }

    if (event.isPointer()) {
        std::string touch = event.get<std::string>("type");
        int x = event.getX();
        int y = event.getY();
        aruic::webviwer::dispatchPointer(this, touch, x, y);
    }
}

}
}

