#pragma once

#include "graphicplayer.h"
#include <util/keydefs.h>

namespace canvas {
	class NclViewer;
}

namespace player {

class NclPlayer : public GraphicPlayer {
public:
	NclPlayer( Device *dev );
	virtual ~NclPlayer();

	virtual bool isApplication() const;
	canvas::Surface *getSurface();

protected:
	//	Types
	typedef std::pair<util::key::type, bool> SelectionEventData;

	virtual bool startPlay();
	virtual void stopPlay();
	virtual void refresh();
	virtual bool supportRemote() const;
	virtual void registerProperties();

	//	Events
	virtual void onSizeChanged( const canvas::Size &size );
	virtual void onPositionChanged( const canvas::Point &point );
	void sendKeyEvent( const SelectionEventData &data );

private:
	canvas::NclViewer *_ncl;
	player::Device *_embDev;
};

}
