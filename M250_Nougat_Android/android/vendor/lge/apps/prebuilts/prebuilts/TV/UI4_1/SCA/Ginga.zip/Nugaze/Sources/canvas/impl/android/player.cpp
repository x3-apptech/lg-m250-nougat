#include "player.h"
#include "mediaplayer.h"

#include <util/log.h>

namespace canvas {
namespace android {

Player::Player()
{
	LDEBUG("android::Player", "Player()");
}

Player::~Player()
{
	LDEBUG("android::Player", "~Player()");
}

canvas::MediaPlayer *Player::create( System * /*sys*/ ) const {
	LDEBUG("android::Player", "create(system)");
	return new MediaPlayer();
}

}
}

