#include "../../color.h"
#include "../../font.h"
#include "../../point.h"
#include "../../rect.h"
#include "../../size.h"

#include <aruic/types.h>

namespace canvas {
namespace android {

class aruicRect : public aruic::Rect {
public:
	aruicRect(const canvas::Rect &rect);
	aruic::Rect &convert();
};

class canvasRect : public canvas::Rect {
public:
	canvasRect(const aruic::Rect &rect);
	canvas::Rect &convert();
};

class aruicPoint : public aruic::Point {
public:
	aruicPoint(const canvas::Point &point);
	aruic::Point &convert();
};

class aruicSize : public aruic::Size {
public:
	aruicSize(const canvas::Size &size);
	aruic::Size &convert();
};

class canvasSize : public canvas::Size {
public:
	canvasSize(const aruic::Size &rect);
	canvas::Size &convert();
};

class aruicColor : public aruic::Color {
public:
	aruicColor(const canvas::Color &color);
	aruic::Color &convert();
};

class aruicFont : public aruic::Font {
public:
	aruicFont(const canvas::Font &font);
	aruic::Font &convert();
};

} // namespace android
} // namespace canvas
