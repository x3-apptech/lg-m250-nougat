#pragma once

#include "../player/lua/event/types.h"

#include "canvas/input.h"
#include "util/string_utils.h"

#include <boost/interprocess/containers/stable_vector.hpp>

#include <string>

namespace player {
namespace input {

class Listener;
typedef boost::container::stable_vector<Listener *> Listeners;

class ListenerId {
public:
    ListenerId(const std::string& _name, const void* _id):
        name(_name),
        id(_id)
    {
        // Nothing to do.
    };

    bool operator==(const ListenerId &that) const {
        return (this->id == that.id);
    };

    operator std::string() const {
        return name + "::" + util::to_string(id);
    };

private:
    const std::string name;

    const void *id;
};

class Manager {
public:
	Manager( void );
	virtual ~Manager( void );

	bool dispatch(const event::LuaEvent &event);

	bool addInputListener(
       const ListenerId &id,
       const event::InputCallback &callback,
       const ::util::key::Keys &keys=::util::key::Keys()
    );

	bool delInputListener(const ListenerId &id);

	void updateGlobalKeys( bool isAdd, const ::util::key::Keys &keys );

	void onGlobalKeysChange(const canvas::ReservedKeysCallback &callback);

private:
	void cullInputListeners();

	input::Listeners     _listeners;
	::util::key::Keys    _globalKeys;
	canvas::ReservedKeysCallback _onGlobalKeysChange ;
};

}
}
