#!/bin/bash

# Desired API and NDK versions and destination folder of
# the stand-alone toolchain, change them to suit your needs.
ndk_path=$1
system=linux-x86_64
api=9
ver=4.8
folder=~/bin/android-$api-ndk-$ver

sh $ndk_path/build/tools/make-standalone-toolchain.sh --system=$system --toolchain=arm-linux-androideabi-$ver --platform=android-$api --install-dir=$folder-arm-linux-androideabi
sh $ndk_path/build/tools/make-standalone-toolchain.sh --system=$system --toolchain=x86-$ver --platform=android-$api --install-dir=$folder-x86
