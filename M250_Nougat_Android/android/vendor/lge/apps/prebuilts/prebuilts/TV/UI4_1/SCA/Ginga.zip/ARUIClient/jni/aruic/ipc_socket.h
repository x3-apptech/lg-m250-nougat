#pragma once

#include <boost/asio.hpp>

namespace aruic {

class ipc_socket {
public:
    ipc_socket(const char* file);
    virtual ~ipc_socket();

    bool closed();

    int readData(void *buff, int length);
	void writeData(const void *buff, int length);

private:
    struct sockaddr_un address;
    bool is_open;
    int _socket; // to pass the FD of the new UDS
    int _uds_fd;
};

} // namespace awrc
