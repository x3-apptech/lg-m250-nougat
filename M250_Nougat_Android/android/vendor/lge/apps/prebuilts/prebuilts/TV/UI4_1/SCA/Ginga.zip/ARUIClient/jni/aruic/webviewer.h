#include "types.h"

#include <string>

namespace aruic {
namespace webviwer {

void newWebViewer(void * id, Surface *surface);
void deleteWebViewer(void * id);

bool load(void * id, const std::string &file);
void stop(void * id);
void draw(void * id);

void dispatchKey(void * id, const std::string &key, bool isUp);
void dispatchPointer(void * id, const std::string &touch, int x, int y);

} // namespace webviwer
} // namespace aruic
