#pragma once
#include <string>

namespace br {
namespace pucrio {
namespace telemidia {
namespace ncl {
namespace layout {

typedef struct {
	std::string name;
	int number;
} Device;

}
}
}
}
}
