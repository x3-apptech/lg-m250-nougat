
#include "gifviewer.h"
#include "../../../util/log.h"
#include "../../surface.h"
#include <aruic/gifviewer.h>

// Need to call these functions when appropriate
//void onMediaStopped();
//void onFrameReady();

namespace canvas {
namespace android {

GifViewer::GifViewer( canvas::System *sys, Surface *surface ):
	canvas::GifViewer(surface), _sys(sys)
{
	aruic::gifviewer::newGifViewer(this, surface);
	_stopped = false;
}

GifViewer::~GifViewer( void ) {
	_stopped = true;
	aruic::gifviewer::deleteGifViewer(this);
}

bool GifViewer::load( const std::string &file ) {
	LDEBUG("GifViewer", "load(%s)", file.c_str());
	return aruic::gifviewer::load(this, file);
}

void GifViewer::stop() {
	_stopped = true;
	LDEBUG("GifViewer", "stop()");
	aruic::gifviewer::stop(this);
}

int GifViewer::draw() {
	if (!_stopped) {
		int next_frame_ms = aruic::gifviewer::draw(this);
		if (next_frame_ms >= 0) {
			surface()->markDirty();
			surface()->flush();
		}
		return next_frame_ms;
	}
	LWARN("GifViewer", "draw() error: media not playing");
	return -1; // error: media is not playing
}

void GifViewer::setFreeze(bool freeze) {
	LDEBUG("GifViewer", "setFreeze(%s)", freeze?"true":"false");
	aruic::gifviewer::setFreeze(this,freeze);
}

int GifViewer::getDuration() {
	int duration = aruic::gifviewer::getDuration(this);
	LDEBUG("GifViewer", "getDuration() returns %d", duration);
	return duration;
}

}
}
