#include "key.h"
#include "../../lua.h"
#include "../../../../input/manager.h"
#include <canvas/system.h>
#include "util/log.h"

namespace player {
namespace event {
namespace key {

//	Event key types
enum type {
	unknown = 0,
	press,
	release
};

static type getKeyEventType(const std::string &name) {
	if (name == "press") {
		return press;
	}

	if (name == "release") {
		return release;
	}

    return unknown;
}

std::string postEvent( System *sys, lua_State *st, bool isOut, int eventPos ) {
    LDEBUG("lua:event::class::key", "postEvent");

	//	Get event type
	std::string value = lua::getField(st, eventPos, "type");
	if (value == "") {
		return "[event::key] Invalid type field in event";
	}

	type type = getKeyEventType(value);
	if (type == unknown) {
        return util::format("[player::event::key] Invalid type: type=%s", value.c_str());
	}

    //	Get key field
    value = lua::getField( st, eventPos, "key" );
    if (value == "") {
        return "[event::key] Invalid key field in event";
    }

    util::key::type key = util::key::getKey( value );
    if (key == util::key::null){
        return util::format("[player::event::key], Invalid key: key=%s", value.c_str());
    }

    //	Get event module from stack
    Module *module = Module::get(st);
    if (!module) {
        return "[player::event::key] Invalid event module";
    }

    if (isOut) {
        module->dispatchKey(key, type == release);
    }
    else {
        dispatchKey(module, key, type == release, true);
    }

	return "";
}

void dispatchKey( Module *module, util::key::type key, bool isUp, bool isInternal ) {
    LDEBUG("lua:event::class::key", "dispatchKey");

	LuaEvent event(key, isUp);
	module->dispatchIn(event, isInternal);
}

}
}
}
