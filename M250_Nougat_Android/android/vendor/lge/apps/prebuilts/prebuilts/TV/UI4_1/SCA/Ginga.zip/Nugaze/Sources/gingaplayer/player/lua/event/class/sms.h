#pragma once

#include "../event.h"

#include <string>

namespace player {
namespace event {
namespace sms {

std::string postEvent(System *sys, lua_State *st, bool isOut, int eventPos);

}
}
}
