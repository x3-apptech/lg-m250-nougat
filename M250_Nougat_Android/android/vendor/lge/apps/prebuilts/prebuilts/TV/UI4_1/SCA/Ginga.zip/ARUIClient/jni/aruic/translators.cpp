#include "translators.h"

namespace aruic {

template<> ipc& ipc::get(Color& value) {
    return (*this)
        .get(value.r)
        .get(value.g)
        .get(value.b)
        .get(value.alpha);
}

template<> ipc& ipc::get(Rect& value) {
    return (*this)
        .get(value.x)
        .get(value.y)
        .get(value.w)
        .get(value.h);
}

template<> ipc& ipc::get(Size& value) {
    return (*this)
        .get(value.w)
        .get(value.h);
}

template<> ipc& ipc::set(const Color& value) {
    return (*this)
        .set(value.r)
        .set(value.g)
        .set(value.b)
        .set(value.alpha);
}

template<> ipc& ipc::set(const Font& value) {
    return (*this)
        .set(value.families)
        .set((int) value.size)
        .set(value.bold)
        .set(value.italic)
        .set(value.smallCaps);
}

/*
template<> ipc& ipc::set(const ImageData* value) {
    return (*this)
        .set(value->size.w)
        .set(value->size.h);
}
*/

template<> ipc& ipc::set(const Point& value) {
    return (*this)
        .set(value.x)
        .set(value.y);
}

template<> ipc& ipc::set(const Rect& value) {
    return (*this)
        .set(value.x)
        .set(value.y)
        .set(value.w)
        .set(value.h);
}

template<> ipc& ipc::set(const Size& value) {
    return (*this)
        .set(value.w)
        .set(value.h);
}

template<> ipc& ipc::set(const BYTE& value) {
    return set((int) value);
}

}
