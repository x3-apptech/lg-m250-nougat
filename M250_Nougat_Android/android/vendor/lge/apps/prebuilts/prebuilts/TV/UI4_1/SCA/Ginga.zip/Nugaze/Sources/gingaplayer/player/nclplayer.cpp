#include "nclplayer.h"
#include "../device.h"
#include "../system.h"
#include <canvas/nclviewer.h>
#include <util/mcr.h>
#include <boost/bind.hpp>
#include "../property/forwardproperty.h"
#include <canvas/surface.h>
#include <canvas/system.h>
#include <canvas/window.h>
#include <boost/filesystem/operations.hpp>

namespace fs = boost::filesystem;

namespace player {

NclPlayer::NclPlayer( Device *dev )
	: GraphicPlayer( dev )
{
	_embDev = NULL;
}

NclPlayer::~NclPlayer()
{
}

bool NclPlayer::startPlay() {
	bool result=false;
	if (GraphicPlayer::startPlay()) {
		//	Create ncl viewer
		_ncl = device()->createNclViewer( surface() );
		if (_ncl) {
			void* window = NULL;
			//_ncl->setDevice(getDevice());
			window = _ncl->prepare();
			if (!window) {
				LWARN("NclPlayer", "NclViewer instance has no window");
				return false;
			}
			const canvas::Size &s = surface()->getSize();
			canvas::Point point = this->surface()->getLocation();
			canvas::Rect position(point.x, point.y, s.w, s.h);

			std::string url = body();
			if (fs::exists( url ) && fs::is_regular_file( url )) {
				fs::path workingDir(url);
				if (chdir(workingDir.remove_filename().string().c_str()) != 0) {
					LDEBUG("NclPlayer", "Cannot change working directory: %s", workingDir.string().c_str());
					return false;
				}
				_embDev = (player::Device*)getDevice()->systemPlayer()->runEmbeddedPresentationManager( url, (void*)_ncl, position );
				_ncl->setSurfaceCallback( boost::bind(&NclPlayer::getSurface, this) );
				_ncl->setCallbackNeedRefresh( boost::bind(&NclPlayer::refresh, this) );
			}
			else LWARN("NclPlayer", "file '%s' not found", url.c_str());
			result=true;
		}
		else LWARN("NclPlayer", "NclViewer instance not created");
	}
	return result;
}

canvas::Surface *NclPlayer::getSurface() {
	if (!_embDev) {
		LWARN("NclPlayer", "getSurface() not embedded");
		return NULL;
	}
	return (canvas::Surface*)_embDev->system()->window()->getSurface();
}

void NclPlayer::stopPlay() {
	_ncl->stop();
	getDevice()->systemPlayer()->stopEmbeddedPresentationManager();
	GraphicPlayer::stopPlay();
	DEL(_ncl);
}

//	Events
void NclPlayer::onSizeChanged( const canvas::Size &size ) {
	//	Redraw html
	_ncl->resize( size );
}

void NclPlayer::onPositionChanged( const canvas::Point &point ) {
	_ncl->move( point );
}

void NclPlayer::refresh() {
	LINFO("NclPlayer", "refresh");
	if (_ncl) {
		LINFO("NclPlayer", "redrawing ncl view");
		_ncl->draw();
	}
}

bool NclPlayer::supportRemote() const {
	return true;
}

void NclPlayer::registerProperties() {
	//	Setup graphic player
	GraphicPlayer::registerProperties();

	ForwardProperty<SelectionEventData> *prop =
		new ForwardProperty<SelectionEventData>( boost::bind(&NclPlayer::sendKeyEvent, this, _1) );

	addProperty( property::type::selectionEvent, prop );
}

void NclPlayer::sendKeyEvent( const SelectionEventData &data ) {
	_ncl->dispatchKey( data.first, data.second );
}

bool NclPlayer::isApplication() const {
	return true;
}

}
