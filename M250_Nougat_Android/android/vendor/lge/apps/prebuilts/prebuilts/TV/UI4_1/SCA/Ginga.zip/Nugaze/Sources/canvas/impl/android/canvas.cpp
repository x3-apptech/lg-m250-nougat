#include "canvas.h"

#include "surface.h"
#include "converter.h"
#include "../../size.h"

#include <util/log.h>

#include <aruic/canvas.h>

namespace canvas {
namespace android {

Canvas::Canvas() {
    LDEBUG("android::Canvas", "Canvas()");
    aruic::canvas::newCanvas(this);
}

Canvas::~Canvas(void) {
    LDEBUG("android::Canvas", "~Canvas()");
    aruic::canvas::deleteCanvas(this);
}

std::string Canvas::name() {
	return "arui";
}

bool Canvas::getSizeImpl(Size &size) {
    LDEBUG("android::Canvas", "getSizeImpl(Size &size)");
    aruic::Size aSize;
    aruic::canvas::getSize(this, aSize);
    size = canvasSize(aSize).convert();
    return true;
}

canvas::Surface *Canvas::createSurfaceImpl(ImageData *img) {
    LDEBUG("android::Canvas", "createSurfaceImpl(ImageData *img)");
	return NULL; // this command is not implemented in server side
}

canvas::Surface *Canvas::createSurfaceImpl(const Rect &rect) {
    LDEBUG("android::Canvas", "createSurfaceImpl(const Rect &rect)");
	return new Surface(this, rect);
}

canvas::Surface *Canvas::createSurfaceImpl(const std::string &file) {
    LDEBUG("android::Canvas", "createSurfaceImpl(const std::string &file)");
	return new Surface(this, file);
}

}
}

