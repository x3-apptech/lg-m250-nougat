#include "ncl.h"
#include "../../lua.h"
#include "util/log.h"

namespace player {
namespace event {
namespace ncl {

std::string postEvent( System *sys, lua_State *st, bool isOut, int eventPos ) {
	//	Get event module from stack
	Module *module = Module::get( st );
	if (!module) {
		return "[event::ncl] Invalid event module";
	}

	//	Get type of event
	std::string value = lua::getField(st, eventPos, "type");
	if (value == "") {
		return "[event::ncl] Invalid type field in event";
	}

	evtType::type type = getEventType( value );
	if (type == evtType::unknown) {
		return util::format("[event::ncl] Invalid type: type=%s\n", value.c_str());
	}

	//	Get action
	value = lua::getField( st, eventPos, "action" );
    if (value == "") {
        // Old spec (2007) support
        value = lua::getField( st, eventPos, "transition" );
    }
	if (value == "") {
		return "[event::ncl] Invalid action field in event";
	}

	evtAction::type action = getEventAction( value );
	if (action == evtAction::unknown){
		return util::format("[event::ncl] Invalid action: action=%s", value.c_str());
	}

	switch (type) {
		case evtType::presentation: {
			std::string label = lua::getField(st, eventPos, "label");
			if (label == "") {
			    // Old spec (2007) support
			    label = lua::getField(st, eventPos, "area");
			}

			if (isOut){
				module->dispatchOut( evtType::presentation, action, label, "" );
			}else{
				dispatchPresentation( module, action, label, true );
			}

			break;
		}
		case evtType::attribution: {
			std::string name = lua::getField(st, eventPos, "name");
			if (name == "") {
			    // Old spec (2007) support
			    name = lua::getField(st, eventPos, "area");
			}
			if (name == "") {
				return "[event::ncl] Invalid name field in event";
			}

			value = lua::getField( st, eventPos, "value" );
			if (value == "" && action == evtAction::start) {
				return "[event::ncl] Invalid value field in event";
			}

			if (isOut){
				module->dispatchOut( evtType::attribution, action, name, value );
			}else{
				dispatchAttribution( module, name, action, value, true );
			}

			break;
		}
		case evtType::selection: {
			value = lua::getField( st, eventPos, "label" );
			if (value == "") {
			    // Old spec (2007) support
			    value = lua::getField(st, eventPos, "area");
			}
			if (value == "") {
				return "[event::ncl] Invalid label field in event";
			}
			module->dispatchOut( evtType::selection, action, value, "" );
			break;
		}
		default:
			break;
	}

	return "";
}

void dispatchPresentation( Module *module, evtAction::type action, const std::string &label, bool isInternal ) {
    LDEBUG("lua:event::class::ncl", "dispatchPresentation");

	LuaEvent event;
	event.set<std::string>("class", "ncl");
	event.set<std::string>("type", "presentation");
	event.set<std::string>("label", label);
	event.set<std::string>("action", getActionName( action ));
	module->dispatchIn(event, isInternal);
}

class LuaAttribution: public LuaEvent {
public:
    LuaAttribution(): LuaEvent() {
        // Nothing to do.
    };

    LuaAttribution(const LuaAttribution &that) : LuaEvent(that) {
        // Nothing to do.
    }

    virtual LuaEvent *clone() const {
        return new LuaAttribution(*this);
    }

    virtual void dispatch(lua_State *lua, LuaHandlers &handlers) const {
        std::string name = get<std::string>("name");
        lua_getfield(lua, LUA_GLOBALSINDEX, name.c_str());
        if (!lua_isnil(lua, -1)) {
            std::string value = get<std::string>("value");
            lua_pushstring(lua, value.c_str());
            lua_call(lua, 1, 1);
        }

        lua_pop(lua, 1);
    };
};

void dispatchAttribution( Module *module, const std::string &name, evtAction::type action, const std::string &value, bool isInternal ) {
    LDEBUG("lua:event::class::ncl", "dispatchAttribution");

	LuaAttribution event;
	event.set<std::string>("class", "ncl");
	event.set<std::string>("type", "attribution");
	event.set<std::string>("name", name);
	event.set<std::string>("action", getActionName( action ));
	event.set<std::string>("value", value);
	module->dispatchIn(event, isInternal);
}

}
}
}
