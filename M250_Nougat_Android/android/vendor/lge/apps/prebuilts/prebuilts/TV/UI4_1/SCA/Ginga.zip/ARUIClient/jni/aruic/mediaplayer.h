#include "types.h"

#include <string>

namespace aruic {
namespace mediaplayer {

void newMediaPlayer(void *id);
void deleteMediaPlayer(void *id);

bool initialize(void *id, const Rect &rect, const std::string &url);
bool initialize(void *id, const std::string &url);
void finalize(void *id);

void play(void *id);
void stop(void *id);
void pause(void *id, bool needPause);

void mute(void *id, bool needMute);
void volume(void *id, float vol);

void move(void *id, const Point &point);
void resize(void *id, const Size &size);

} // namespace mediaplayer
} // namespace aruic
