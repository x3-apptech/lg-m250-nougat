#include "manager.h"
#include <util/log.h>
#include <util/mcr.h>
#include <boost/bind.hpp>
#include <boost/foreach.hpp>

namespace player {
namespace input {

class Listener {
public:
	Listener(
          const ListenerId &id,
          const event::InputCallback &callback,
          const ::util::key::Keys &keys
    ):
		_id(id),
		_callback(callback),
		_keys(keys),
		_enabled(true)
	{
	    /* Nothing to do. */
	}

	virtual ~Listener(void) {}

	const ListenerId &id() const {
		return _id;
	}

	bool hasReservedKey(const event::LuaEvent &event) const {
		return (
			_keys.size() != 0 &&
			std::find( _keys.begin(), _keys.end(), event.getKey() ) != _keys.end()
        );
	}

	void dispatch(const event::LuaEvent &event) {
	    if (!_enabled) {
	        return;
	    }

	    if (!event.isKey() || hasReservedKey(event)) {
			LDEBUG("Manager", "Dispatch %s event to %s", event.name().c_str(), ((std::string) _id).c_str());
            _callback(event);
	    }
	}

	void reserveKeys( const ::util::key::Keys &keys ) {
		BOOST_FOREACH( ::util::key::type key, keys ) {_keys.insert(key);}
	}

	const ::util::key::Keys &getKeys() {
		return _keys;
	}

	bool isEnabled() const { return _enabled; }

	void enabled( bool enabled ){ _enabled = enabled; }

private:
	ListenerId _id;
	event::InputCallback _callback;
	::util::key::Keys _keys;
	bool _enabled;
};

struct ListenerFinder {
	const ListenerId &_id;
	ListenerFinder( const ListenerId &id ) : _id( id ) {}
	bool operator()( input::Listener *listener ) const {
		return listener->id() == _id;
	}
};

Manager::Manager( void )
{
}

Manager::~Manager( void )
{
	CLEAN_ALL(input::Listener *,_listeners);
}

bool Manager::addInputListener(
    const ListenerId &id,
    const event::InputCallback &callback,
    const ::util::key::Keys &keys
) {
	input::Listener *listener;
	ListenerFinder finder(id);

	LDEBUG("Manager",
        "Reserve keys: listeners=%d, id=%s, size=%d",
        _listeners.size(), ((std::string) id).c_str(), keys.size()
    );

	input::Listeners::iterator it=std::find_if( _listeners.begin(), _listeners.end(), finder );
	if (it == _listeners.end()) {
		listener = new input::Listener( id, callback, keys );
		_listeners.push_back( listener );
	}
	else {
		//  Listener found, add keys
		listener = (*it);
		listener->enabled( true );
		listener->reserveKeys( keys );
	}
	updateGlobalKeys(true, keys);
	return true;
}

bool Manager::delInputListener(const ListenerId &id) {
	input::Listener *listener;
	ListenerFinder finder(id);

	input::Listeners::iterator it=std::find_if( _listeners.begin(), _listeners.end(), finder );
	if (it != _listeners.end()) {
		listener = (*it);
		if(listener->isEnabled()) {
			listener->enabled( false );
			updateGlobalKeys(false, listener->getKeys());
			LDEBUG("Manager", "listener removed, id=%p", ((std::string) id).c_str());
			return true;
		}
	}
	return false;
}

bool Manager::dispatch(const event::LuaEvent &event) {
    LDEBUG("Manager", "dispatch(%s to %d listener(s)", ((std::string) event).c_str(), _listeners.size());

    // Iterate over a copy of the list of Input Listeners, so as to avoid
    // calling Listeners that were created in response to this same event.
    input::Listeners listeners(_listeners);
    for (input::Listeners::iterator i = listeners.begin(), n = listeners.end(); i != n; ++i) {
        (*i)->dispatch(event);
    }

    // Remove disabled Listeners.
    for (input::Listeners::iterator i = _listeners.begin(), n = _listeners.end(); i != n;) {
        Listener *listener = (*i);
        if (listener->isEnabled()) {
            ++i;
        }
        else {
            i = _listeners.erase(i);
            delete listener;
        }
    }

    return true;
}

void Manager::onGlobalKeysChange(const canvas::ReservedKeysCallback &callback){
	_onGlobalKeysChange = callback;
}

void Manager::updateGlobalKeys(bool isAdd, const ::util::key::Keys &keys)
{
	bool modified = false;
	if (!keys.size())
		return;

	::util::key::Keys::iterator k = keys.begin();
	::util::key::Keys::iterator gk;

	while (k != keys.end()) {
		util::key::type key = (util::key::type)*k;
		gk = _globalKeys.find(key);

		if (isAdd) {
			_globalKeys.insert(key);
			modified |= (gk == _globalKeys.end());
		} else {
			if (gk != _globalKeys.end()) {
				_globalKeys.erase(gk);
				modified |= _globalKeys.find(key) == _globalKeys.end();
			}
		}
		++k;
	}

	if(modified && !_onGlobalKeysChange.empty()){
		_onGlobalKeysChange( _globalKeys );
	}
}

}
}
