#include "mediaplayer.h"

#include "converter.h"

#include "../../rect.h"
#include "../../point.h"

#include <util/log.h>

#include <aruic/mediaplayer.h>

namespace canvas {
namespace android {

using namespace aruic;

MediaPlayer::MediaPlayer() {
	aruic::mediaplayer::newMediaPlayer(this);
}

MediaPlayer::~MediaPlayer(void) {
	aruic::mediaplayer::deleteMediaPlayer(this);
}

//	Initialization
bool MediaPlayer::initialize(const Rect &rect, const std::string &url) {
	return aruic::mediaplayer::initialize(this, aruicRect(rect).convert(), url);
}

bool MediaPlayer::initialize(const std::string &url) {
	return aruic::mediaplayer::initialize(this, url);
}

void MediaPlayer::finalize() {
	aruic::mediaplayer::finalize(this);
}

//	Stream operations
void MediaPlayer::play() {
	aruic::mediaplayer::play(this);
}

void MediaPlayer::stop() {
	aruic::mediaplayer::stop(this);
}

void MediaPlayer::pause(bool needPause) {
	aruic::mediaplayer::pause(this, needPause);
}

//	Volume
void MediaPlayer::mute(bool needMute) {
	aruic::mediaplayer::mute(this, needMute);
}

void MediaPlayer::volume(Volume vol) {
	aruic::mediaplayer::volume(this, vol);
}

//	Position/size
void MediaPlayer::move(const Point &point) {
	aruic::mediaplayer::move(this, aruicPoint(point).convert());
}

void MediaPlayer::resize(const Size &size) {
	aruic::mediaplayer::resize(this, aruicSize(size).convert());
}

}
}
