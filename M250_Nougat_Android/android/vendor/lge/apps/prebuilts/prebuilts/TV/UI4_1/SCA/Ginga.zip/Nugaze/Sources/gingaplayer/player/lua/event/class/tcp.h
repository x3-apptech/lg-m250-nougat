#pragma once

#include "../event.h"

namespace player {
namespace event {
namespace tcp {

//	Event class methods
std::string postEvent(System *sys, lua_State *st, bool isOut, int eventPos);
void connectTCP( std::string host, std::string port, std::string timeoutStr, bool allow);
void onDataReceived( Module *module, const std::string &val, int socketID);

}
}
}

