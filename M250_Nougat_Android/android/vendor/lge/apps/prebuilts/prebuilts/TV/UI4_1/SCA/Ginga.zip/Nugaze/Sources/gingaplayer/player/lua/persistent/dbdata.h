/*******************************************************************************

  Copyright (C) 2010, 2013 LIFIA - Facultad de Informatica - Univ. Nacional de La Plata

********************************************************************************

  This file is part of DTV-gingaplayer implementation.

    DTV-gingaplayer is free software: you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as published by the Free
  Software Foundation, either version 2 of the License.

    DTV-gingaplayer is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
  A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License along with
  this program. If not, see <http://www.gnu.org/licenses/>.

********************************************************************************

  Este archivo es parte de la implementación de DTV-gingaplayer.

    DTV-gingaplayer es Software Libre: Ud. puede redistribuirlo y/o modificarlo
  bajo los términos de la Licencia Pública General Reducida GNU como es publicada por la
  Free Software Foundation, según la versión 2 de la licencia.

    DTV-gingaplayer se distribuye esperando que resulte de utilidad, pero SIN NINGUNA
  GARANTÍA; ni siquiera la garantía implícita de COMERCIALIZACIÓN o ADECUACIÓN
  PARA ALGÚN PROPÓSITO PARTICULAR. Para más detalles, revise la Licencia Pública
  General Reducida GNU.

    Ud. debería haber recibido una copia de la Licencia Pública General Reducida GNU
  junto a este programa. Si no, puede verla en <http://www.gnu.org/licenses/>.

*******************************************************************************/

#pragma once

#include "types.h"
#include "../lua.h"
#include <string>
#include <vector>
#include <sstream>

namespace player {

namespace persistent {
	class NilData;
	class TableData;
}

namespace lua {

void pushValue( lua_State *st, const std::string &index, persistent::NilData & /*data*/ );
void pushValue( lua_State *st, const std::string &index, persistent::TableData &table );

} // end namespace lua

namespace persistent {

class DBDataVisitor;

class DBData {
public:
	DBData( dbdata::type type, const std::string &key );
	virtual ~DBData();

	virtual void push( lua_State * st )=0;
	virtual DBData *getCopy() const =0;
	virtual void visit( DBDataVisitor &visitor )=0;

	const std::string &key() const;
	std::string &mutableKey();
	const dbdata::type &type() const;

	static DBData *create( dbdata::type type, const std::string &key );

private:
	dbdata::type _type;
	std::string _key;
};

template<typename T>
class DBDataImpl : public DBData {
public:
	DBDataImpl( dbdata::type type, const std::string &key, const T &value ) : DBData(type, key), _data(value) {}
	virtual ~DBDataImpl() {}

	virtual void push( lua_State * st ) {
		player::lua::pushValue( st, key(), _data );
	}

	virtual DBData *getCopy() const {
		return new DBDataImpl<T>( type(), key(), _data );
	}

	virtual void visit( DBDataVisitor &visitor ) {
		visitor( _data );
	}

	T &data() {
		return _data;
	}

private:
	T _data;
};

class NilData {
public:
	template<class Storage>
	void serialize( Storage &storage ) {
		int n = 0;
		storage.serialize( "nil", n );
	}
};

class TableData {
public:
	TableData();
	TableData( const TableData &other );
	TableData( lua_State *st, int idx );
	virtual ~TableData();

	TableData &operator=( const TableData &other );
	DBData *operator[]( int pos );

	virtual void push( lua_State * st, const std::string &key );

	std::vector<DBData*> &table();
	void table( const std::vector<DBData*> &t );

	unsigned size() const;

	void add( DBData *data );

private:
	std::vector<DBData*> _table;
};

class DBDataVisitor {
public:
	virtual void operator()( int &data )=0;
	virtual void operator()( bool &data )=0;
	virtual void operator()( std::string &data )=0;
	virtual void operator()( NilData &data )=0;
	virtual void operator()( TableData &data )=0;
};

template<class Storage>
class DBDataVisitorImpl : public DBDataVisitor {
public:
	DBDataVisitorImpl( Storage &storage ) : _storage(storage) {}

	virtual void operator()( int &data ) {
		_storage.serialize( "data", data );
	}

	virtual void operator()( bool &data ) {
		_storage.serialize( "data", data );
	}

	virtual void operator()( std::string &data ) {
		_storage.serialize( "data", data );
	}

	virtual void operator()( NilData &data ) {
		_storage.serialize( "data", data );
	}

	virtual void operator()( TableData &data ) {
		_storage.serialize( "data", data );
	}

private:
	Storage &_storage;
	DBDataVisitorImpl & operator=( const DBDataVisitorImpl & ) {}
};

class DBDataLoader {
public:
	DBDataLoader() : _data(NULL) {}
	virtual ~DBDataLoader() { _data = NULL; }

	DBData *data()  { return _data; }
	void data( DBData *data ) { _data = data; }
private:
	DBData *_data;
};

} // end namespace persistent
} // end namespace player

namespace util {
namespace storage {

template<class Storage>
void serialize( Storage &storage, player::persistent::DBData &data ) {
	std::string type( player::persistent::dbdata::getName( data.type() ) );
	storage.serialize( "type",  type );
	storage.serialize( "key", data.mutableKey() );
	player::persistent::DBDataVisitorImpl<Storage> visitor( storage );
	data.visit( visitor );
}

template<class Storage>
void serialize( Storage &storage, player::persistent::DBDataLoader &loader ) {
	std::string typeName, key;
	storage.serialize( "type", typeName );
	storage.serialize( "key", key );
	player::persistent::dbdata::type type = player::persistent::dbdata::getType( typeName );
	player::persistent::DBData *data = player::persistent::DBData::create( type, key );
	player::persistent::DBDataVisitorImpl<Storage> visitor( storage );
	data->visit( visitor );
	loader.data( data );
}

template<class Storage>
void serialize( Storage &storage, player::persistent::TableData &table ) {
	unsigned size = table.size();
	storage.serialize("size", size);

	if (storage.isLoading()) {
		// Loading
		table.table().clear();
		for( unsigned i=0; i<size; i++ ) {
			std::stringstream pos;
			pos << "dbdata_";
			pos << i+1;
			player::persistent::DBDataLoader loader;
			storage.serialize( pos.str(), loader );
			table.add( loader.data() );
		}
	} else {
		// Saving
		for( unsigned i=0; i<size; i++ ) {
			std::stringstream pos;
			pos << "dbdata_";
			pos << i+1;
			storage.serialize( pos.str(), *table[i] );
		}
	}
}

} // end namespace storage
} // end namespace util
