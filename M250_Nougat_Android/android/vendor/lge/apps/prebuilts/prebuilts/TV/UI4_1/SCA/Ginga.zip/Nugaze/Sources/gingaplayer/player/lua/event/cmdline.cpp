#include "cmdline.h"
#include "gingaplayer/player/lua/event/class/tcp.h"

#include <map>
#include <iostream>
#include <string>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/ioctl.h>

namespace player {
namespace event {

static void handleLuaEvent(System *system, std::string &params) {
	player::event::LuaEvent event;

	// Parse parameters
	if (!event.fromString(params)) {
		LWARN("android::System", "table.fromString error");
		return;
	}

	// Dispatch event
	system->dispatch(event);

	// [DEBUG]
	// Verification
	std::string test;
	if (!event.toString(test)) {
		LWARN("android::System", "table.toString error");
		return;
	}

	LDEBUG("android::System", test.c_str());
	// [/DEBUG]
}

static void handleTCPConnect(System *system, std::string &params) {
	player::event::LuaEvent event;

	// Parse parameters
	if (!event.fromString(params)) {
		LWARN("android::System", "table.fromString error");
		return;
	}

	std::string host = event.get<std::string>("host");
	std::string port = event.get<std::string>("port");
	std::string timeout = event.get<std::string>("timeout");
	bool allow = event.get<bool>("allow");

	player::event::tcp::connectTCP(host, port, timeout, allow);

	// [DEBUG]
	// Verification
	std::string test;
	if (!event.toString(test)) {
		LWARN("android::System", "table.toString error");
		return;
	}

	LDEBUG("android::System", test.c_str());
	// [/DEBUG]
}

typedef void (*CmdHandler)(System *system, std::string &params);

static bool done = false;

void endCmdLinePoller() {
	done = true;
}

void pollCmdLine(System *system) {
	done = false;
	std::map<std::string, CmdHandler> handlers;
	handlers["LUA_EVENT"] = handleLuaEvent;
	handlers["TCP_CONNECT"] = handleTCPConnect;

	char input_buf[2048];
	boost::posix_time::milliseconds short_sleep(500);

	// ----- Unix Domain Socket ------
	const char* sock_name = "gingaSystemData";
    struct sockaddr_un address;
    int _uds_fd;
	_uds_fd = socket(PF_UNIX, SOCK_STREAM, 0);
	if(_uds_fd < 0) {
		LERROR("android::System", "socket() failed");
		return;
	}
	LDEBUG("android::System", "Connecting to system data socket");
	// start with a clean address structure;
	socklen_t len;
	memset(&address, 0, sizeof(struct sockaddr_un));
	// using abstract namespace for socket path
	address.sun_family = AF_LOCAL;
	address.sun_path[0] = '\0';
	strncpy(&address.sun_path[1], sock_name, UNIX_PATH_MAX-1);
	len = offsetof(struct sockaddr_un, sun_path) + 1 + strlen(&address.sun_path[1]);

	if (connect(_uds_fd, (struct sockaddr *) &address, len) != 0) {
		LERROR("android::System", "system data socket connect() failed");
		return;
	}

	LINFO("android::System", "cmdLinePoll running");
	for (;!done;) {
		// Send any available data as output
		std::string out_data = system->cmdout.str();
		len = out_data.length();
		if (len > 0) {
		    //LDEBUG("android::System", "Sending some data: %s", out_data.c_str());
		    write(_uds_fd, out_data.c_str(), len);
		    system->cmdout.str("");
		    system->cmdout.clear();
		}

		// Check data availability, to avoid reading blocking IO
		// this allows thread to be interrupted
		if (ioctl(_uds_fd, FIONREAD, &len) < 0) {
			// error, connection is closed
		    LDEBUG("android::System", "pollCmdLine: socket seems closed");
			break;
		}
		if (len == 0) {
		    //LDEBUG("android::System", "pollCmdLine: No data... sleeping for a while...");
			boost::this_thread::sleep(short_sleep);
			continue;
		}

		// Read input command line
		len = read(_uds_fd, input_buf, len);
		if (len == 0) continue; // hey... where's my data?! We checked before, so this should not happen...
		else if (len < 0) {
		    LERROR("android::System", "pollCmdLine: unexpected error reading data");
			break;
		}
		std::string input(input_buf,len);

		LDEBUG("android::System", "Input: \"%s\"", input.c_str());

		// Get command identifier
		unsigned int start = input.find_first_not_of(' ', 0);
		unsigned int end = input.find_first_of(' ', start);
		std::string command = input.substr(start, (end - start));
		LDEBUG("android::System", "Command: \"%s\"", command.c_str());

		// Get parameters
		unsigned int offset = input.find_first_not_of(' ', end);
		std::string params = input.substr(offset);
		LDEBUG("android::System", "Params: \"%s\"", params.c_str());

		// Retrieve command handler
		std::map<std::string, CmdHandler>::iterator i = handlers.find(command);
		if (i == handlers.end()) {
			LWARN("android::System", "Unknown input command: \"%s\"", input.c_str());
			continue;
		}

		// Call handler
		CmdHandler handle = i->second;
		handle(system, params);
	}

	int err;
	if (getsockopt(_uds_fd, SOL_SOCKET, SO_ERROR, &err, &len) < 0) {
		LDEBUG("android::System", "cmdLinePoll socket already closed");
	} else {
		LDEBUG("android::System", "cmdLinePoll closing socket");
		close(_uds_fd);
	}
	LINFO("android::System", "cmdLinePoll stopped");
}

} // namespace event
} // namespace player
