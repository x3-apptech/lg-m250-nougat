#!/bin/bash

. build_setup.sh

NAME="zlib-1.2.8"
extract_sources $NAME
STAGE=$(make_stagedir)

./configure --static --prefix=$STAGE --eprefix=$STAGE

(cat Makefile | \
    sed "s|CC=gcc|CC=$CC|" | \
    sed "s|AR=ar|AR=$AR|" | \
    sed "s|RANLIB=ranlib|RANLIB=$RANLIB|" \
) > Makefile.patch
cp Makefile Makefile.backup
mv Makefile.patch Makefile

make $MAKE_JOBS $MAKE_LOAD
make install
copy_binaries $STAGE

