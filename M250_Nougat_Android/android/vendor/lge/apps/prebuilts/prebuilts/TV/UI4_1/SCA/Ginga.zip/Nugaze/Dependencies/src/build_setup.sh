API=9
VER=4.8

CWD=${PWD}

TOOLS=$HOME/bin
if [ "$TARGET_ARCH_ABI" = "x86" ]; then
NDK=$TOOLS/android-$API-ndk-$VER-x86
BIN=$NDK/bin/i686-linux-android
elif [ "$TARGET_ARCH_ABI" = "armeabi" -o "$TARGET_ARCH_ABI" = "armeabi-v7a" ]; then
NDK=$TOOLS/android-$API-ndk-$VER-arm-linux-androideabi
BIN=$NDK/bin/arm-linux-androideabi
else
echo "Invalid architecture"
exit 1
fi
SYS=$NDK/sysroot

AR=$BIN-ar
CC="$BIN-gcc --sysroot=$SYS"
CXX="$BIN-g++ --sysroot=$SYS"
LD=$BIN-ld
RANLIB=$BIN-ranlib

CFLAGS=""
CPPFLAGS="${CFLAGS}"

function extract_sources {
    rm -fR "$1" 2> /dev/null
    tar -zvxf "$1.tar.gz"
    cd "$1"
}

function extract_bz2 {
    rm -fR "$1" 2> /dev/null
    tar -jvxf "$1.tar.bz2"
    cd "$1"
}

function make_stagedir {
    STAGE=$(pwd)/android/$TARGET_ARCH_ABI
    mkdir -p $STAGE
    echo $STAGE
}

function copy_binaries {
    mkdir -p ../../$TARGET_ARCH_ABI/include
    mkdir -p ../../$TARGET_ARCH_ABI/lib
    cp -vfR $1/include/* ../../$TARGET_ARCH_ABI/include
    cp -vfR $1/lib/*.a ../../$TARGET_ARCH_ABI/lib
    rm -fR $1
}
