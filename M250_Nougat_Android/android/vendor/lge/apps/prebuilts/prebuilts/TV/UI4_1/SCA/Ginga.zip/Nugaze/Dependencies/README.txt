Environment setup
=====

This environment was tested with Android NDK r8e toolchain on Linux x64.

Steps to build toolchain:

1. Extract android-ndk-r8e-linux-x86_64.tar.bz2 to $HOME/bin:

	$ tar -jvxf android-ndk-r8e-linux-x86_64.tar.bz2

2. Copy build_ndk_toolchain-x64.sh to $HOME/bin;
3. Run the build script, with proper parameters:

	$ ./build_ndk_toolchain-x64.sh <extracted_ndk_path> <system> <android_api> <ndk_version>

	Example:

	$ ./build_ndk_toolchain-x64.sh android-ndk-r8e linux-x86_64 14 4.7

If everything works, the built toolchain will be in $HOME/bin/android-<android_api>-ndk-<ndk_version>.


Build project dependencies
=====

To build all dependencies, open a command shell to the base Dependencies/ folder and type:

	$ ./build_all.sh

This will run all dependency build scripts in sequence. In general those scripts perform the steps below:

1. Unpack the respective source TARball;
2. Run the ./configure script to setup the building process;
3. Apply necessary patches to enable compilation with the Android toolchain;
4. Run make to build the library;
5. Copy static library binaries and header files to Dependencies/lib and Dependencies/include respectively.

After the build process is over the library source trees are redundant and can be deleted (this is not done automatically so they can be inspected in case something goes wrong).

The build scripts are intended as "executable documentation" on how the various dependencies were adapted to the Android environment; if need be, environment settings and/or library versions could be changed and the whole process repeated without much effort.


Build Valdroid (Valgrind for Android)
=====

Valdroid is a binary build from Valgrind 3.8.1 using the Android NDK.

Valgrind is an instrumentation framework for building dynamic analysis/profiling tools.

Steps to build Valdroid:

1. In order to fix a bug in Android NDK r8e, open header file $HOME/bin/android-14-ndk-4.7/sysroot/usr/include/elf.h and add a line "#include <sys/types.h>" before "#include <sys/exec_elf.h>";
2. Run build script for Valdroid:

	$ ./build_valgrind.sh

If everything works, compiled files will be written to android/data/local/valdroid under the base source folder.

For detailed information, see the Valdroid's project README:

https://github.com/xperroni/Valdroid/blob/master/README.md


Notes
=====

Starting at version 1.44, boost released a new revision of its filesystem library, "filesystem v3". This version relies exclusively on wide strings for encoding filesystem paths, in contrast to v2 which could be setup at compilation time to use 8-bit strings instead. This is troublesome because Android lacks proper support for the wchar_t type - the type is defined, but it's the wrong length (one byte prior to revision 9, four afterwards) and most of the standard C functions intended to handle wchar_t values are missing or dummies. Until proper support for wchar_t is added to Android, only versions of boost up to 1.47.0 (the last one to provide filesystem v2 as an option) can be compiled to the platform.
