#pragma once

#include <string>

extern "C" {
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
}

namespace player {
namespace lua {

void storeObject( lua_State *st, void *obj, const char *index );

template<class T>
inline T *getObject( lua_State *st, const char *index  ) {
	lua_getfield( st, LUA_REGISTRYINDEX, index );
	T *obj = (T *) lua_touserdata( st, -1 );
	lua_pop( st, 1 );
	return obj;
}

std::string getField(lua_State *st, int pos, const char *index);

void pushValue( lua_State *st, const std::string &index, int value );
void pushValue( lua_State *st, const std::string &index, bool value );
void pushValue( lua_State *st, const std::string &index, const std::string &value );

}
}

