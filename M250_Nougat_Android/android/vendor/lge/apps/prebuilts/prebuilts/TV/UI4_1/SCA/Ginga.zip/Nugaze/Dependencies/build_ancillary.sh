#!/bin/bash

. build_setup.sh

NAME="libancillary-0.9.1"
extract_sources $NAME
STAGE=$(make_stagedir)

(cat Makefile | \
    sed "s|CC=gcc|CC=$CC|" | \
    sed "s|AR=ar|AR=$AR|" | \
    sed "s|RANLIB=ranlib|RANLIB=$RANLIB|" \
) > Makefile.patch
cp Makefile Makefile.backup
mv Makefile.patch Makefile

make $MAKE_JOBS $MAKE_LOAD
#make install
rm -fR ../$TARGET_ARCH_ABI/include/ancillary.h
cp -vfR ancillary.h ../$TARGET_ARCH_ABI/include
cp *.a ../$TARGET_ARCH_ABI/lib
