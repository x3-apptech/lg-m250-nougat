#pragma once

#include "../../webviewer.h"

namespace canvas {
namespace android {

class WebViewer : public canvas::WebViewer {
public:
	WebViewer( Surface *surface );
	virtual ~WebViewer( void );

	virtual bool load( const std::string &file );
	virtual void stop();
	virtual void draw();

	virtual void dispatch(const player::event::LuaEvent &event);
};

}
}

