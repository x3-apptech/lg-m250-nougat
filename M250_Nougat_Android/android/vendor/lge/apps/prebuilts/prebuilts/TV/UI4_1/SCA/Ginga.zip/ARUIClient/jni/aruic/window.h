#include "types.h"

#include <vector>

namespace aruic {
namespace window {

void newWindow(const void *id);
void deleteWindow(const void *id);

void renderLayer(const void *id, aruic::Surface *surface, const std::vector<aruic::Rect> &dirtyRegions);
void getSize(const void *id, aruic::Size &size);

} // namespace window
} // namespace aruic
