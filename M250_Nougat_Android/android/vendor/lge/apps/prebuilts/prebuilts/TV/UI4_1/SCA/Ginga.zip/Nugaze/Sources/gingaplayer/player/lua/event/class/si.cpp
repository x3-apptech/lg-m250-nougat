/*
Technical notes:

Two noteworthy points of the Ginga standard towards SI events are:

* SI request types "services", "mosaic" and "epg" all accept an optional
  "fields" parameter. If this parameter is specified, only the listed table
  fields are to be retrieved (and all fields otherwise);
* The response event is generated either when all requested data is ready, or
  after a timeout -- in the later case, any table fields not retrieved should
  be set to nil.

As a result of these rules, each table field in an SI response can be in one
of three possible states, depending on whether the field was requested and, if
positive, whether it was successfully retrieved:

1. Field not requested: the field should not be defined in corresponding
   tables;
2. Field requested, but not retrieved: the field should be defined but assigned
   a nil value;
3. Field requested and successfully retrieved: the field should be defined and
   assigned the retrieved value.

To further complicate things, because of the asynchronous request / response
model implemented for Lua events, the field list received with the request will
not be available by the time the response arrives; it has to be returned along
with the results.

In the code below, response parsers work by first setting all fields for which
values were returnded, then setting the remaining requested fields (whose list
is received in the response) to nil, which in Nugaze is represented by the
singleton value LuaNil::NIL. As a result, any field requested but not assigned
a value in the response will be set to nil when the whole response structure is
pushed to the running Lua context.
*/

#include "si.h"

#include "../event.h"
#include "../../lua.h"

#include <canvas/system.h>
#include <util/log.h>

#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/shared_ptr.hpp>

#include <iostream>
#include <string>

#include "../cmdline.h"

namespace player {
namespace event {
namespace si {

#define Strings std::vector<std::string>

typedef boost::function
    <void (
        LuaTable&,
        const std::string&,
        Strings::const_iterator&
    )>
FieldParser;

template<typename T> static void fetch(Strings::const_iterator &i, T &value) {
    const std::string &str = *(i++);

    LDEBUG("event::si", "fetched \"%s\"", str.c_str());

    util::from_string<T>(str, value);
}

template<typename T> static T fetch(Strings::const_iterator &i) {
    T value;
    fetch<T>(i, value);
    return value;
}

template<typename T> static void fetch(Strings::const_iterator &i, std::vector<T> &values) {
    for (int j = 0, n = fetch<int>(i); j < n; j++) {
        T value;
        fetch<T>(i, value);
        values.push_back(value);
    }
}

static void parseBool(
    LuaTable &table,
    const std::string &name,
    Strings::const_iterator &i
) {
    table.set<bool>(name, fetch<bool>(i));
}

static void parseInt(
    LuaTable &table,
    const std::string &name,
    Strings::const_iterator &i
) {
    int value = fetch<int>(i);
    table.set<int>(name, value);
}

static void parseString(
    LuaTable &table,
    const std::string &name,
    Strings::const_iterator &i
) {
    fetch<std::string>(i, table.ref<std::string>(name));
}

static void parseLuaDateTime(
    LuaTable &table,
    const std::string &name,
    Strings::const_iterator &i
) {
    LuaDateTime &date = table.ref<LuaDateTime>(name);
    date.set<int>("year", fetch<int>(i));
    date.set<int>("month", fetch<int>(i));
    date.set<int>("day", fetch<int>(i));
    date.set<int>("hour", fetch<int>(i));
    date.set<int>("min", fetch<int>(i));
    date.set<int>("sec", fetch<int>(i));
    date.set<bool>("isdst", fetch<bool>(i));
}

class EventParser {
public:
    typedef boost::function
        <void (
            EventParser*,
            LuaTable&,
            const std::string&,
            Strings::const_iterator&
        )>
    DefaultParser;

    EventParser();

    EventParser(const DefaultParser &_parse):
        parse(_parse)
    {
        // Nothing to do.
    };

    void operator () (
        LuaTable &table,
        const std::string &name,
        Strings::const_iterator &i
    ) {
        parse(this, table, name, i);
    };

    void addParser(const std::string &name, const FieldParser &parser) {
        parsers[name] = parser;
        fields.push_back(name);
    };

    void addCellParser(const std::string &name, const FieldParser &parser) {
        if (cellParser.get() == NULL) {
            cellParser.reset(new EventParser());
        }

        cellParser->addParser(name, parser);
    };

    void parseEvent(
       LuaEvent &table,
       const std::string &typeName,
       const Strings &event
    ) {
        table.set<std::string>("class", "si");
        table.set<std::string>("type", typeName);

        // Creates an iterator from the second cell onwards, discarding the input
        // event name (e.g. "si.mosaic") at the beginning.
        Strings::const_iterator i = ++(event.begin());

        // Gets the list of requested fields.
        Strings fields;
        parseRequestedFields(fields, i);

        // Parse the event's contents.
        parseData(table, fields, i);
    };

    virtual void parseRequestedFields(Strings &fields, Strings::const_iterator &i) {
        fetch<std::string>(i, fields);
    };

    virtual void parseData(LuaTable &table, const Strings &fields, Strings::const_iterator &i) {
        LuaTable &array = table.ref<LuaTable>("data");
        parseArray<LuaTable>(array, fields, i);
    };

    template<typename T> void parseArrayItem(
        T &item,
        const Strings &fields,
        Strings::const_iterator &i
    ) {
        fetch<T>(i, item);
    };

    template<typename T> void parseArray(
        LuaTable &array,
        const Strings &fields,
        Strings::const_iterator &i
    ) {
        for (int j = 0, n = fetch<int>(i); j < n; j++) {
            T &item = array.add<T>();
            parseArrayItem(item, fields, i);
        }
    };

    template<typename T> void parseArray(LuaTable &array, Strings::const_iterator &i) {
        parseArray<T>(array, fields, i);
    };

    void parseField(LuaTable &record, const std::string &name, Strings::const_iterator &i) {
        LDEBUG("event::si", "fetched \"%s\"", name.c_str());

        std::map<std::string, FieldParser>::iterator j = parsers.find(name);
        if (j == parsers.end()) {
            LERROR("event::si", "Parser for field \"%s\" not found", name.c_str());
            return;
        }

        FieldParser &parse = j->second;
        parse(record, name, i);
    };

    void parseRecord(LuaTable &record, const Strings &fields, Strings::const_iterator &i) {
        for (int k = 0, n = fetch<int>(i); k < n; k++) {
            const std::string &name = *(i++);
            parseField(record, name, i);
        }

        for (Strings::const_iterator j = fields.begin(), m = fields.end(); j != m; ++j) {
            const std::string &name = *j;
            if (!record.contains(name)) {
                LDEBUG("event::si", "set \"%s\" to nil", name.c_str());
                record.set<LuaNil>(name, LuaNil::NIL);
            }
        }
    };

    void parseRecord(LuaTable &record, Strings::const_iterator &i) {
        parseRecord(record, fields, i);
    };

    void parseRecordCells(LuaTable &record, Strings::const_iterator &i) {
        if (cellParser.get() != NULL) {
            cellParser->parseArray<LuaTable>(record, i);
        }
    };

private:
    std::map<std::string, FieldParser> parsers;

    DefaultParser parse;

    boost::shared_ptr<EventParser> cellParser;

    Strings fields;
};

template<typename T> static void parseArrayField(
    EventParser *parser,
    LuaTable &table,
    const std::string &name,
    Strings::const_iterator &i
) {
    LuaTable &array = table.ref<LuaTable>(name);
    parser->parseArray<T>(array, i);
}

static void parseIntArrayField(
    EventParser *parser,
    LuaTable &table,
    const std::string &name,
    Strings::const_iterator &i
) {
    LDEBUG("event::si", "parseIntArrayField(\"%s\")", name.c_str());
    parseArrayField<int>(parser, table, name, i);
}

static void parseRecordField(
    EventParser *parser,
    LuaTable &table,
    const std::string &name,
    Strings::const_iterator &i
) {
    LDEBUG("event::si", "parseRecordField(\"%s\")", name.c_str());
    LuaTable &record = table.ref<LuaTable>(name);
    parser->parseRecord(record, i);
}

static void parseRecordArrayField(
    EventParser *parser,
    LuaTable &table,
    const std::string &name,
    Strings::const_iterator &i
) {
    LDEBUG("event::si", "parseRecordArrayField(\"%s\")", name.c_str());
    parseArrayField<LuaTable>(parser, table, name, i);
}

static void parseTableField(
    EventParser *parser,
    LuaTable &table,
    const std::string &name,
    Strings::const_iterator &i
) {
    LDEBUG("event::si", "parseTableField(\"%s\")", name.c_str());
    LuaTable &record = table.ref<LuaTable>(name);
    parser->parseRecord(record, i);
    parser->parseRecordCells(record, i);
};

EventParser::EventParser():
    parse(boost::bind(parseRecordField, _1, _2, _3, _4))
{
    // Nothing to do.
}

template<> void EventParser::parseArrayItem(
    LuaTable &item,
    const Strings &fields,
    Strings::const_iterator &i
) {
    parseRecord(item, fields, i);
};

class EPGParser: public EventParser {
public:
    EPGParser() {

        EventParser parseContentDescription(
            boost::bind(parseIntArrayField, _1, _2, _3, _4)
        );

        EventParser parseLinkage;
        parseLinkage.addParser("tsId", parseInt);
        parseLinkage.addParser("networkId", parseInt);
        parseLinkage.addParser("serviceId", parseInt);
        parseLinkage.addParser("type", parseInt);
        parseLinkage.addParser("data", parseString);

        EventParser parseHyperlink;
        parseHyperlink.addParser("type", parseInt);
        parseHyperlink.addParser("destinationType", parseInt);
        parseHyperlink.addParser("tsId", parseInt);
        parseHyperlink.addParser("networkId", parseInt);
        parseHyperlink.addParser("eventId", parseInt);
        parseHyperlink.addParser("componentTag", parseInt);
        parseHyperlink.addParser("moduleId", parseInt);
        parseHyperlink.addParser("serviceId", parseInt);
        parseHyperlink.addParser("contentId", parseInt);
        parseHyperlink.addParser("url", parseString);

        EventParser parseSeries;
        parseSeries.addParser("id", parseInt);
        parseSeries.addParser("repeatLabel", parseInt);
        parseSeries.addParser("programPattern", parseInt);
        parseSeries.addParser("episodeNumber", parseInt);
        parseSeries.addParser("lastEpisodeNumber", parseInt);
        parseSeries.addParser("name", parseString);

        EventParser parseEventGroup(
            boost::bind(parseTableField, _1, _2, _3, _4)
        );
        parseEventGroup.addParser("type", parseInt);
        parseEventGroup.addCellParser("id", parseInt);
        parseEventGroup.addCellParser("tsId", parseInt);
        parseEventGroup.addCellParser("networkId", parseInt);
        parseEventGroup.addCellParser("serviceId", parseInt);

        EventParser parseCaUnitComponent(
            boost::bind(parseRecordArrayField, _1, _2, _3, _4)
        );
        parseCaUnitComponent.addParser("tag", parseInt);

        EventParser parseCaUnit;
        parseCaUnit.addParser("id", parseInt);
        parseCaUnit.addParser("component", parseCaUnitComponent);

        EventParser parseComponentGroup(
            boost::bind(parseTableField, _1, _2, _3, _4)
        );
        parseComponentGroup.addParser("type", parseInt);
        parseComponentGroup.addCellParser("id", parseInt);
        parseComponentGroup.addCellParser("totalBitRate", parseInt);
        parseComponentGroup.addCellParser("description", parseString);
        parseComponentGroup.addCellParser("caUnit", parseCaUnit);

        addParser("startTime", parseLuaDateTime);
        addParser("endTime", parseLuaDateTime);
        addParser("runningStatus", parseInt);
        addParser("name", parseString);
        addParser("originalNetworkId", parseInt);
        addParser("shortDescription", parseString);
        addParser("extendedDescription", parseString);
        addParser("copyrightId", parseInt);
        addParser("copyrightInfo", parseString);
        addParser("parentalRating", parseInt);
        addParser("parentalRatingDescription", parseString);
        addParser("audioLanguageCode", parseString);
        addParser("audioLanguageCode2", parseString);
        addParser("dataContentLanguageCode", parseString);
        addParser("dataContentText", parseString);
        addParser("hasInteractivity", parseBool);
        addParser("logoURI", parseString);
        addParser("contentDescription", parseContentDescription);
        addParser("linkage", parseLinkage);
        addParser("hyperlink", parseHyperlink);
        addParser("series", parseSeries);
        addParser("eventGroup", parseEventGroup);
        addParser("componentGroup", parseComponentGroup);
    };
};

class MosaicParser: public EventParser {
public:
    MosaicParser() {
        addParser("logicalId", parseInt);
        addParser("presentationInfo", parseInt);
        addParser("id", parseInt);
        addParser("linkageInfo", parseInt);
        addParser("bouquetId", parseInt);
        addParser("networkId", parseInt);
        addParser("tsId", parseInt);
        addParser("serviceId", parseInt);
        addParser("eventId", parseInt);
    };

    virtual void parseData(LuaTable &mosaic, const Strings &fields, Strings::const_iterator &i) {
        LuaTable &data = mosaic.ref<LuaTable>("data");
        for (int j = 0, m = fetch<int>(i); j < m; j++) {
            LuaTable &row = data.add<LuaTable>();
            for (int k = 0, n = fetch<int>(i); k < n; k++) {
                LuaTable &cell = row.add<LuaTable>();
                parseRecord(cell, fields, i);
            }
        }
    };
};

class ServiceParser: public EventParser {
public:
    ServiceParser() {
        EventParser parseStreams(boost::bind(parseRecordArrayField, _1, _2, _3, _4));
        parseStreams.addParser("pid", parseInt);
        parseStreams.addParser("componentTag", parseInt);
        parseStreams.addParser("type", parseInt);
        parseStreams.addParser("regionSpecType", parseInt);
        parseStreams.addParser("regionSpec", parseString);

        addParser("id", parseInt);
        addParser("isAvailable", parseBool);
        addParser("isPartialReception", parseBool);
        addParser("parentalControlRating", parseInt);
        addParser("runningStatus", parseInt);
        addParser("serviceType", parseInt);
        addParser("providerName", parseString);
        addParser("serviceName", parseString);
        addParser("stream", parseStreams);
    };
};

class TimeParser: public EventParser {
public:
    TimeParser() {
        addParser("year", parseInt);
        addParser("month", parseInt);
        addParser("day", parseInt);
        addParser("hours", parseInt);
        addParser("minutes", parseInt);
        addParser("seconds", parseInt);
    };

    virtual void parseRequestedFields(Strings &fields, Strings::const_iterator &i) {
        // Nothing to do.
    };

    virtual void parseData(LuaTable &table, const Strings &fields, Strings::const_iterator &i) {
        LuaTable &record = table.ref<LuaTable>("data");
        parseRecord(record, i);
    };
};

void parseEPG(LuaEvent &response, const std::vector<std::string> &event) {
    LDEBUG("event::si", "parseEPG(response, {\"%s\", ...})", event[0].c_str());

    EPGParser parser;

    LDEBUG("event::si", "parseEvent(response, \"epg\", event)");
    parser.parseEvent(response, "epg", event);

    LDEBUG("event::si", "Parsed EPG event: %s", ((std::string) response).c_str());
}

void parseMosaic(LuaEvent &response, const std::vector<std::string> &event) {
    MosaicParser parser;
    parser.parseEvent(response, "mosaic", event);
}

void parseServices(LuaEvent &response, const std::vector<std::string> &event) {
    ServiceParser parser;
    parser.parseEvent(response, "services", event);
}

void parseTime(LuaEvent &response, const std::vector<std::string> &event) {
    TimeParser parser;
    parser.parseEvent(response, "time", event);
}

static std::string postEPG(System *sys, LuaEvent &request, lua_State *lua, int index) {
	pullRequired(request, std::string, "stage", lua, index);
	const std::string &stage = request.get<std::string>("stage");

	if (stage == "current") {
        request.pullArray<std::string>("fields", lua, index, false);

        // FIXME: send data to pipe
        std::string event;
        request.toString(event);
        sys->cmdout << "LUA_EVENT" << " " << event << std::endl;

        return "";
	}

	if (stage == "next") {
	    request.pull<int>("eventId", lua, index, -1);
        request.pullArray<std::string>("fields", lua, index, false);

        // FIXME: send data to pipe
        std::string event;
        request.toString(event);
        sys->cmdout << "LUA_EVENT" << " " << event << std::endl;

        return "";
	}

	if (stage == "schedule") {
	    pullRequired(request, LuaDateTime, "startTime", lua, index);
	    pullRequired(request, LuaDateTime, "endTime", lua, index);
        request.pullArray<std::string>("fields", lua, index, false);

        // FIXME: send data to pipe
        std::string event;
        request.toString(event);
        sys->cmdout << "LUA_EVENT" << " " << event << std::endl;

        return "";
	}

	const char* format = "si epg stage \"%s\" not supported";
	std::string err = util::format(format, stage.c_str());
    LWARN("event::si", err.c_str());
	return err;
}

static std::string postMosaic(System *sys, LuaEvent &request, lua_State *lua, int index) {
    // Pull the remaining request fields, if given.
    request.pullArray<std::string>("fields", lua, index, false);

    LDEBUG("event::si", "si request: %s", ((std::string) request).c_str());

    // FIXME: send data to pipe
    std::string event;
    request.toString(event);
    sys->cmdout << "LUA_EVENT" << " " << event << std::endl;

    return "";
}

static std::string postServices(System *sys, LuaEvent &request, lua_State *lua, int index) {
    // Pull the remaining request fields, if given.
    request.pull<int>("index", lua, index, -1);
    request.pullArray<std::string>("fields", lua, index, false);

    LDEBUG("event::si", "si request: %s", ((std::string) request).c_str());

    // FIXME: send data to pipe
    std::string event;
    request.toString(event);
    sys->cmdout << "LUA_EVENT" << " " << event << std::endl;

    return "";
}

static std::string postTime(System *sys, LuaEvent &request, lua_State *lua, int index) {
    // FIXME: send data to pipe
    std::string event;
    request.toString(event);
    sys->cmdout << "LUA_EVENT" << " " << event << std::endl;

    return "";
}

std::string postEvent(System *sys, lua_State *lua, bool /*isOut*/, int eventPos) {
	LuaEvent request("si");
	pullRequired(request, std::string, "type", lua, eventPos);
	const std::string &eventType = request.ref<std::string>("type");

    LDEBUG("event::si", "si type \"%s\" requested", eventType.c_str());

	if (eventType == "services") {
	    return postServices(sys, request, lua, eventPos);
	}

	if (eventType == "mosaic") {
		return postMosaic(sys, request, lua, eventPos);
	}

	if (eventType == "epg") {
	    return postEPG(sys, request, lua, eventPos);
	}

	if (eventType == "time") {
		return postTime(sys, request, lua, eventPos);
	}

	const char* format = "si type \"%s\" not supported";
	std::string err = util::format(format, eventType.c_str());
	LWARN("event::si", err.c_str());
	return err;
}

}
}
}
