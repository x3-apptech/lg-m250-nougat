#pragma once

#include "../event.h"

namespace player {
namespace event {
namespace pointer {

std::string postEvent(System *sys, lua_State *st, bool isOut, int eventPos);

void dispatchPointer(Module *module, util::touch::type touch, int x, int y, bool isInternal = false);

}
}
}

