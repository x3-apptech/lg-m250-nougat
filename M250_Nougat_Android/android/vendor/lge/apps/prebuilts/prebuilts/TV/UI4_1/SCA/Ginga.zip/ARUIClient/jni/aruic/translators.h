#pragma once

#include "ipc.h"
#include "types.h"

namespace aruic {

template<> ipc& ipc::get(aruic::Color& value);

template<> ipc& ipc::get(aruic::Rect& value);

template<> ipc& ipc::get(aruic::Size& value);

template<> ipc& ipc::set(const aruic::Color& value);

//template<> ipc& ipc::set(const aruic::ImageData* value);

template<> ipc& ipc::set(const aruic::Point& value);

template<> ipc& ipc::set(const aruic::Rect& value);

template<> ipc& ipc::set(const aruic::Size& value);

template<> ipc& ipc::set(const aruic::Font& value);

template<> ipc &ipc::set(const aruic::BYTE &value);

}
