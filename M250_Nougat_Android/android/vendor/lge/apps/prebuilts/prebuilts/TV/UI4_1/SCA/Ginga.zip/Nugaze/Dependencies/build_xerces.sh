#!/bin/bash

. build_setup.sh
CPPFLAGS="${CPPFLAGS} -I${CWD}/$TARGET_ARCH_ABI/include"
LDFLAGS="-L${CWD}/$TARGET_ARCH_ABI/lib"
LIBS="-liconv"

XERCES="xerces-c-3.1.1"
extract_sources $XERCES
STAGE=$(make_stagedir)

./configure CC="$CC" CFLAGS="$CFLAGS" CXX="$CXX" CPPFLAGS="$CPPFLAGS" LDFLAGS="$LDFLAGS" LIBS="$LIBS" \
    --host arm-linux --prefix=$STAGE --exec-prefix=$STAGE \
    --enable-transcoder-iconv

(cd "src/xercesc/util"; patch < "${CWD}/libxerces_src_xercesc_util_XMLAbstractDoubleFloat.cpp.patch")

make $MAKE_JOBS $MAKE_LOAD
make install
copy_binaries $STAGE
