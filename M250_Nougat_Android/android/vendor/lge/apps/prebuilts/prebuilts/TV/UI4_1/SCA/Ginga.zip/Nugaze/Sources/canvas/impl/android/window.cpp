#include "window.h"

#include "surface.h"
#include "canvas.h"
#include "converter.h"

#include "util/log.h"

#include <aruic/window.h>
#include "../../system.h"

namespace canvas {
namespace android {

Window::Window() {
	LDEBUG("android::Window", "Window()");
	aruic::window::newWindow(this);
	LDEBUG("android::Window", "new Window done");
	_surface = NULL;
	_parent = NULL;
}

Window::~Window() {
	LDEBUG("android::Window", "~Window()");
	aruic::window::deleteWindow(this);
	delete _surface;
}

bool Window::getSizeImpl(Size &size) {
	LDEBUG("android::Window", "getSizeImpl(Size &size)");
	aruic::Size asize;
	aruic::window::getSize(this, asize);
	size.w = asize.w;
	size.h = asize.h;
	return true;
}

//	Layer methods
canvas::Surface *Window::lockLayer(canvas::Canvas *canvas) {
	LDEBUG("android::Window", "lockLayer(canvas::Canvas *canvas)");
	if (!_surface) {
		const Size &s = canvas->size();
		_surface = new Surface((Canvas*) canvas, Rect(0,0,s.w,s.h) );
	}
	return _surface;
}

void Window::renderLayer(canvas::Surface* surface, const std::vector<Rect>& dirtyRegions) {
	LDEBUG("android::Window", "renderLayer(canvas::Surface* surface, const std::vector<Rect>& dirtyRegions)");

	// TODO
	std::vector<aruic::Rect> aDirtyRegions;
	for (std::vector<Rect>::const_iterator i = dirtyRegions.begin(), n = dirtyRegions.end(); i != n; ++i) {
		aDirtyRegions.push_back((aruicRect(*i).convert()));
	}

	aruic::window::renderLayer(this, surface, aDirtyRegions);
	if (_parent != NULL) {
		LINFO("android::Window", "OnRender: a children window has been rendered");
		_parent->runCallbackNeedRefresh();
	}
}

void Window::unlockLayer(Surface* surface) {
	LDEBUG("android::Window", "unlockLayer(Surface* surface)");
}

}
}
