#include "../lua.h"
#include "../../luaplayer.h"
#include "../../../system.h"
#include "class/key.h"
#include "class/ncl.h"
#include "class/pointer.h"
#include "class/si.h"
#include "class/sms.h"
#include "class/tcp.h"
#include "class/user.h"
#include <canvas/system.h>
#include <util/net/resolver.h>
#include <util/net/socket.h>
#include <util/net/ipv4/sockaddr.h>
#include <util/buffer.h>
#include <util/log.h>
#include <util/mcr.h>
#include <boost/bind.hpp>
#include <boost/foreach.hpp>

#define LUA_EVENT "lua_module_event"

namespace player {
namespace event {

struct FindTimerByID {
	FindTimerByID( util::id::Ident &timerID ) : _timerID(timerID) {}

	bool operator()( const Module::TimerRef &timer ) const {
		return timer.first == _timerID;
	}

	util::id::Ident &_timerID;

private:
	// Avoid VisualStudio warning C4512
	FindTimerByID &operator=( FindTimerByID & /*ft*/ ) { return *this; }
};

struct FindTimerByRef {
	FindTimerByRef( int id ) : _id(id) {}

	bool operator()( const Module::TimerRef &timer ) const {
		return timer.second == _id;
	}

	int _id;
};

struct FindSocketByID {
	FindSocketByID( util::id::ID_TYPE id ) : _id(id) {}

	bool operator()( const Module::SocketList::value_type &pair ) const {
		util::id::Ident id = pair.first;
		return util::id::isValid(id) ? (id->getID() == _id) : false;
	}

	util::id::ID_TYPE _id;

private:
	// Avoid VisualStudio warning C4512
	FindSocketByID &operator=( FindSocketByID & /*ft*/ ) { return *this; }
};

/*******************************************************************************
*	Event module
*******************************************************************************/
static int l_post( lua_State *L ) {
	//	(a) evt: event -> sent: boolean; err_msg: string
	//	(b) dst:string, evt: event -> sent: boolean; err_msg: string
	//	dst = [in | out]; default=out

	//	Get event module from stack
	Module *module = Module::get( L );
	if (!module) {
		return luaL_error( L, "[player::event] Invalid event module" );
	}

	//	Check dst
	bool dstIsOut=true;
	int eventPos=1;
	if (lua_gettop(L) == 2) {
		const char *dst = luaL_checkstring(L, 1);
		if (!dst) {
			return luaL_error(L, "[player::event] Invalid dst");
		}

		if (!strcmp("out",dst)) {
			dstIsOut=true;
		}
		else if (!strcmp( "in", dst )) {
			dstIsOut=false;
		}
		else {
			return luaL_error(L, "[player::event] Invalid dst");
		}

		eventPos=2;
	}

	//	Get class event
	luaL_checktype(L, eventPos, LUA_TTABLE);
	std::string value = lua::getField( L, eventPos, "class" );
	if (value.empty()) {
		return luaL_error(L, "[player::event] Event class nil" );
	}

	std::string err = module->postEvent( L, value, dstIsOut, eventPos );
	if(err.empty()) {
		lua_pushboolean(L, true);
		lua_pushnil(L);
	}
	else {
		lua_pushboolean(L, false);
		lua_pushstring(L, err.c_str());
	}
	return 2;
}

static int l_cancel( lua_State *L ) {
	//	Get event module from stack
	Module *module = Module::get( L );
	if (!module) {
		return (int) luaL_error( L, "[player::event] Invalid event module" );
	}

	//	Get timerID
	int timerRef = (int) lua_tonumber(L,lua_upvalueindex(1));

	module->cancelTimer( timerRef );
	return 0;
}

static int l_timer( lua_State *L ) {
	// event.timer( time: number, f: function ) -> cancel: function

	//	Get event module from stack
	Module *module = Module::get( L );
	if (!module) {
		return luaL_error( L, "[player::event] Invalid event module" );
	}

	//	Check ms value
	util::DWORD ms = (util::DWORD) luaL_checknumber( L, 1 );

	//	Check function and save in the registry
	luaL_checktype( L, 2, LUA_TFUNCTION );	//	(f)

	//	Register system timer
	module->registerTimer( L, ms );
	return 1;
}

static int l_uptime( lua_State *L ) {	//	TODO: Get uptime from player
	//	Get event module from stack
	Module *module = Module::get( L );
	if (!module) {
		return luaL_error( L, "[player::event] Invalid event module" );
	}

	util::DWORD ms = module->uptime();
	lua_pushnumber(L, ms);
	return 1;
}

static int isValidClass( const std::string class_name ) {
	return class_name == "key" ||
		class_name == "ncl" ||
		class_name == "edit" ||
		class_name == "tcp" ||
		class_name == "sms" ||
		class_name == "si" ||
		class_name == "user";
}

static int l_register( lua_State *L ) {
	//	event.register( [pos:number]; f:function; [class:string; [...:any]] )

	std::string classFilter="";
	std::list<std::string> classDependent;
	int index=1;

	//	Get event module from stack
	Module *module = Module::get( L );
	if (!module) {
		return luaL_error( L, "[player::event] Invalid event module" );
	}

	//	Get pos
	int pos=-1;
	if (lua_type(L, index) == LUA_TNUMBER) {
		pos = (int) luaL_checknumber( L, index );
		if (pos <= 0) {
			return luaL_argerror(L, 1, NULL);
		}
		index++;
	}

	//	Get function
	luaL_checktype(L, index, LUA_TFUNCTION);
	int fncIndex=index;
	index++;

	//	Have class filter?
	if (lua_gettop(L) >= index)	{
		//	Get class filter
		classFilter=luaL_checkstring( L, index );
		if (!isValidClass(classFilter))
			return luaL_error( L, "[player::event] Invalid class \"%s\"", classFilter.c_str() );
		index++;
		//	Have class dependent filters?
		while (lua_gettop(L) >= index) {
			classDependent.push_back(luaL_checkstring( L, index++ ));
		}
	}

	//	Add event handler
	return module->addHandler( L, pos, fncIndex, classFilter, classDependent );
}

static int l_unregister( lua_State *L ) {
	//	event.unregister( f:function )

	//	Get event module from stack
	Module *module = Module::get( L );
	if (!module) {
		return luaL_error( L, "[player::event] Invalid event module" );
	}

	//	Check function
	luaL_checktype( L, 1, LUA_TFUNCTION );	//	(f)

	//	Remove event handler
	module->removeHandler( L, 1 );
	return 0;
}

static const struct luaL_Reg event_methods[] = {
	{ "post",       l_post       },
	{ "timer",      l_timer      },
	{ "uptime",     l_uptime     },
	{ "register",   l_register   },
	{ "unregister", l_unregister },
	{ NULL,         NULL         }
};


/*******************************************************************************
*	Class Module
*******************************************************************************/
Module::Module( System *sys, LuaPlayer *player, lua_State *lua )
	: _sys(sys), _player(player), _lua( lua )
{
	//	Store module into stack
	lua::storeObject( lua, this, LUA_EVENT );

	//	Register classes
	_classes["ncl"]  = &ncl::postEvent;
	_classes["key"]  = &key::postEvent;
	_classes["pointer"]  = &pointer::postEvent;
	_classes["si"] = &si::postEvent;
	_classes["sms"] = &sms::postEvent;
	_classes["user"] = &user::postEvent;
	_classes["tcp"] = &tcp::postEvent;

	//	Register event methods
	luaL_register( _lua, "event", event_methods );
}

Module::~Module()
{
	{	//	Cleanup timers
		TimerList::iterator it=_timers.begin();
		while (it != _timers.end()) {
			cancelTimer( (*it).first, true );
			it = _timers.begin();
		}
	}

	{	//	Cleanup sockets
		SocketList::iterator it=_sockets.begin();
		while (it != _sockets.end()) {
			disconnect( it );
			it=_sockets.begin();
		}
	}
}

//	Initialization
void Module::setCallback( const Callback &callback ) {
	_callback = callback;
}

void Module::setInputEventCallback( const InputCallback &callback ) {
	_inCallback = callback;
}

//	LuaPlayer methods
void Module::dispatchKey( util::key::type key, bool isUp ) {
	key::dispatchKey( this, key, isUp );
}

void Module::dispatchPointer(util::touch::type touch, int x, int y) {
	pointer::dispatchPointer(this, touch, x, y);
}

void Module::dispatchPresentation( evtAction::type action, const std::string &label ) {
	ncl::dispatchPresentation( this, action, label );
}

void Module::dispatchAttribution( const std::string &name, evtAction::type action, const std::string &value ) {
	ncl::dispatchAttribution( this, name, action, value );
}

//	Dispatch methods
void Module::dispatchInCallback( int ref, util::id::Ident &timerID )
{
	BOOST_FOREACH( LuaHandlerPtr handler, _handlers ) {
		if (handler.get() && handler->dispatchEvent( ref )) {
			break;
		}
	}

    // delete event
    luaL_unref(_lua, LUA_REGISTRYINDEX, ref);
}

void Module::dispatchIn(const LuaEvent &event, bool isInternal) {
	 if (isInternal) {
		event.push(_lua);

		// save event into registry
		int ref = luaL_ref( _lua, LUA_REGISTRYINDEX );

		_sys->registerTimer( 1, boost::bind( &Module::dispatchInCallback, this, ref, _1 ) );
	} else {
		event.dispatch(_lua, _handlers);
	}
	if (!_inCallback.empty()) {
		_inCallback(event);
	}
	_handlersToRemove.clear();
}

class DispatchOutInfo {
public:
	DispatchOutInfo(evtType::type type, evtAction::type action, const std::string &parameter, const std::string &value)
		: type(type), action(action), parameter(parameter), value(value) {}

	evtType::type type;
	evtAction::type action;
	const std::string parameter;
	const std::string value;
};

void Module::dispatchOutCallback(DispatchOutInfoPtr dispatchInfo, util::id::Ident &timerID)
{
	if (!_callback.empty())
		_callback(dispatchInfo->type, dispatchInfo->action, dispatchInfo->parameter, dispatchInfo->value);
}


void Module::dispatchOut(
	evtType::type type,
	evtAction::type action,
	const std::string &parameter,
	const std::string &value )
{
	if (!_callback.empty()) {
		DispatchOutInfoPtr dispatchInfo( new DispatchOutInfo( type, action, parameter, value ) );
		_sys->registerTimer( 1, boost::bind( &Module::dispatchOutCallback, this, dispatchInfo, _1 ) );
	}
}

//	Lua event methods
std::string Module::postEvent( lua_State *L, const std::string &evtClass, bool isOut, int eventPos ) {
	Classes::const_iterator it=_classes.find( evtClass );
	if (it != _classes.end()) {
		return ((*it).second)( _sys, L, isOut, eventPos );
	}

	const char* format = "Class '%s' not found";
	std::string err = util::format(format, evtClass.c_str());
	LWARN("player::event", err.c_str());
	return err;
}

int Module::addHandler( lua_State *L, int pos, int fncIndex, const std::string &classFilter,
		const std::list<std::string> &depFilters ) {

	//  Check number of class dependent filters
	if (classFilter != "" && depFilters.size() > LuaHandler::depFilter(classFilter).size())
		return luaL_error( L, "[player::event] Invalid number of class-dependent filters for class %s", classFilter.c_str());

	//	Find handler
	LuaHandlers::const_iterator it=_handlers.begin();
	while (it != _handlers.end()) {
		LuaHandlerPtr handler = (*it);
		if (handler.get() && handler->isEqual( L, fncIndex )) {
			return luaL_error( L, "[player::event] Handler already registered" );
		}
		it++;
	}

	//	Push function into registry
	lua_pushvalue( L, fncIndex );
	int ref = luaL_ref(L, LUA_REGISTRYINDEX);

	LuaHandlerPtr handler( new LuaHandler( _lua, ref, classFilter, depFilters ) );
	if (pos < 0) {
		_handlers.push_back( handler );
	}
	else {
		if(_handlers.size() < static_cast<size_t>( pos )){
			_handlers.resize( pos, LuaHandlerPtr() );
		}
		LuaHandlerPtr removeHandler = _handlers[pos-1];
		if (removeHandler.get()) {
			_handlersToRemove.push_back(removeHandler);
		}

		_handlers[pos-1] = handler;
	}
	return 0;
}

void Module::removeHandler( lua_State *L, int index ) {
	LuaHandlers::iterator it=_handlers.begin();
	while (it != _handlers.end()) {
		LuaHandlerPtr handler = (*it);
		if (handler.get() &&handler->isEqual( L, index )) {
			_handlersToRemove.push_back(handler);
			_handlers.erase(it);
			break;
		}
		it++;
	}
}

util::DWORD Module::uptime() const {
	return _player->uptime();
}

void Module::registerTimer( lua_State *L, util::DWORD ms) {
	//	Register timer
	util::id::Ident timerID=_sys->registerTimer( ms, boost::bind( &Module::onTimerExpired, this, _1 ) );

	//	Push function into registry
	lua_pushvalue( L, 2 );
	int key = luaL_ref( L, LUA_REGISTRYINDEX );

	//	Push cancel function with timerID as upvalue(1)
	lua_pushnumber( L, key );
	lua_pushcclosure( L, l_cancel, 1 );

	_timers.push_back( std::make_pair(timerID,key) );

	LDEBUG("lua::Event::Module", "Timer registered: timerID=%p", timerID->getID() );
}

void Module::cancelTimer( int timerRef ) {
	//	Find timer in list
	TimerList::iterator it=std::find_if(
		_timers.begin(),
		_timers.end(),
		FindTimerByRef(timerRef)
	);
	if (it != _timers.end()) {
		cancelTimerAux( it, true );
	}
}

void Module::cancelTimer( util::id::Ident &timerID, bool needUnregister ) {
	//	Find timer in list
	TimerList::iterator it=std::find_if(
		_timers.begin(),
		_timers.end(),
		FindTimerByID(timerID)
	);
	if (it != _timers.end()) {
		cancelTimerAux( it, needUnregister );
	}
}

void Module::cancelTimerAux( TimerList::iterator &it, bool needUnregister ) {
	//	Cancel function callback
	luaL_unref(_lua, LUA_REGISTRYINDEX, it->second );

	//	Cancel timer
	if (needUnregister) {
		_sys->unregisterTimer( it->first );
	}

	//	Remove from list
	_timers.erase( it );
}

void Module::onTimerExpired( util::id::Ident &timerID ) {
	LDEBUG("lua::Event::Module", "On Timer expired: timerID=%p", timerID->getID() );
	bool result=false;
	TimerList::const_iterator it=std::find_if(
		_timers.begin(),
		_timers.end(),
		FindTimerByID(timerID)
	);
	if  (it != _timers.end()) {
		//	Get function from registry into stack
		lua_rawgeti(_lua, LUA_REGISTRYINDEX, it->second);
		if (!lua_isnil( _lua, -1 )) {
			lua_call( _lua, 0, 0 );
			cancelTimer( timerID, false );
			result=true;
		}
		else {
			lua_pop( _lua, 1 );
		}
	}

	if (!result) {
		LWARN( "lua::Event::Module", "Timer not found" );
	}
}

util::id::Ident Module::connect(const std::string &host, const std::string &port, util::DWORD /*timeOut*/) {
	util::id::Ident socketID;

	std::vector<util::net::SockAddr> addresses;
	if ( !util::net::resolve( host, port, addresses )) {
		LERROR("lua::Event::Module", "Cannot resolve socket address: host=%s, port=%d", host.c_str(), port.c_str());
		return socketID;
	}

	//	Create socket
	util::net::Socket *sock = new util::net::Socket();
	if (!sock->create( util::net::type::stream )) {
		LERROR("lua::Event::Module", "Cannot create socket: host=%s, port=%d", host.c_str(), port.c_str());
		return socketID;
	}

	BOOST_FOREACH( util::net::SockAddr sockAddr, addresses ) {
		LDEBUG("lua::Event::Module", "Trying connect: host=%s, sockAddr=%s", host.c_str(), sockAddr.asString().c_str() );

		//	Try connect to remote host
		if (!sock->connect( sockAddr )) {
			LERROR("lua::Event::Module", "Cannot connect: host=%s, sockAddr=%s", host.c_str(), sockAddr.asString().c_str() );
			continue;
		}

		//	Set socket non blocking
		if (!sock->setNonBlocking( true )) {
			LERROR("lua::Event::Module", "Cannot set socket non blocking: host=%s, sockAddr=%s", host.c_str(), sockAddr.asString().c_str() );
			continue;
		}

		//	Add socket to dispatcher
		socketID = _sys->addSocket( sock->fd(), boost::bind(&Module::onDataReceived, this, _1));
		if (util::id::isValid(socketID)) {
			LDEBUG("lua::Event::Module", "Socket connected: socket=%d", sock->fd() );
			_sockets[socketID] = sock;
			break;
		}
	}

	return socketID;
}

bool Module::disconnect( util::id::ID_TYPE socketID ) {
	bool res = false;
	SocketList::iterator it=std::find_if(
		_sockets.begin(),
		_sockets.end(),
		FindSocketByID(socketID)
	);
	if (it != _sockets.end()) {
		disconnect( it );
		res = true;
	}
	return res;
}

void Module::disconnect( SocketList::iterator &it ) {
	LDEBUG( "lua::Event::Module", "disconnect socketID: %ld", it->first->getID() );

	//	Stop listen for data
	util::id::Ident id = it->first;
	_sys->stopSocket( id );

	//	Disconnect and cleanup
	util::net::Socket *sock = it->second;
	delete sock;

	_sockets.erase( it );
}

void Module::onDataReceived( util::id::Ident &socketID ) {
	LDEBUG("lua::Event::Module", "onDataReceived socketID: %li", socketID->getID());
	SocketList::iterator it=_sockets.find( socketID );
	if (it != _sockets.end()) {
		util::net::Socket *sock = it->second;
		util::Buffer buf( 1024 );
		util::SSIZE_T len = sock->recv( buf.buffer(), buf.capacity() );
		while (len > 0) {
			{	//	Notify data
				std::string tmp( buf.buffer(), len );
				tcp::onDataReceived( this, tmp, socketID->getID() );
			}

			len = sock->recv( buf.buffer(), buf.capacity() );
		}
		if (len == 0) {	//	No data and peer has performed an orderly shutdown ... close socket!
			LWARN("lua::Event::Module", "Connection closed, disconnect socket" );
			disconnect( it );
		}
	}
}

bool Module::send( util::id::ID_TYPE socketID, const std::string &data, util::DWORD /*timeout=0*/ ) {
	bool res = false;
	SocketList::iterator it=std::find_if(
		_sockets.begin(),
		_sockets.end(),
		FindSocketByID(socketID)
	);
	if (it != _sockets.end()) {
		LDEBUG( "lua::Event::Module", "Send data to connection: %ld", socketID );
		util::SSIZE_T bytes=it->second->send( data.c_str(), data.length() );
		res=bytes > 0 && static_cast<size_t>(bytes) == data.length();
		if (!res) {
			LWARN("lua::Event::Module", "Connection error, disconnect socket: bytes=%d", bytes );
			disconnect( it );
		}
	}
	else {
		LWARN("lua::Event::Module", "Socket not found" );
	}
	return res;
}

Module *Module::get( lua_State *st ) {
	return lua::getObject<Module>(st,LUA_EVENT);
}

}
}

