#pragma once

#include "../event.h"

namespace player {
namespace event {
namespace key {

//	Event class methods
std::string postEvent(System *sys, lua_State *st, bool isOut, int eventPos);
void dispatchKey( Module *module, util::key::type key, bool isUp, bool isInternal = false );

}
}
}

