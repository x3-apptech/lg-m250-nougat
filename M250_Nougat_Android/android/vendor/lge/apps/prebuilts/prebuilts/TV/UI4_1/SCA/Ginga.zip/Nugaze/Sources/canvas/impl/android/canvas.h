#pragma once

#include "../../canvas.h"

#include <string>

namespace canvas {
namespace android {

class Canvas : public canvas::Canvas {
public:
	Canvas();
	virtual ~Canvas();

	virtual std::string name();
protected:
	virtual canvas::Surface *createSurfaceImpl( ImageData *img );
	virtual canvas::Surface *createSurfaceImpl( const Rect &rect );
	virtual canvas::Surface *createSurfaceImpl( const std::string &file );
	virtual bool getSizeImpl( Size &size );
};

}
}

