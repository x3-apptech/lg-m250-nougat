#include "window.h"

#include "translators.h"
#include "opcodes.h"

namespace aruic {
namespace window {

void newWindow(const void *id) {
	invoke(id, IPC_WINDOW_NEW).call();
}

void deleteWindow(const void *id) {
	invoke(id, IPC_DELETE).call();
}

void renderLayer(const void *id, aruic::Surface *surface, const std::vector<aruic::Rect> &dirtyRegions) {
	invoke(id, IPC_WINDOW_RENDER_LAYER)
			.set(surface)
			.set(dirtyRegions)
		.call();
}

void getSize(const void *id, aruic::Size &size) {
	invoke(id, IPC_WINDOW_GET_SIZE).call().get(size);
}

} // namespace window
} // namespace aruic
