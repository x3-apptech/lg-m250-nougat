#include "canvas.h"

#include "translators.h"
#include "opcodes.h"

namespace aruic {
namespace canvas {

void newCanvas(const void *id) {
	invoke(id, IPC_CANVAS_NEW).call();
}

void deleteCanvas(const void *id) {
	invoke(id, IPC_DELETE).call();
}

void getSize(const void *id, Size &size) {
	invoke(id, IPC_CANVAS_GET_SIZE).call().get(size);
}

} // namespace canvas
} // namespace aruic
