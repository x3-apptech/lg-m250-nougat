#!/bin/bash

. build_setup.sh

NAME="libmicrohttpd-0.9.27"
extract_sources $NAME
STAGE=$(make_stagedir)

./configure CC="$CC" CFLAGS="$CFLAGS" --enable-static=yes --host=arm-linux --prefix=$STAGE --exec-prefix=$STAGE

make $MAKE_JOBS $MAKE_LOAD
make install
copy_binaries $STAGE
