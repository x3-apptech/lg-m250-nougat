#pragma once

#include "../../window.h"
#include "../../nclviewer.h"

namespace canvas {
namespace android {

class Surface;

class Window : public canvas::Window {
public:
	Window();
	//explicit Window( canvas::Surface * );
	virtual ~Window();

	//	Layer methods
	virtual canvas::Surface *lockLayer( canvas::Canvas *canvas );
	virtual void renderLayer( canvas::Surface *surface, const std::vector<Rect> &dirtyRegions );
	virtual void unlockLayer( Surface *surface );
	virtual bool getSizeImpl( Size &size );
	virtual void* getSurface() const { return _surface; }

private:
	canvas::Surface *_surface;
};

}
}

