#pragma once

#include <boost/thread.hpp>

#include "custom/system.h"

namespace canvas {
namespace android {

class System: public canvas::custom::System {
public:
    System();
    canvas::NclViewer *createNclViewer(canvas::Surface *surface);
    virtual canvas::GifViewer *createGifViewer( Surface * );

private:
    boost::thread poller;
};

}
}
