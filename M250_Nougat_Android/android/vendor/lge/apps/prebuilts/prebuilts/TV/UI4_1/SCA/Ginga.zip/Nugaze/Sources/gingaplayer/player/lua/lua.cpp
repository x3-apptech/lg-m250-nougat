#include "lua.h"
#include "../luaplayer.h"

namespace player {
namespace lua {

void storeObject( lua_State *st, void *obj, const char *index ) {
	lua_pushlightuserdata( st, obj );
	lua_setfield( st, LUA_REGISTRYINDEX, index );
}

std::string getField(lua_State *st, int pos, const char *szIndex) {
	lua_getfield(st, pos, szIndex);
	if (lua_isnil(st, -1) || !lua_isstring(st, -1)) {
		return "";
	}

	std::string value = luaL_checkstring(st, -1);
    lua_pop(st, 1);
	return value;
}

void pushValue( lua_State *st, const std::string &index, int value ) {
	lua_pushnumber( st, value );
	lua_setfield( st, -2, index.c_str() );
}

void pushValue( lua_State *st, const std::string &index, bool value ) {
	lua_pushboolean( st, value ? 1 : 0 );
	lua_setfield( st, -2, index.c_str() );
}

void pushValue( lua_State *st, const std::string &index, const std::string &value ) {
	lua_pushstring( st, value.c_str() );
	lua_setfield( st, -2, index.c_str() );
}

}
}
