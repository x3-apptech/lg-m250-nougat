#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/vfs.h>
#include <sys/statfs.h>


/* Please implement read_hw_key function.
   It returns hw key in keyout. The length of keyout must be 16. */

#define IMEI_LEN   15 /* 14 decimal digits plus a check digit */
#define IMEI_INDEX 8

#define KEY_LEN 16
static char frstflag[15];

int read_hw_key(char *keyout)
{
    int loop;
        for( loop=0; loop<KEY_LEN; loop++)
        keyout[loop]='0';

    FILE *fp;
    fp=fopen("/temp/br_daemon.log","a");
    fprintf(fp,"[hw_key.c] main start\n");
        fprintf(fp,"[hw_key.c] init keyout : %s\n",keyout);
        fflush(fp);

  char buffer[1024];
  int i;

  FILE* model_info = fopen("/data/data/com.lge.sync/settings.txt","r");

  if(model_info == NULL)
  {
       fprintf(fp,"[hw_key.c] settings file was not found.\n");
       fflush(fp);
       fclose(fp);
           return 0;  //jinkwon.jung@lge.com  in case of null, it should be processed.
  }

  char* google_account;
  char* model_name;
  while(fgets(buffer, sizeof(buffer)-1, model_info)) {

      for(i=0; buffer[i] && isspace(buffer[i]); ++i);

      if(buffer[i] == '\0' || buffer[i] == '#')
        continue;

      if(strncmp(buffer, "Model", strlen("Model")) == 0)
      {
            char* original = strdup(buffer);
            char* config = strtok(original, "=");
            model_name = strtok(NULL,"\n");
      }
      if(strncmp(buffer, "GoogleAccount", strlen("GoogleAccount")) == 0)
      {
        char* original = strdup(buffer);
        char* config = strtok(original, "=");
        google_account = strtok(NULL,"\n");

          if(google_account==NULL)
          {
              fclose(fp);
              fclose(model_info);
                return 0;
          }
      }
  }

  int account_len=strlen(google_account); // minus null
  int model_len=strlen(model_name)-1;
  int j;
  for( i=0; i<account_len ; i++)
    keyout[i] = google_account[i];
/* comment out fill in model name
  for( i=KEY_LEN,j=0; i>(KEY_LEN-model_len); i--,j++)
  {
    int temp;
    temp = keyout[i] + model_name[j];
    if(temp > 255)
        temp-=255;

    keyout[i] = (char)temp;
  }
*/
      fprintf(fp,"[hw_key.c] google_account : %s\n",google_account);
    fprintf(fp,"[hw_key.c] model_name : %s\n",model_name);
      fprintf(fp,"[hw_key.c] keyout : %s\n",keyout);
     fprintf(fp,"[hw_key.c] model_len : %d\n",model_len);
        fprintf(fp,"[hw_key.c] google_account_len : %d\n",account_len);
        fflush(fp);

  fclose(model_info);
  fclose(fp);

  return 0;


}
