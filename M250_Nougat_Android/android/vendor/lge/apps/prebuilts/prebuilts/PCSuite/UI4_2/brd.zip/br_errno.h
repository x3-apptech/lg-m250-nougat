#define CHOWN_FAILURE                1 // "chown failure"
#define SYSTEM_TAR_FAILURE           2 // "tar failure in system directory"
#define GZIP_FAILURE                 3 // "gzip failure"
#define ENC_FAILURE                  4 // "encryption failure"
#define RM_FAILURE                   5 // "rm failure"
#define MV_FAILURE                   6 // "mv failure"
#define DEC_FAILURE                  7 // "decryption failure"
#define UNTAR_FAILURE                8 // "untar failure"
#define UNZIP_FAILURE                9 // "unzip failure"
#define TEMP_DIR_CREATE_FAILURE     10 // "/temp" creation failure
#define TAR_FAILURE                 11 // "tar failure"
#define TAR_ADD_FAILURE             12 // "tar addition failure"
#define LAST_RESTORE_FILE_NOT_FOUND 13 // restore file doesn't have file info
#define INVALID_MODE_FAILURE        14 // invalid mode. backup or restore is not specified
#define MERGE_SPLIT_FAILURE         15 // failure in merging split pieces
#define REMOUNT_FAILURE             16 // remount failure
#define SOCKET_FAILURE              17 // socket failure
#define BIND_FAILURE                18 // bind failure
#define LOG_FILE_OPEN_FAILURE       19 // cannot open "/temp/br_daemon.log" file
#define LISTEN_FAILURE              20 // listen failure
#define ACCEPT_FAILURE              21 // accept failure
#define RECV_FAILURE                22 // recv failure
#define BACKUP_INFO_FILE_FAILURE    23 // cannot open backup info file
#define OPEN_DIR_FAILURE            24 // opendir failure
#define STAT_FAILURE                25 // stat failure
#define WRONG_CODE                  26 // S/W bug
#define SPLIT_FAILURE               27 // split failure
#define TEMP_DIR_CHMOD_FAILURE      28 // "chmod 755 /temp" failure
#define HIDDEN_DIR_CREATE_FAILURE   29 // cannot make /temp/hidden directory
#define WORKING_DIR_CREATE_FAILURE  30    // cannot make /temp
#define WORKING_DIR_OWN_CHANGE_FAILURE 31 // "chown shell.shell /temp" failure
#define ACTIVITY_LAUNCH_FAILURE        32 // "am start activity" failure
#define DAEMON_CONNECT_FAILURE         33 // fail to connect BnR daemon
#define BACKUP_CANCEL_FAILURE          34 // backup cancel failure
#define INVALID_STATE                  35
#define REMOVE_SIGNALFILE_FAILURE      36 // remove a signal file failure
#define GET_RESTORE_INFO_START_FAILURE 37 // getRestoreInfoStart return failure
#define GET_VALID_RESTORE_FAILURE      38 // getValidRestore return failure
#define SDRESTORE_FAILURE              39 // sdrestore return failure
#define NOTI_GEN_FAILURE               40 // noti file generation failure
#define BACKUP_FAILURE                 41 // SD_NOTI_BACKUP_RESULT return failure
#define RESTORE_FAILURE                42 // SD_NOTI_RESTORE_RESULT return failure
#define BACKUP_SIZE_FAILURE            43 // cannot generate backup_size file
#define INTERNAL_SD_MOUNT_FAILURE      45 // cannot mount internal SD
#define LISTUP_BACKUP_FILES_FAILURE    46
#define GENERATE_FILES_FAIURE          47
#define FILES_OPEN_FAILURE             48
#define SHORT_BACKUP_OPEN_FAILURE      49
#define SHORT_BACKUP_FLAG_FAILURE      50
#define NO_BACKUP_FILE                 51
#define FIRMWARE_VERSION_MISMATCH      55 // Do not change this number
#define CLEARLOCK_FAILURE              56
#define SYSTEM_MOUNT_FAILURE           57

#define MERGE_CHMOD_FAILURE            58 /* kalen.lee@lge.com 2011.10.04 */
#define SYMLINK_SAVE_FAILURE           59 /* kalen.lee@lge.com 2011.10.05 */
#define MERGE_DIR_CREATION_FAILURE     60 /* kalen.lee@lge.com 2011.10.05 */
#define LINK_CREATION_FAILURE          61 /* kalen.lee@lge.com 2011.10.05 */
