#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<pthread.h>

#define MAX_BACKUP_FILE_LENGTH 256 /* It would be enough */

class Node{
    friend class List;
    public:
        Node(){
            //memset(data,0x00,sizeof(data));
            next=NULL;
        };
        Node(char *i){
                        data=(char *)malloc(sizeof(char)*(strlen(i)+1));
            strcpy(data,i);
            next=NULL;
        }
//    private:
        Node *next;
    //    char data[MAX_BACKUP_FILE_LENGTH];
        char *data;
};
class List{
//    private:
        pthread_mutex_t sync_mutex; /* add it for thread-safety due to encryption_list  */
        char name[128];
        int num;
        public:
        Node *head;
//    public:
        List(char *name_in){
                        memset(name,0x00,sizeof(name));
                        strcpy(name, name_in);
            head=NULL;
                        pthread_mutex_init(&sync_mutex, NULL);
                        num=0;
        };
        List(Node *insertNode){
            head=NULL;
            insert(insertNode);
        };

                ~List();

        void insert(Node *insertNode);
        void del(char *delNum);
        void printList();
                int isEmpty();
                char *front();
                char *getName();
                void setName(char *new_name);
                void free();
                int getNum(){ return num;};
};
