#include <stdio.h>

#define LOCKSETTINGS_DB_FILE    "/data/system/locksettings.db"
#define LOCKSETTINGS_DB_SHM_FILE    "/data/system/locksettings.db-shm"
#define LOCKSETTINGS_DB_WAL_FILE    "/data/system/locksettings.db-wal"



int main(int argc, char **argv)
{
    remove(LOCKSETTINGS_DB_FILE);
    remove(LOCKSETTINGS_DB_SHM_FILE);
    remove(LOCKSETTINGS_DB_WAL_FILE);

    if(!access(LOCKSETTINGS_DB_FILE) || !access(LOCKSETTINGS_DB_SHM_FILE) || !access(LOCKSETTINGS_DB_WAL_FILE))
    {
          fprintf(stderr,"%s or %s or %s still exist\n",LOCKSETTINGS_DB_FILE,LOCKSETTINGS_DB_SHM_FILE,LOCKSETTINGS_DB_WAL_FILE);
          return -1;
    }
    return 0;
}
