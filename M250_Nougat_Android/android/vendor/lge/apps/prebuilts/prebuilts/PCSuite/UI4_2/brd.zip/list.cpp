#include"list.h"
#if 0
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX_BACKUP_FILE_LENGTH 256 /* It would be enough */

class Node{
    friend class List;
    public:
        Node(){
            memset(data,0x00,sizeof(data));
            next=NULL;
        };
        Node(char *i){
            strcpy(data,i);
            next=NULL;
        }
//    private:
        Node *next;
        char data[MAX_BACKUP_FILE_LENGTH];
};
class List{
//    private:
        public:
        Node *head;
//    public:
        List(){
            head=NULL;
        };
        List(Node *insertNode){
            head=NULL;
            insert(insertNode);
        };
        void insert(Node *insertNode);
        void del(char *delNum);
        void printList();
};
#endif
#define LOG_MSG

int List::isEmpty()
{
       if(head==NULL)
            return 1;
       else
            return 0;
}

void List::insert(Node *insertNode)
{

        pthread_mutex_lock(&sync_mutex);

    if(head==NULL){
        head=insertNode;
    }
    else{
        Node *current=head;
        Node *beforeCurrent=NULL;
        for(Node *ptr=head;ptr!=NULL;ptr=ptr->next) current=ptr;
        current->next=insertNode;
    }
        ++num;
        pthread_mutex_unlock(&sync_mutex);
}

char *List::getName()
{
        return name;
}

void List::setName(char *new_name)
{
      memset(name,0x00,sizeof(name));
      strcpy(name,new_name);
}

void List::free() /* distructor */
{
    Node *next,*ptr;
    ptr=head;

    if(ptr==NULL)
       return;

    do{
       next=ptr->next;
       delete ptr;
       ptr=next;
    }while(ptr);

    return;
}

List::~List()
{
    free();
}

char *List::front()
{
    if(head==NULL) return NULL;
    return head->data;
}

#if defined(LOG_MSG) && !defined(STDOUT_PRINT)
extern FILE *log;
#else
#define log stdout
#endif

void List::del(char *delNum)
{
        pthread_mutex_lock(&sync_mutex);

    if(head==NULL) printf("List is Empty\n");
    else{
        Node *current=head;
        Node *beforeCurrent=NULL;
        for(Node *ptr=head;ptr!=NULL;ptr=ptr->next){
            beforeCurrent=current;
            current=ptr;
              #if defined(LOG_MSG)
                if(log)
                {
                  fprintf(log,"List::del[%s][%s]",name,delNum);
                  fflush(log);
                }
              #endif
            if(!strcmp(current->data,delNum)){
                if(beforeCurrent==head && current==head) head=current->next; //check first Node
                else beforeCurrent->next=current->next;
                delete current;
                                --num;
                                pthread_mutex_unlock(&sync_mutex);
                return;
            }
        }
        printf("%s cannot find in List",delNum);
    }

        pthread_mutex_unlock(&sync_mutex);
    return;
}

void List::printList()
{
    if(head==NULL){
        printf("List(%s) is Empty\n",name);
            #if defined(LOG_MSG)
                if(log)
                {
                  fprintf(log,"log:List(%s) is Empty\n",name);
                  fflush(log);
                }
            #endif
    }
    else{
        for(Node *ptr=head;ptr!=NULL;ptr=ptr->next){
            printf("[%s]%s(len:%d)\n",name, ptr->data,strlen(ptr->data));
                     #if defined(LOG_MSG)
                         if(log)
                         {
                           fprintf(log,"[%s]log:%s\n",name,ptr->data);
                           fflush(log);
                         }
                     #endif
        }
    }
}

#if defined(STAND_ALONE_LIST)
int main(){
    List *linkedList=new List();
        Node *Node1 = new Node("t");
        linkedList->insert(Node1);
        Node *Node2 = new Node("tt");
        linkedList->insert(Node2);
        linkedList->printList();
        linkedList->del("t");
        linkedList->printList();
    //while(1) inputSet(linkedList);
        return 0;
};
#endif
