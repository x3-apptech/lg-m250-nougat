#include "timespec.h"
int futimensc (int, char const *, struct timespec const [2]);
int utimens (char const *, struct timespec const [2]);
